package restaurantReservationApp;

import java.time.LocalDate;
import java.time.LocalTime;

public class ReservationMgr {
	private Reservation[][][] reservationMatrix;
	private int tableNum; // in this project, it is 30 tables.
	private int days; // in this project, it is set as one month (30 days)
	private TableMgr tableMgr;
	
	public ReservationMgr(TableMgr tableMgr){
		this.tableMgr = tableMgr;
		this.tableNum = 30;
		this.days = 30;
		reservationMatrix = new Reservation[days][tableNum][2];
		FileMgr.loadReservationMatrix(this);
	}
	
	public int findReservation(int hp, int choice) {
		for (int i = 0; i< 30; i++){
			for (int j =0; j< 30; j++){
				for (int k = 0; k < 2; k++){
					if(reservationMatrix[i][j][k] != null && reservationMatrix[i][j][k].getContactNum() == hp){
						if (choice == 1){ //check reservation
							printReservation(reservationMatrix[i][j][k]);
							return 0;
						}
						else if (choice == 2){ //remove reservation
							reservationMatrix[i][j][k] = null;
							tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
							System.out.println("Reservation is removed");
							return 0;
						}
						else if(choice ==3){ // reservation guest arrive
							int tableId = reservationMatrix[i][j][k].getTableId();
							reservationMatrix[i][j][k] = null; //delete reservation
							tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
							tableMgr.changeStatus(j, "occupied"); //change table status
							return tableId;
						}
					}
				}
			}
		}
		System.out.println("Error: reservation not found!");
		return -1;
	}
	
	public void printReservation(Reservation res){
		System.out.println("==========================================================");
		System.out.println("                       RESERVATION                        ");
		System.out.println("==========================================================");
		System.out.println("Name: "+res.getCustName());
		System.out.println("Contact number: "+res.getContactNum());
		System.out.println("Pax: "+res.getPax());
		System.out.println("Table ID: "+res.getTableId());
		System.out.println("Arrival date: "+res.getArrDate());
		System.out.println("Arrival time: "+res.getArrTime());
		System.out.println("==========================================================");
	}

	public void setTables(Table[] tables, boolean AM) {
		int index = 0;
		if (!AM)
			index= 1; //PM
		for (int i = 0; i < tableNum; i++){
			if (reservationMatrix[0][i][index] != null){
				tables[i].changeStatus("reserved");
			}
		}
	}

	// method to delete expired reservation at current moment
	public void deleteExpiredRes(){ //will only check current day's reservation
		LocalTime currentTime = LocalTime.now();
		for (int i = 0; i < tableNum; i++) {
			int j = currentTime.getHour() < 15? 0:1;
			if (reservationMatrix[0][i][j] != null){
				LocalTime expiryTime = reservationMatrix[0][i][j].getArrTime().plusMinutes(30); // get expiryTime = arrTime + 30mins
				if (expiryTime.compareTo(currentTime) < 0){ //expiryTime past already
					reservationMatrix[0][i][j] = null; //delete expired reservations
				}
			}
		}
	}
	
	public Reservation addReservation(LocalDate arrDate, LocalTime arrTime, int pax) {
		LocalDate today = LocalDate.now();
		if (arrDate.compareTo(today) >= 0 && arrDate.compareTo(today) < 30){
			tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
			int daysAfterToday = arrDate.compareTo(today);
	     	int index = arrTime.getHour() < 15 ? 0:1;
	    	for (int i = 0; i < tableNum; i++){
	        	if (pax <= tableMgr.getCapacity(i) && reservationMatrix[daysAfterToday][i][index] == null){
	        		Reservation res = new Reservation(arrDate, arrTime,pax,tableMgr.getTableID(i));
	        		//System.out.println("Successful ! Table " + tableMgr.getTableID(i) + " is reserved for you.");
	            	reservationMatrix[daysAfterToday][i][index] = res;
	            	if (daysAfterToday == 0){
	            		tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
	            	}
	             	return res;
	            }
	    	}
	    	System.out.println("Sorry, no more available table for reservation.");
            return null;
		}
		else{
        	System.out.println("You cannot make reservation on that date.");
        	return null;
        }
	}
}
