package restaurantReservationApp;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ReservationMgr {
	private Reservation[][][] reservationMatrix;
	private int tableNum; // in this project, it is 30 tables.
	private int days; // in this project, it is set as one month (30 days)
	private TableMgr tableMgr;
	private Scanner sc = new Scanner(System.in);
	
	
	
	public ReservationMgr(TableMgr tableMgr){
		this.tableMgr = tableMgr;
		this.tableNum = 30;
		this.days = 30;
		reservationMatrix = new Reservation[days][tableNum][2];
		FileMgr.loadReservationMatrix(this);
	}
	
	public void addReservation(String[] data){
		Reservation res = new Reservation(data);
		int daysAfterToday = res.getArrDate().compareTo(LocalDate.now());
		int tableIndex = res.getTableId()-1;
		int AM = res.getArrTime().getHour()< 15? 0: 1;
		reservationMatrix[daysAfterToday][tableIndex][AM] = res;	
	}
	
	
	
	public int findReservation(int hp, int choice) {
		for (int i = 0; i< 30; i++){
			for (int j =0; j< 30; j++){
				for (int k = 0; k < 2; k++){
					if(reservationMatrix[i][j][k] != null && reservationMatrix[i][j][k].getHp() == hp){
						if (choice == 1){ //check reservation
							printReservation(reservationMatrix[i][j][k]);
							return 0;
						}
						else if (choice == 2){ //remove reservation
							reservationMatrix[i][j][k] = null;
							tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
							System.out.println("Reservation is removed");
							return 0;
						}
						else if(choice ==3){ // reservation guest arrive
							int tableId = reservationMatrix[i][j][k].getTableId();
							reservationMatrix[i][j][k] = null; //delete reservation
							tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
							tableMgr.changeStatus(j, "occupied"); //change table status
							return tableId;
						}
					}
				}
			}
		}
		System.out.println("Error: reservation not found!");
		return -1;
	}
	
	public void printReservation(Reservation res){
		System.out.println("==========================================================");
		System.out.println("                       RESERVATION                        ");
		System.out.println("==========================================================");
		System.out.println("Name: "+res.getCustName());
		System.out.println("Contact number: "+res.getHp());
		System.out.println("Pax: "+res.getPax());
		System.out.println("Table ID: "+res.getTableId());
		System.out.println("Arrival date: "+res.getArrDate());
		System.out.println("Arrival time: "+res.getArrTime());
		System.out.println("==========================================================");
	}

	public void setTables(Table[] tables, boolean AM) {
		int index = 0;
		if (!AM)
			index= 1; //PM
		for (int i = 0; i < tableNum; i++){
			if (reservationMatrix[0][i][index] != null && tables[i].getStatus().compareToIgnoreCase("vacant") == 0){
				tables[i].changeStatus("reserved");
			}
			if (reservationMatrix[0][i][index] == null && tables[i].getStatus().compareToIgnoreCase("reserved") == 0){
				tables[i].changeStatus("vacant");
			}
		}
	}

	// method to delete expired reservation at current moment
	public void deleteExpiredRes(){ //will only check current day's reservation
		LocalTime currentTime = LocalTime.now();
		for (int i = 0; i < tableNum; i++) {
			int j = currentTime.getHour() < 15? 0:1;
			if (reservationMatrix[0][i][j] != null){
				LocalTime expiryTime = reservationMatrix[0][i][j].getArrTime().plusMinutes(30); // get expiryTime = arrTime + 30mins
				if (expiryTime.compareTo(currentTime) < 0){ //expiryTime past already
					reservationMatrix[0][i][j] = null; //delete expired reservations
					System.out.println("DEBUG : deleteExpiredRes");
				}
			}
		}
	}
	
	public Reservation addReservation(LocalDate arrDate, LocalTime arrTime, int pax) {
		LocalDate today = LocalDate.now();
		if (arrDate.compareTo(today) >= 0 && arrDate.compareTo(today) < 30){
			tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
			int daysAfterToday = arrDate.compareTo(today);
	     	int index = arrTime.getHour() < 15 ? 0:1;
	    	for (int i = 0; i < tableNum; i++){
	        	if (pax <= tableMgr.getCapacity(i) && reservationMatrix[daysAfterToday][i][index] == null){
	        		Reservation res = new Reservation(arrDate, arrTime,pax,tableMgr.getTableID(i));
	            	reservationMatrix[daysAfterToday][i][index] = res;
	            	if (daysAfterToday == 0){
	            		tableMgr.resetReservedTable(LocalTime.now().getHour() < 15);
	            	}
	             	return res;
	            }
	    	}
	    	System.out.println("Sorry, no more available table for reservation.");
            return null;
		}
		else{
        	System.out.println("You cannot make reservation on that date.");
        	return null;
        }
	}

	public void updateDB() {
		FileMgr.writeReservation(reservationMatrix);
	}
	
	
	public void checkReservationUI(){
		try{
			System.out.println("1. Check reservation");
			System.out.println("2. Remove reservation");
			System.out.println("3. Back");
			
			System.out.println("Enter your choice: ");
			int c= sc.nextInt();
		
		
			switch (c){
				case 1 : case 2:
				{
					System.out.println("Contact Number?");
					int hp = sc.nextInt();
					int result = findReservation(hp, c);
					if (result == -1)
						System.out.println("Cannot find reservation.");
					break;
				}
				case 3:
					break;
				default:
					System.out.println("Error: invalid input!");
					break;	
			}

		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			checkReservationUI();
		}
	
	}

	
	
	public void bookReservationUI() {
		LocalDate arrDate = null;
		LocalTime arrTime = null;
		try{
			System.out.println("Input arrival date (Format: yyyy-MM-dd, e.g. 2014-01-01): ");
			String dateStr = sc.next();
			arrDate = LocalDate.parse(dateStr);
			if (arrDate.isBefore(LocalDate.now()))
				throw new Exception ("Error: invalid date");
			System.out.println("Input arrival time (Format: HH:MM, e.g. 18:00): ");
			String timeStr = sc.next();
			arrTime = LocalTime.parse(timeStr);
		}catch(DateTimeParseException e){
			System.out.println("Error: incorrect date/time format");
			bookReservationUI();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			bookReservationUI();
		}
		
		System.out.println("Input number of people: ");
		Reservation res = null;
		try{
			int pax= sc.nextInt();
			
			res = addReservation(arrDate, arrTime, pax);
			
			if (res == null){
				return;
			}
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			bookReservationUI();
		}
		int flag = 0;
		do{
			
			try{
				sc.nextLine(); // flush
				System.out.print("Pleases enter the customer name:");
				String name = sc.nextLine();
				res.setName(name);
				System.out.print("Contact: ");
				int contact = sc.nextInt();
				res.setContact(contact);
				System.out.println("Reservation successful!");
				printReservation(res);
				flag =1;
			}catch(InputMismatchException e){
				System.out.println("Error: invalid input");
				sc.nextLine();
				continue;
			}
		}while (flag == 0);
		
	}
}
