package restaurantReservationApp;


import java.util.ArrayList;
import java.util.Iterator;
import restaurantReservationApp.Food.KindOfFood;


public class FoodMgr {
	
	private static ArrayList<Food> foodList = new ArrayList<Food>();
	
	public FoodMgr(){
		FileMgr.loadFood(this);
	}

	public void addFood (String[] attributes){
		Food food = new Food(attributes);
		foodList.add(food);
	}
	
	public void addFood (int ID, String name, double price, int category, String description){
		Food food = new Food(ID, name, price, category, description);
		int index = getInsertionIndex(category);
		foodList.add(index, food);
		System.out.println("Food successfully added!");
		System.out.println(food.toString());
	}
	
	public int removeFood (int ID) {
		Food food = searchFood(ID);
		if (food == null)
			return -1;
		foodList.remove(food);
		System.out.println("Food successfully removed!");
		System.out.println(food.toString());
		return 0;
	}

	public int updateFood(int ID, int choice, String value){
		Food food = searchFood(ID);
		if (food == null)
			return -1;
		switch (choice){
			case 1:
				food.setName(value);
				break;
			case 2:
				food.setPrice(Double.parseDouble(value));
				break;
			case 3:
				food.setDescription(value);
				break;
		}
		System.out.println("Successfully updated!");
		System.out.println(food.toString());
		return 0;
		
	}
	
	public static Food searchFood(int ID){
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			if (food.getID() == ID){
				return food;
			}
		}
		System.out.println("Error: food not found!");
		return null;
	}
	
	private int getInsertionIndex(int category){
		int index_last = 0;
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			if (food.getCategory().ordinal() > category -1 ){
				break;
			}
			else{
				index_last++;
			}
		}
		return index_last;
	}
	
	public static void printMenu(){
		System.out.println("========================================================================================");
		System.out.println("                                          MENU                                          ");
		System.out.println("========================================================================================");
		
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			System.out.println(food.toString());
		}
	}
	
	public void printCategories(){
		for (int i = 0; i< KindOfFood.values().length; i++){
			System.out.printf("%d: %s \n", i+1, KindOfFood.values()[i]);
		}
	}

	public void printMenuByCategory(int category) {
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			if (food.getCategory().ordinal() == category -1 ){
				System.out.println(food.toString());
			}
			else if(food.getCategory().ordinal() > category -1){
				break;
			}
		}	
	}
}
