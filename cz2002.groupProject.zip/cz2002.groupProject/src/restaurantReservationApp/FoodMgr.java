package restaurantReservationApp;


import java.util.ArrayList;
import java.util.Iterator;
import restaurantReservationApp.Food.KindOfFood;
import java.util.Scanner;


public class FoodMgr {
	
	private static ArrayList<Food> foodList = new ArrayList<Food>();
	private Scanner sc = new Scanner(System.in);
	
	public FoodMgr(){
		FileMgr.loadFood(this);
	}

	
	public void addFood(Food food) {
		foodList.add(food);
		
	}
	
	public void addFood (int ID, String name, double price, int category, String description){
		Food food = new Food(ID, name, price, category, description);
		int index = getInsertionIndex(category);
		foodList.add(index, food);
		System.out.println("Food successfully added!");
		System.out.println(food.toString());
	}
	
	public int removeFood (Food food) {
		foodList.remove(food);
		System.out.println("Food successfully removed!");
		return 0;
	}

	public int updateFood(Food food, int choice, String value){
		if (food == null)
			return -1;
		switch (choice){
			case 1:
				food.setName(value);
				break;
			case 2:
				food.setPrice(Double.parseDouble(value));
				break;
			case 3:
				food.setDescription(value);
				break;
		}
		System.out.println("Successfully updated!");
		System.out.println(food.toString());
		return 0;
		
	}
	
	public static Food searchFood(int ID){
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			if (food.getID() == ID){
				return food;
			}
		}
		return null;
	}
	
	private int getInsertionIndex(int category){
		int index_last = 0;
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			if (food.getCategory().ordinal() > category -1 ){
				break;
			}
			else{
				index_last++;
			}
		}
		return index_last;
	}
	
	public static void printMenu(){
		System.out.println("========================================================================================");
		System.out.println("                                          MENU                                          ");
		System.out.println("========================================================================================");
		
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			System.out.println(food.toString());
		}
	}
	
	public void printCategories(){
		for (int i = 0; i< KindOfFood.values().length; i++){
			System.out.printf("%d: %s \n", i+1, KindOfFood.values()[i]);
		}
	}

	public void printMenuByCategory(int category) {
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			if (food.getCategory().ordinal() == category -1 ){
				System.out.println(food.toString());
			}
			else if(food.getCategory().ordinal() > category -1){
				break;
			}
		}	
	}

	public void updateDB() {
		FileMgr.writeFood(foodList);	
	}

	public void foodUI() throws ItemNotFoundException 
	{
		System.out.println("1: Create menu item");
		System.out.println("2: Update menu item");
		System.out.println("3: Remove menu item");
		System.out.println("4: Print menu");
		System.out.println("5: Quit");
		int c=sc.nextInt();
		
		switch(c)
		{
			case 1://add food
				addFoodUI();
				break;
			case 2://update food
				updateFoodUI();
				break;
			case 3://remove food
				removeFoodUI();
				break;
			case 4: //print menu
				printMenuUI();
			case 5:
				break;
			default:
				System.out.println("Error: invalid input!");
				break;
		}
	}

	private void printMenuUI() {
		System.out.println("0: ALL");
		printCategories();
		System.out.println("Enter your choice");
		int c =sc.nextInt();
		if (c == 0)
			printMenu();
		else 
			printMenuByCategory(c);
		
	}
	
	private void removeFoodUI() throws ItemNotFoundException {
		System.out.print("Enter the food id:");
		int id=sc.nextInt();
		Food food = searchFood(id);
		if (food == null){
			throw new ItemNotFoundException("food");
		}
		removeFood(food);	
	}

	private void updateFoodUI() throws ItemNotFoundException {
		System.out.print("Enter the food id: ");
		int id=sc.nextInt();
		Food food = searchFood(id);
		if (food == null){
			throw new ItemNotFoundException("food");
		}
		int c;
		do
		{
			System.out.println("1: Update name");
			System.out.println("2: Update price");
			System.out.println("3: Update description");
			System.out.println("4: Quit");
			c = sc.nextInt();
			sc.nextLine(); // flush
			switch(c){
				case 1: case 2: case 3:
					System.out.println("New Value:");
					String value = sc.nextLine();
					updateFood(food, c, value);
					break;
				case 4:
					break;
				default:
					System.out.println("Error: invalid input!");
			}
				
		}while(c>0 &&c<4);
		
	}

	private void addFoodUI() throws ItemNotFoundException{
		System.out.print("Food ID:");
        int id = sc.nextInt();
        if (searchFood(id) != null){
        	throw new ItemNotFoundException("food");
        }
        sc.nextLine(); // flush
		System.out.print("Food name:");
		String name =sc.nextLine();
		System.out.print("Food price:");
		double price=sc.nextDouble();
		System.out.println("Food category:");
		printCategories();
		int category = sc.nextInt();
		sc.nextLine(); //flush
		System.out.print("Food description:");
        String description = sc.nextLine();
        addFood(id, name, price, category, description);
		
	}
		
}
