package restaurantReservationApp;


import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import restaurantReservationApp.Food.KindOfFood;
import java.util.Scanner;


public class FoodMgr {
	private Scanner sc = new Scanner(System.in);
	
	/**
	 * Contains all the Food in the menu.
	 */
	private static ArrayList<Food> foodList = new ArrayList<Food>();

	
	/**
	 * Initiate the foodList by calling static function 'loadFood' in FileMgr
	 */
	public FoodMgr(){
		FileMgr.loadFood(this);
	}
	
	/**
	 * Add the Food to the foodList
	 * @param food
	 */
	public void addFood(Food food) {
		foodList.add(food);	
	}
	
	/**
	 * Create a Food with the given parameters
	 * Add the food to the correct position in the foodList so that food belonging to the same
	 * category can be grouped together
	 * @param ID
	 * @param name
	 * @param price
	 * @param category
	 * @param description
	 */
	public void addFood (int ID, String name, double price, int category, String description){
		Food food = new Food(ID, name, price, category, description);
		int index = getInsertionIndex(category);
		foodList.add(index, food);
		System.out.println("Food successfully added!");
		System.out.println(food.toString());
	}
	
	/**
	 *If foodList contains the Food, it will be removed, return 0;
	 *Else return -1;
	 * @param food
	 * @return 0 or -1 depending on whether successfully removed.
	 */
	public int removeFood (Food food) {
		if (!foodList.remove(food)) 
			return -1;
		System.out.println("Food successfully removed!");
		return 0;
	}

	/**
	 * If foodList contains the food, update the attribute of the food, return 0;
	 * Else return -1;
	 * @param food: The food to be updated
	 * @param choice: 1 = updateName, 2 = updatePrice, 3 = updateDescription
	 * @param value: new value
	 * @return 0 or -1 depending on whether the update is successful
	 */
	public int updateFood(Food food, int choice, String value){
		if (!foodList.contains(food))
			return -1;
		switch (choice){
			case 1:
				food.setName(value);
				break;
			case 2:
				food.setPrice(Double.parseDouble(value));
				break;
			case 3:
				food.setDescription(value);
				break;
		}
		System.out.println("Successfully updated!");
		System.out.println(food.toString());
		return 0;
		
	}
	
	/**
	 * Get the Food with corresponding ID, return null if no food has the same ID
	 * @param ID
	 * @return 
	 */
	public static Food getFoodByID(int ID){
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			if (food.getID() == ID){
				return food;
			}
		}
		return null;
	}
	
	/**
	 * Traverse down foodList to find the index of the last Food item belonging to the specific category.
	 * New food will be inserted immediately after that Food.
	 * @param category
	 * @return index of the 
	 */
	private int getInsertionIndex(int category){
		int index_last = 0;
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			if (food.getCategory().ordinal() > category -1 ){
				break;
			}
			else{
				index_last++;
			}
		}
		return index_last;
	}
	
	/**
	 * Print all food items in foodList
	 */
	public static void printMenu(){
		System.out.println("========================================================================================");
		System.out.println("                                          MENU                                          ");
		System.out.println("========================================================================================");
		
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			System.out.println(food.toString());
		}
	}
	
	/**
	 * Print the list of categories (enum KindOfFood)
	 */
	public void printCategories(){
		for (int i = 0; i< KindOfFood.values().length; i++){
			System.out.printf("%d: %s \n", i+1, KindOfFood.values()[i]);
		}
	}

	/**
	 * Print all food belonging to the category
	 * @param category = enum index + 1;
	 */
	public void printMenuByCategory(int category) {
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			if (food.getCategory().ordinal() == category -1 ){
				System.out.println(food.toString());
			}
			else if(food.getCategory().ordinal() > category -1){
				break;
			}
		}	
	}

	/**
	 * Ask FileMgr to update FoodDB.txt when the program exit.
	 */
	public void updateDB() {
		FileMgr.writeFood(foodList);	
	}

	
	/**
	 * User interface for:
	 * 1. Create Food; 2. Update Food; 3. Remove Food; 4. Print food
	 * @throws ItemNotFoundException
	 */
	public void foodUI() throws ItemNotFoundException 
	{
		System.out.println("1: Create menu item");
		System.out.println("2: Update menu item");
		System.out.println("3: Remove menu item");
		System.out.println("4: Print menu");
		System.out.println("5: Quit");
		int c= 0;
		try{
			c=sc.nextInt();
			
			
			switch(c)
			{
				case 1://add food
					addFoodUI();
					break;
				case 2://update food
					updateFoodUI();
					break;
				case 3://remove food
					removeFoodUI();
					break;
				case 4: //print menu
					printMenuUI();
				case 5:
					break;
				default:
					System.out.println("Error: invalid input!");
					break;
			}
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input!");
			sc.nextLine();
			foodUI();
		}
	}

	/**
	 * User interface for 
	 * 1. Print all food. 1.Print food by category
	 */
	private void printMenuUI() {
		try{
			System.out.println("0: ALL");
			printCategories();
			System.out.println("Enter your choice");
			int c =sc.nextInt();
			if (c == 0)
				printMenu();
			else 
				printMenuByCategory(c);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			printMenuUI();
		}
		
	}
	
	/**
	 * User interface to remove Food
	 * Get user input: food ID
	 * @throws ItemNotFoundException: no Food with corresponding ID
	 */
	private void removeFoodUI() throws ItemNotFoundException {
		try{
			System.out.print("Enter the food id:");
			int id=sc.nextInt();
			Food food = getFoodByID(id);
			if (food == null){
				throw new ItemNotFoundException("food");
			}
			removeFood(food);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			removeFoodUI();
		}
	}

	/**
	 * User interface to update Food
	 * Get user input: 1. food ID; 2. choice of attribute to be updated; 3. new value.
	 * @throws ItemNotFoundException: no Food with corresponding ID
	 */
	private void updateFoodUI() throws ItemNotFoundException {
		try{
			System.out.print("Enter the food id: ");
			int id=sc.nextInt();
			Food food = getFoodByID(id);
			if (food == null){
				throw new ItemNotFoundException("food");
			}
			int c;
			do
			{
				System.out.println("1: Update name");
				System.out.println("2: Update price");
				System.out.println("3: Update description");
				System.out.println("4: Quit");
				c = sc.nextInt();
				sc.nextLine(); // flush
				switch(c){
					case 1: case 2: case 3:
						System.out.println("New Value:");
						String value = sc.nextLine();
						updateFood(food, c, value);
						break;
					case 4:
						break;
					default:
						System.out.println("Error: invalid input!");
				}
					
			}while(c>0 &&c<4);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			updateFoodUI();
		}
		
	}

	/**
	 * User interface
	 * Get user input: 1. ID; 2. name; 3.price; 4.category; 5.description.
	 * @throws ItemNotFoundException
	 */
	private void addFoodUI() throws ItemNotFoundException{
		try{
			System.out.print("Food ID:");
	        int id = sc.nextInt();
	        if (getFoodByID(id) != null){
	        	System.out.println("Error: food ID exist!");
	        	return;
	        }
	        sc.nextLine(); // flush
			System.out.print("Food name:");
			String name =sc.nextLine();
			System.out.print("Food price:");
			double price=sc.nextDouble();
			System.out.println("Food category:");
			printCategories();
			int category = sc.nextInt();
			sc.nextLine(); //flush
			System.out.print("Food description:");
	        String description = sc.nextLine();
	        addFood(id, name, price, category, description);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			addFoodUI();
		}
		
	}
		
}
