package restaurantReservationApp;

public class Receipt {
	public static final double GST = 0.07;
	public static final double SERVICECHARGE = 0.10;
	private Order order;
	
	
	

}
