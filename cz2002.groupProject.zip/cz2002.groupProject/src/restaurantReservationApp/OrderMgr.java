package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;


public class OrderMgr {
	
	private ArrayList<Order> orderList = new ArrayList<Order>();
	private Scanner sc = new Scanner(System.in);
	
	
	public Order addOrder(int tableId, int staffId) {
		int orderID = orderList.size()+1;
		Order order = new Order(orderID, tableId, staffId);
		orderList.add(order);
		return order;
	}
	
	public Order getOrderById(int orderID){
		for (Order order: orderList)
			if (order.getOrderID() == orderID)
				return order;
		return null;
	}
	
	public void addToOrder(Order order, MenuItem item, int quantity){
		order.addToOrder(item, quantity);
		System.out.println("Food successfully added to order!");
	}
	
	public void removeFromOrder(Order order, MenuItem item, int quantity){
		int result =  order.removeFromOrder(item, quantity);
		if (result ==0)
			System.out.println("Error: unable to remove food. Check order!");
		else
			System.out.println("Food successfully removed from order!");
	}
	
	
	public void printOrder(Order order){
		Map<MenuItem, Integer> foodOrderList = order.getOrderList();
		Set<MenuItem> itemSet = foodOrderList.keySet();
		System.out.println("============================================================================");
		System.out.println("Order ID: " + order.getOrderID());
		System.out.printf("%-5s %-50s %-10s\n", "ID", "Name", "Quantity");
		
		for(MenuItem item: itemSet)
			System.out.printf("%-5d %-50s %-10d\n",item.getID(),item.getName(), foodOrderList.get(item));
		System.out.println("============================================================================");
	}
	
	
	public void printReceipt(Order order){
		Map<MenuItem, Integer> foodOrderList = order.getOrderList();
		Set<MenuItem> itemSet = foodOrderList.keySet();
		System.out.println("============================================================================");
		System.out.println("                               SCSE RESTAURANT                              ");
		System.out.println("                               Nanyang Avenue                               ");
		System.out.println("                                  65432107                                  ");
		System.out.println("Staff : " + order.getStaffId());
		System.out.println("Table number : "+ order.getTableID());
		System.out.println(order.getDateTime().toString());
		System.out.println("============================================================================");
		
		for(MenuItem item: itemSet)
			System.out.printf("%-5d %-50s %-10.2f\n",foodOrderList.get(item),item.getName(), item.getPrice());
		System.out.println("============================================================================");
		System.out.printf("%52s %10.2f\n","Total: ", order.getPrice());
		System.out.println();
		System.out.println("                         Thanks for dining with us!                         ");
		System.out.println();
		System.out.println("============================================================================");
	}
	
	

	public void addItemUI(Order order) throws ItemNotFoundException {
		int c;
		do{
			System.out.println("1: Add food");
			System.out.println("2: Add promotional set" );
			System.out.println("3. Quit");
			c = sc.nextInt();
			switch (c){
				case 1:
					addFoodUI(order);
					break;
				case 2:
					addPromoSetUI(order);
					break;
				case 3:
					break;
				default:
					System.out.println("Error: invalid input!");
					break;
				
			}
		} while (c != 3);
		
	}

	private void addPromoSetUI(Order order) throws ItemNotFoundException {
		System.out.println("Enter promotional set id and the quantity");
		int id = sc.nextInt();
		PromoSet promoSet = PromoSetMgr.searchPromoSet(id);
		if (promoSet == null){
			throw new ItemNotFoundException("promotional set");
		}
		int quantity=sc.nextInt();
		addToOrder(order,promoSet, quantity);
	}

	private void addFoodUI(Order order) throws ItemNotFoundException {
		System.out.println("Enter food id and the quantity");
		int id=sc.nextInt();
		Food food = FoodMgr.searchFood(id);
		if (food == null){
			throw new ItemNotFoundException("food");
		}
		int quantity=sc.nextInt();
		addToOrder(order,food, quantity);
	}
	
	public void viewOrderUI() throws ItemNotFoundException {
		System.out.print("Enter the order id:");
		int orderId=sc.nextInt();
		Order order= getOrderById(orderId);
		if(order ==null){
			throw new ItemNotFoundException("order");
		}
		printOrder(order);
	}

	private void removePromoSetUI(Order order) throws ItemNotFoundException {
		System.out.println("1: Enter the promotional set id and the amount");
		int id=sc.nextInt();
		PromoSet promoSet = PromoSetMgr.searchPromoSet(id);
		if (promoSet== null){
			throw new ItemNotFoundException("promotional set");
		}
		int quantity=sc.nextInt();
		order.removeFromOrder(promoSet, quantity);
	}

	private void removeFoodUI(Order order) throws ItemNotFoundException {
		System.out.println("1: Enter the food id and the amount");
		int id=sc.nextInt();
		Food food = FoodMgr.searchFood(id);
		if(food == null){
			throw new ItemNotFoundException("food");
		}
		int quantity=sc.nextInt();
		int result = order.removeFromOrder(food, quantity);
		if(result == 0)
			System.out.println("Food successfully removed!");
		else
			System.out.println("Error: not able to remove food. Check order!");
	}
	
	private void removeItemUI(Order order) throws ItemNotFoundException {
		int c;
		do{
			System.out.println("1: Remove food");
			System.out.println("2: Remove promotional set" );
			System.out.println("3. Quit");
			c = sc.nextInt();
			switch (c){
				case 1:
					removeFoodUI(order);
					break;
				case 2:
					removePromoSetUI(order);
					break;
				case 3:
					break;
				default:
					System.out.println("Error: invalid input!");
					break;
				
			}
		} while (c != 3);
	}
	
	public void modifyOrderUI() throws ItemNotFoundException {
		System.out.print("Enter the order id:");
		int orderId=sc.nextInt();
		Order order= getOrderById(orderId);
		if(order ==null){
			throw new ItemNotFoundException("order");
		}
		System.out.println("1: Add order items to order");
		System.out.println("2: Remove order items from order");
		System.out.println("3: Quit");
		int c=sc.nextInt();
		switch(c) 
		{
			case 1:	//add stuff to the order
			{
				addItemUI(order);
				break;
			}
			case 2: // remove from order
			{
				removeItemUI(order);
				break;
			}
			default: 
			{
				System.out.println("Error: invalid input!");
				break;
			}
		}
	}


}
