package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;


public class OrderMgr {
	
	private ArrayList<Order> orderList = new ArrayList<Order>();
	
	public void addOrder(Order order){ //order object created in Table class is passed into here to be added into list of all orders
		int orderID = orderList.size()+1;
		order.setOrderID(orderID);
		orderList.add(order);
	}
	
	public Order addOrder(int tableId, int staffId) {
		int orderID = orderList.size()+1;
		Order order = new Order(orderID, tableId, staffId);
		orderList.add(order);
		return order;
	}
	
	public Order getOrderById(int orderID){
		Iterator<Order> itr = orderList.iterator();
		while(itr.hasNext()){
			Order order = itr.next();
			if (order.getOrderID() == orderID){
				return order;
			}
		}
		return null;
	}
	
	public void addFoodOrder(int orderID, Food food, int num){
		Order order = getOrderById(orderID);
		order.addFood(food, num);
	}
	
	public void removeFoodOrder(int orderID, Food food, int num){
		Order order = getOrderById(orderID);
		int result = order.removeFood(food, num);
		if (result == -1){
			System.out.println("There are no " +num+ " amount of " +food.getName()+ " ordered.");
		}
	}
	
	public void addPromoSetOrder(int orderID, PromoSet promoSet, int num){
		Order order = getOrderById(orderID);
		order.addPromoSet(promoSet, num);
	}
	
	public void removePromoSetOrder(int orderID, PromoSet promoSet, int num){
		Order order = getOrderById(orderID);
		int result = order.removePromoSet(promoSet, num);
		if (result == -1){
			System.out.println("There are no " +num+ " amount of " +promoSet.getName()+ " ordered.");
		}
	}
	
	public void printReceipt(int orderID){
		int i;
		Order order = getOrderById(orderID);
		ArrayList<Food> foodOrder = order.getFoodOrder();
		ArrayList<Integer> foodQuantity = order.getFoodQuantity();
		ArrayList<PromoSet> promoSetOrder = order.getPromoSetOrder();
		ArrayList<Integer> promoSetQuantity = order.getPromoSetQuantity();
		System.out.println("----------------------------------------");
		System.out.println("RESTAURANT NAME");
		System.out.println("restaurant address");
		System.out.println("restaurant telephone");
		System.out.println("\t Staff : " + order.getStaffId());
		for(i=0; i<foodOrder.size(); i++){
			
		}
		
	}

	
	
	
	/* public void printReceipt(int orderID){
		int i, num;
		String name;
		Food food;
		double price;
		Order order = getOrderById(orderID);
		ArrayList<Integer[]> foodOrder = order.getFoodOrder();
		ArrayList<Integer[]> promoSetOrder = order.getPromoSetOrder();
		System.out.println("<Restaurant Name");
		System.out.println("<Address>");
		System.out.println("<Telephone number>");
		System.out.println("*********************");
		for (i=0; i<foodOrder.size();){
			num = foodOrder.get(i)[1];
			food = fm.searchFood(foodOrder.get(i)[0]);
			name = food.getFoodName();
			price = food.getFoodPrice();
			System.out.println(num + "\t" + name + "\t" + price);
		}
		System.out.println("-----------------------------------------");
		System.out.println("\t\t Subtotal : " + (findFoodPrice(foodOrder)+findPromoSetPrice(promoSetOrder)));
		System.out.println("\t\t GST : " + (findFoodPrice(foodOrder)+findPromoSetPrice(promoSetOrder))*1.17);
		System.out.println("=======================================");
		System.out.println("\t\t Total : " + order.getPrice());
		
	}  */

}
