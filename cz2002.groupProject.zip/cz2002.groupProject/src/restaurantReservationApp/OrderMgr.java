package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


public class OrderMgr {
	
	private ArrayList<Order> orderList = new ArrayList<Order>();
	
	public Order addOrder(int tableId, int staffId) {
		int orderID = orderList.size()+1;
		Order order = new Order(orderID, tableId, staffId);
		orderList.add(order);
		return order;
	}
	
	public Order getOrderById(int orderID){
		for (Order order: orderList)
			if (order.getOrderID() == orderID)
				return order;
		return null;
	}
	
	public void addToOrder(Order order, MenuItem item, int quantity){
		order.addToOrder(item, quantity);
		System.out.println("Food successfully added to order!");
	}
	
	public void removeFromOrder(Order order, MenuItem item, int quantity){
		int result =  order.removeFromOrder(item, quantity);
		if (result ==0)
			System.out.println("Error: unable to remove food. Check order!");
		else
			System.out.println("Food successfully removed from order!");
	}
	
	
	public void printOrder(Order order){
		Map<MenuItem, Integer> foodOrderList = order.getOrderList();
		Set<MenuItem> itemSet = foodOrderList.keySet();
		System.out.println("============================================================================");
		System.out.println("Order ID: " + order.getOrderID());
		System.out.printf("%-5s %-50s %-10s\n", "ID", "Name", "Quantity");
		
		for(MenuItem item: itemSet)
			System.out.printf("%-5d %-50s %-10d\n",item.getID(),item.getName(), foodOrderList.get(item));
		System.out.println("============================================================================");
	}
	
	
	public void printReceipt(Order order){
		Map<MenuItem, Integer> foodOrderList = order.getOrderList();
		Set<MenuItem> itemSet = foodOrderList.keySet();
		System.out.println("============================================================================");
		System.out.println("                               SCSE RESTAURANT                              ");
		System.out.println("                               Nanyang Avenue                               ");
		System.out.println("                                  65432107                                  ");
		System.out.println("Staff : " + order.getStaffId());
		System.out.println("Table number : "+ order.getTableID());
		System.out.println(order.getDateTime().toString());
		System.out.println("============================================================================");
		
		for(MenuItem item: itemSet)
			System.out.printf("%-5d %-50s %-10.2f\n",foodOrderList.get(item),item.getName(), item.getPrice());
		System.out.println("============================================================================");
		System.out.printf("%52s %10.2f\n","Total: ", order.getPrice());
		System.out.println();
		System.out.println("                         Thanks for dining with us!                         ");
		System.out.println();
		System.out.println("============================================================================");
	}

}
