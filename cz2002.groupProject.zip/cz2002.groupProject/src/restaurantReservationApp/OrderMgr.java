package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;


public class OrderMgr {
	
	private ArrayList<Order> orderList = new ArrayList<Order>();
	
	public Order addOrder(int tableId, int staffId) {
		int orderID = orderList.size()+1;
		Order order = new Order(orderID, tableId, staffId);
		orderList.add(order);
		return order;
	}
	
	public Order getOrderById(int orderID){
		Iterator<Order> itr = orderList.iterator();
		while(itr.hasNext()){
			Order order = itr.next();
			if (order.getOrderID() == orderID){
				return order;
			}
		}
		return null;
	}
	
	public void addFoodOrder(Order order, Food food, int num){
		order.addFood(food, num);
	}
	
	public void removeFoodOrder(Order order, Food food, int num){
		int result = order.removeFood(food, num);
		if (result == -1){
			System.out.println("There are no " +num+ " amount of " +food.getName()+ " ordered.");
		}
	}
	
	public void addPromoSetOrder(Order order, PromoSet promoSet, int num){
		order.addPromoSet(promoSet, num);
	}
	
	public void removePromoSetOrder(Order order, PromoSet promoSet, int num){
		int result = order.removePromoSet(promoSet, num);
		if (result == -1){
			System.out.println("There are no " +num+ " amount of " +promoSet.getName()+ " ordered.");
		}
	}
	
	public void printOrder(Order order){
		ArrayList<Food> foodOrder = order.getFoodOrder();
		ArrayList<Integer> foodQuantity = order.getFoodQuantity();
		ArrayList<PromoSet> promoSetOrder = order.getPromoSetOrder();
		ArrayList<Integer> promoSetQuantity = order.getPromoSetQuantity();
		System.out.println("============================================================================");
		System.out.println("Order ID: " + order.getOrderID());
		System.out.println("Ala Carte");
		System.out.printf("%-5s %-50s %-10s\n", "ID", "Name", "Quantity");
		for (int i = 0; i< foodOrder.size(); i++){
			Food food = foodOrder.get(i);
			int quantity = foodQuantity.get(i);
			System.out.printf("%-5d %-50s %-10d\n",food.getID(),food.getName(), quantity);
		}
		System.out.println();
		System.out.println("SET");
		System.out.printf("%-5s %-50s %-10s\n", "ID", "Name", "Quantity");
		for (int i = 0; i< promoSetOrder.size(); i++){
			PromoSet promoSet = promoSetOrder.get(i);
			int quantity = promoSetQuantity.get(i);
			System.out.printf("%-5d %-50s %-10d\n",  promoSet.getID(), promoSet.getName(),quantity);
		}
		System.out.println("============================================================================");
	}
	
	public int checkOut(int orderID){
		Order order = getOrderById(orderID);
		if (order == null){
			System.out.println("Error: order not found!");
			return -1;
		}
		printReceipt(order);
		return order.getTableID();
	}
	
	public void printReceipt(Order order){
		ArrayList<Food> foodOrder = order.getFoodOrder();
		ArrayList<Integer> foodQuantity = order.getFoodQuantity();
		ArrayList<PromoSet> promoSetOrder = order.getPromoSetOrder();
		ArrayList<Integer> promoSetQuantity = order.getPromoSetQuantity();
		System.out.println("============================================================================");
		System.out.println("                               SCSE RESTAURANT                              ");
		System.out.println("                               Nanyang Avenue                               ");
		System.out.println("                                  65432107                                  ");
		System.out.println("Staff : " + order.getStaffId());
		System.out.println("Table number : "+ order.getTableID());
		System.out.println(order.getDateTime().toString());
		System.out.println("============================================================================");
		for (int i = 0; i< foodOrder.size(); i++){
			Food food = foodOrder.get(i);
			int quantity = foodQuantity.get(i);
			System.out.printf("%-5d %-50s %-10.2f\n",quantity,food.getName(),food.getPrice());
		}
		for (int i = 0; i< promoSetOrder.size(); i++){
			PromoSet promoSet = promoSetOrder.get(i);
			int quantity = promoSetQuantity.get(i);
			System.out.printf("%-5d %-50s %-10.2f\n",  quantity, promoSet.getName(),promoSet.getPrice());
		}
		System.out.println("============================================================================");
		System.out.printf("%52s %10.2f\n","Total: ", order.getPrice());
		System.out.println();
		System.out.println("                         Thanks for dining with us!                         ");
		System.out.println();
		System.out.println("============================================================================");
	}

}
