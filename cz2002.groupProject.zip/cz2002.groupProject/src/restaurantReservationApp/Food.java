package restaurantReservationApp;



public class Food extends MenuItem{
	
	/**
	 *Enum for 14 categories.
	 */
	public static enum KindOfFood{
		ADVANCEDORDER,
		APPETIZER,
		SOUP,
		FISH,
		FRESHPRAWN,
		CLASSICZICHAR,
		VEGETABLE,
		EGGNTOFU,
		DESSERT,
		NOODLENRICE,
		HOTDRINK,
		COLDDRINK,
		FRESHJUICE,
		BEER
	};
	
	/**
	 * The category which this Food belongs
	 */
	private KindOfFood category;
	
	/**
	 * Creates a new Food with all the attributes.
	 * @param attributes
	 */
	public Food (String[] attributes){
		ID = Integer.parseInt(attributes[0]);
		category = KindOfFood.valueOf(attributes[1]);
		name = attributes[2];
		price = Double.parseDouble(attributes[3]);
		//description = attributes[4];
	}
	
	/**
	 * Creates a new Food with the given parameters.
	 * @param ID This Food's ID.
	 * @param name This Food's name.
	 * @param price This Food's price.
	 * @param category = index of enum KindOfItem + 1
	 * @param description This Food's description.
	 */
	public Food(int ID, String name, double price, int category, String description) {
		this.ID = ID;
		this.name = name;
		this.price = price;
		this.category = KindOfFood.values()[category-1];
		this.description = description;
	}

	/**
	 * Get the category of this Food.
	 * @return This Food's category: enum KindOfFood.
	 */
	public KindOfFood getCategory(){
		return category;
	}
	
	/**
	 * Format this Food to a string for display
	 */
	public String toString(){	
		String format = "%1$-5d %2$-20s %3$-50s %4$-10.2f";
		String output = String.format(format, this.ID, this.category, this.name, this.price);
		return output;
	}

	
}
