package restaurantReservationApp;


public class MenuItem {
	
	/**
	 * ID is unique 
	 */
	protected int ID;
	protected String name;
	protected double price;
	protected String description;
	
	public int getID(){
		return ID;
	}

	public void setID(int ID){
		this.ID= ID;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String getName(){
		return name;
	}
	
	public void setPrice(double price){
		this.price = price;
	}
	
	public double getPrice(){
		return price;
	}
	
	public void setDescription(String description) {
		this.description = description;
		
	}
}
