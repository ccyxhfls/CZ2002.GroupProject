package restaurantReservationApp;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Order {
	
	private int orderID;
	private double price;
	private int staffId;
	private ArrayList<Food> foodOrder = new ArrayList<Food>();
	private ArrayList<Integer> foodQuantity = new ArrayList<Integer>();
	private ArrayList<PromoSet> promoSetOrder = new ArrayList<PromoSet>();
	private ArrayList<Integer> promoSetQuantity = new ArrayList<Integer>();
	private LocalDate date;
	private LocalTime time;
	private int tableID;
	
	public Order(int orderID, int staffId, ArrayList<Food> foodOrder, ArrayList<Integer> foodQuantity, 
			ArrayList<PromoSet> promoSetOrder, ArrayList<Integer> promoSetQuantity, LocalDate date, LocalTime time, double price, int tableID){
		this.orderID = orderID;
		this.staffId = staffId;
		this.foodOrder = foodOrder;
		this.promoSetOrder = promoSetOrder;
		this.price = price;
		this.tableID = tableID;
		this.date = date;
		this.time = time;
	}
	
	public Order(int orderId, int tableId, int staffId){
		this.orderID = orderId;
		this.staffId = staffId;
		this.tableID = tableId;
		date = LocalDate.now();
		time = LocalTime.now();
	}
	
	public int getOrderID(){
		return orderID;
	}
	
	public void setOrderID(int orderID){
		this.orderID = orderID;
	}
	
	public double getPrice(){
		return price;
	}
	
	public void setPrice(double price){
		this.price = price;
	}
	
	public int getStaffId(){
		return staffId;
	}
	
	public void setStaff(int staffId){
		this.staffId = staffId;
	}
	
	public ArrayList<Food> getFoodOrder(){
		return foodOrder;
	}
	
	public ArrayList<Integer> getFoodQuantity(){
		return foodQuantity;
	}
	
	public void addFood(Food food, int num){
		if (foodOrder.contains(food)){
			int index = foodOrder.indexOf(food);
			int quantity = foodQuantity.get(index) + num;
			foodQuantity.add(index, quantity);
		}
		else{
			foodOrder.add(food);
			foodQuantity.add(num);
		}
		price += (food.getPrice()*num);
		System.out.println("Food successfully added to order!");
		
	}
	
	public int removeFood(Food food, int num){
		if (foodOrder.contains(food)){
			System.out.println("Food successfully removed from order!");
			int index = foodOrder.indexOf(food);
			int quantity = foodQuantity.get(index);
			if (quantity >= num){
				quantity -= num;
				if(quantity == 0){
					foodOrder.remove(index);
					foodQuantity.remove(index);
				}
				else{
					foodQuantity.add(index, quantity);
				}
				return 0;
			}
			else
				return -1;
		}
		return -1;
	}
	
	public ArrayList<PromoSet> getPromoSetOrder(){
		return promoSetOrder;
	}
	
	public ArrayList<Integer> getPromoSetQuantity(){
		return promoSetQuantity;
	}
	
	public void addPromoSet(PromoSet promoSet , int num){
		if (promoSetOrder.contains(promoSet)){
			int index = promoSetOrder.indexOf(promoSet);
			int quantity = promoSetQuantity.get(index) + num;
			promoSetQuantity.add(index, quantity);
		}
		else{
			promoSetOrder.add(promoSet);
			promoSetQuantity.add(num);
		}
		price += (promoSet.getPrice()*num);
		System.out.println("PromoSet successfully added to order!");
		
	}
	
	public int removePromoSet(PromoSet promoSet, int num){
		if (promoSetOrder.contains(promoSet)){
			System.out.println("PromoSet successfully removed from order!" );
			int index = promoSetOrder.indexOf(promoSet);
			int quantity = promoSetQuantity.get(index);
			if (quantity >= num){
				quantity -= num;
				if(quantity == 0){
					promoSetOrder.remove(index);
					promoSetQuantity.remove(index);
				}
				else{
					promoSetQuantity.add(index, quantity);
				}
				return 0;
			}
			else
				return -1;
		}
		return -1;
	}
	
	public int getTableID(){
		return tableID;
	}
	
	public void setTableID(int tableID){
		this.tableID = tableID;
	}

	public String getDateTime() {
		String dateTime = date.toString() + " " +time.toString();
		return dateTime;
	}

	
}
