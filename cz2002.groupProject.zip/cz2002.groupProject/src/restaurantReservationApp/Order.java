package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Order {
	
	private int orderID;
	private double price;
	private int staffId;
	private ArrayList<Food> foodOrder = new ArrayList<Food>();
	private ArrayList<Integer> foodQuantity = new ArrayList<Integer>();
	private ArrayList<PromoSet> promoSetOrder = new ArrayList<PromoSet>();
	private ArrayList<Integer> promoSetQuantity = new ArrayList<Integer>();
	private Calendar dateTime;
	private int tableID;
	
	public Order(int orderID, int staffId, ArrayList<Food> foodOrder, ArrayList<Integer> foodQuantity, 
			ArrayList<PromoSet> promoSetOrder, ArrayList<Integer> promoSetQuantity, Calendar dateTime, double price, int tableID){
		this.orderID = orderID;
		this.staffId = staffId;
		this.foodOrder = foodOrder;
		this.promoSetOrder = promoSetOrder;
		this.dateTime = dateTime;
		this.price = price;
		this.tableID = tableID;
	}
	
	public Order(int orderId, int tableId, int staffId){
		this.orderID = orderId;
		this.staffId = staffId;
		this.tableID = tableId;
	}
	
	public int getOrderID(){
		return orderID;
	}
	
	public void setOrderID(int orderID){
		this.orderID = orderID;
	}
	
	public double getPrice(){
		return price;
	}
	
	public void setPrice(double price){
		this.price = price;
	}
	
	public int getStaffId(){
		return staffId;
	}
	
	public void setStaff(int staffId){
		this.staffId = staffId;
	}
	
	public ArrayList<Food> getFoodOrder(){
		return foodOrder;
	}
	
	public ArrayList<Integer> getFoodQuantity(){
		return foodQuantity;
	}
	
	public void addFood(Food food, int num){
		if (foodOrder.contains(food)){
			int index = foodOrder.indexOf(food);
			int quantity = foodQuantity.get(index) + num;
			foodQuantity.add(index, quantity);
		}
		else{
			foodOrder.add(food);
			foodQuantity.add(num);
		}
		price += (food.getPrice()*num);
		System.out.println("Food successfully added to order!");
		
	}
	
	public int removeFood(Food food, int num){
		if (foodOrder.contains(food)){
			System.out.println("Food successfully removed from order!");
			int index = foodOrder.indexOf(food);
			int quantity = foodQuantity.get(index);
			if (quantity >= num){
				quantity -= num;
				if(quantity == 0){
					foodOrder.remove(index);
					foodQuantity.remove(index);
				}
				else{
					foodQuantity.add(index, quantity);
				}
				return 0;
			}
			else
				return -1;
		}
		return -1;
	}
	
	public ArrayList<PromoSet> getPromoSetOrder(){
		return promoSetOrder;
	}
	
	public ArrayList<Integer> getPromoSetQuantity(){
		return promoSetQuantity;
	}
	
	public void addPromoSet(PromoSet promoSet , int num){
		if (promoSetOrder.contains(promoSet)){
			int index = promoSetOrder.indexOf(promoSet);
			int quantity = promoSetQuantity.get(index) + num;
			promoSetQuantity.add(index, quantity);
		}
		else{
			promoSetOrder.add(promoSet);
			promoSetQuantity.add(num);
		}
		price += (promoSet.getPrice()*num);
		System.out.println("PromoSet successfully added to order!");
		
	}
	
	public int removePromoSet(PromoSet promoSet, int num){
		if (promoSetOrder.contains(promoSet)){
			System.out.println("PromoSet successfully removed from order!" );
			int index = promoSetOrder.indexOf(promoSet);
			int quantity = promoSetQuantity.get(index);
			if (quantity >= num){
				quantity -= num;
				if(quantity == 0){
					promoSetOrder.remove(index);
					promoSetQuantity.remove(index);
				}
				else{
					promoSetQuantity.add(index, quantity);
				}
				return 0;
			}
			else
				return -1;
		}
		return -1;
	}
	
	public Calendar getDateTime(){
		return dateTime;
	}
	
	public void setTime(Calendar dateTime){
		this.dateTime = dateTime;
	}
	
	public int getTableID(){
		return tableID;
	}
	
	public void setTableID(int tableID){
		this.tableID = tableID;
	}

	public void printOrder() {
		System.out.println("============================================================================");
		System.out.println("Order ID: " + orderID);
		System.out.println("Ala Carte");
		System.out.printf("%-5s %-50s %-10s\n", "ID", "Name", "Quantity");
		for (int i = 0; i< foodOrder.size(); i++){
			Food food = foodOrder.get(i);
			int quantity = foodQuantity.get(i);
			System.out.printf("%-5d %-50s %-10d\n",food.getID(),food.getName(), quantity);
		}
		System.out.println();
		System.out.println("SET");
		System.out.printf("%-5s %-50s %-10s\n", "ID", "Name", "Quantity");
		for (int i = 0; i< promoSetOrder.size(); i++){
			PromoSet promoSet = promoSetOrder.get(i);
			int quantity = promoSetQuantity.get(i);
			System.out.printf("%-5d %-50s %-10d\n",  promoSet.getID(), promoSet.getName(),quantity);
		}
		System.out.println("============================================================================");
	}
	
}
