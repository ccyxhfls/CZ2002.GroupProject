package restaurantReservationApp;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

public class Order {
	
	private Map<MenuItem, Integer> foodOrderList;
	private double price;
	private int orderID;
	private int tableID;
	private int staffId;
	private LocalDate date;
	private LocalTime time;
	
	
	public Order(int orderID, int staffId, LocalDate date, LocalTime time, double price, int tableID){
		this.orderID = orderID;
		this.staffId = staffId;
		this.price = price;
		this.tableID = tableID;
		this.date = date;
		this.time = time;
	}
	
	public Order(int orderId, int tableId, int staffId){
		foodOrderList = new HashMap<MenuItem, Integer>();
		this.orderID = orderId;
		this.staffId = staffId;
		this.tableID = tableId;
		date = LocalDate.now();
		time = LocalTime.now();
	}
	
	public Map<MenuItem, Integer> getOrderList() {
		return foodOrderList;
	}
	
	public int getOrderID(){
		return orderID;
	}
	
	public void setOrderID(int orderID){
		this.orderID = orderID;
	}
	
	public double getPrice(){
		return price;
	}
	
	public void setPrice(double price){
		this.price = price;
	}
	
	public int getStaffId(){
		return staffId;
	}
	
	public void setStaff(int staffId){
		this.staffId = staffId;
	}
	
	public int getTableID(){
		return tableID;
	}
	
	public void setTableID(int tableID){
		this.tableID = tableID;
	}
	
	
	public void addToOrder(MenuItem item, int quantity){
		double priceDiff = item.getPrice() * quantity;
		if (foodOrderList.containsKey(item))
			quantity += (int)foodOrderList.get(item);
		foodOrderList.put(item, quantity);
		price += priceDiff;
	}

	public int removeFromOrder (MenuItem item, int quantity){
		double priceDiff = item.getPrice() * quantity;
		if (foodOrderList.containsKey(item)){
			int q = (int)foodOrderList.get(item) - quantity;
			if (q > 0){
				foodOrderList.put(item, q);
				price -= priceDiff;
				return 0;
			}
		}
		return -1;
	}
	
	
	public String getDateTime() {
		String dateTime = date.toString() + " " +time.toString();
		return dateTime;
	}

	
	
}
