package restaurantReservationApp;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Map;

public class Order {
	
	private Map<MenuItem, Integer> foodOrderList = new HashMap<MenuItem, Integer>();
	private double price;
	private double totalPrice;
	private double gst;
	private double scharge;
	private int orderID;
	private int tableID;
	private int staffId;
	private LocalDate date;
	private LocalTime time;
	
	
	public Order(String[] attributes){
		this.orderID = Integer.parseInt(attributes[0]);
		this.staffId = Integer.parseInt(attributes[1]);
		this.tableID = Integer.parseInt(attributes[2]);
		this.date = LocalDate.parse(attributes[3]);
		this.time = LocalTime.parse(attributes[4]);
		this.price = Double.parseDouble(attributes[5]);
		this.gst = Double.parseDouble(attributes[6]);
		this.scharge = Double.parseDouble(attributes[7]);
		this.totalPrice = Double.parseDouble(attributes[8]);
	}
	
	public Order(int orderId, int tableId, int staffId){
		foodOrderList = new HashMap<MenuItem, Integer>();
		this.orderID = orderId;
		this.staffId = staffId;
		this.tableID = tableId;
		date = LocalDate.now();
		time = LocalTime.now();
	}
	
	public Map<MenuItem, Integer> getFoodList() {
		return foodOrderList;
	}
	
	public int getOrderID(){
		return orderID;
	}
	
	public void setOrderID(int orderID){
		this.orderID = orderID;
	}
	
	public double getPrice(){
		return price;
	}
	
	public void setPrice(double price){
		this.price = price;
	}
	
	public double getGST(){
		return gst;
	}
	
	public void setGST(double gst){
		this.gst = gst;
	}
	
	public double getScharge(){
		return scharge;
	}
	
	public void setScharge(double scharge){
		this.scharge = scharge;
	}
	
	public double getTotalPrice(){
		return totalPrice;
	}
	
	public void setTotalPrice(double totalPrice){
		this.totalPrice = totalPrice;
	}
	
	public int getStaffId(){
		return staffId;
	}
	
	public void setStaff(int staffId){
		this.staffId = staffId;
	}
	
	public int getTableID(){
		return tableID;
	}
	
	public void setTableID(int tableID){
		this.tableID = tableID;
	}
	
	
	public void addToOrder(MenuItem item, int quantity){
		double priceDiff = item.getPrice() * quantity;
		if (foodOrderList.containsKey(item))
			quantity += (int)foodOrderList.get(item);
		foodOrderList.put(item, quantity);
		price += priceDiff;
		double itemGST = priceDiff * 0.07;
		gst += itemGST;
		double itemSCharge = (priceDiff + itemGST)*0.1;
		scharge += itemSCharge;
		totalPrice += (priceDiff + itemGST + itemSCharge);
	}

	public int removeFromOrder (MenuItem item, int quantity){
		double priceDiff = item.getPrice() * quantity;
		if (foodOrderList.containsKey(item)){
			int q = (int)foodOrderList.get(item) - quantity;
			if (q > 0){
				foodOrderList.put(item, q);
				price -= priceDiff;
				gst -= priceDiff *0.07;
				scharge -= (priceDiff*1.07)*0.1;
				totalPrice -= price + gst + scharge;
				return 0;
			}
		}
		return -1;
	}
	
	
	public String getDateTime() {
		String dateTime = date.toString() + "," +time.toString();
		return dateTime;
	}
}
