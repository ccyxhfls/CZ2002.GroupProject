package restaurantReservationApp;

import restaurantReservationApp.Staff.Gender;

import java.util.ArrayList;
import java.util.Iterator;

public class StaffMgr {
	
	ArrayList<Staff> staffList;
	
	public StaffMgr(){
		staffList = new ArrayList<Staff>();
		FileMgr.loadStaff(this);
	}
	
	public Staff addStaff(String name, Gender gender, int empID, String jobTitle){
		Staff staff = new Staff(name, gender, empID, jobTitle);
		staffList.add(staff);
		return staff;
	}
	
	public Staff removeStaff (int empID){
		Staff staff = searchStaff(empID);
		staffList.remove(staff);
		return staff;
	}
	
	public Staff searchStaff(int empID){
		Iterator<Staff> itr = staffList.iterator();
		while(itr.hasNext()){
			Staff staff = itr.next();
			if (staff.getempID() == empID){
				return staff;
			}
		}
		return null;
	}
	
	public Staff updateName(int empID, String name){
		Staff staff = searchStaff(empID);
		staff.setName(name);
		return staff;
	}
	
	public Staff updateJobTitle(int empID, String jobTitle){
		Staff staff = searchStaff(empID);
		staff.setJobTitle(jobTitle);
		return staff;
	}

}
