package restaurantReservationApp;

import restaurantReservationApp.Staff.Gender;

import java.util.ArrayList;
import java.util.Iterator;

public class StaffMgr {
	
	ArrayList<Staff> staffList;
	
	public StaffMgr(){
		staffList = new ArrayList<Staff>();
		FileMgr.loadStaff(this);
	}
	
	/**
	 * Create a new Staff with given parameters and add that Staff to staffList
	 * @param name
	 * @param gender
	 * @param empID
	 * @param jobTitle
	 * @return
	 */
	public void addStaff(String name, Gender gender, int empID, String jobTitle){
		Staff staff = new Staff(name, gender, empID, jobTitle);
		staffList.add(staff);
	}
	
	/**
	 * Remove the Staff with corresponding ID from the staffList, return true if successful, otherwise return false 
	 * @param empID
	 * @return
	 */
	public boolean removeStaff (int empID){
		Staff staff = getStaffByID(empID);
		return staffList.remove(staff);
	}
	
	/**
	 * Find the Staff in the staffList with corresponding ID. If found, return the Staff,else, return null.
	 * @param empID
	 * @return
	 */
	public Staff getStaffByID(int empID){
		Iterator<Staff> itr = staffList.iterator();
		while(itr.hasNext()){
			Staff staff = itr.next();
			if (staff.getempID() == empID){
				return staff;
			}
		}
		return null;
	}
	
	public Staff updateName(int empID, String name){
		Staff staff = getStaffByID(empID);
		staff.setName(name);
		return staff;
	}
	
	public Staff updateJobTitle(int empID, String jobTitle){
		Staff staff = getStaffByID(empID);
		staff.setJobTitle(jobTitle);
		return staff;
	}

}
