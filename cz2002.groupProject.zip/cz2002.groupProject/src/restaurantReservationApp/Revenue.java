package restaurantReservationApp;

import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeParseException;
import java.time.temporal.TemporalAdjuster;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Revenue {
	private Scanner sc = new Scanner(System.in);
	
	/**
	 * Get orderList from orderMgr
	 */
	ArrayList<Order> orderList;
	
	
	public Revenue(ArrayList<Order> orderList) {
		this.orderList = orderList;
	}

	/**
	 * For Orders created later than the starting date, merge the orders according to food type. i.e: sum the total quantity for each Food/PromoSet
	 * @param date
	 * @return
	 */
	private Map<MenuItem, Integer> collateOrderByFood () {
		Map<MenuItem, Integer> collateOrder = new HashMap<MenuItem, Integer>();
		for (Order order : orderList){
			order.getFoodList().forEach((k, v) -> collateOrder.merge(k, v, Integer::sum));
		}
		
		return collateOrder;
	}
	
	/**
	 * Print the revenue by food
	 * @param collatedOrder
	 */
	public void printRevByFood(Map<MenuItem, Integer> collatedOrder){
		Set<MenuItem> itemSet = collatedOrder.keySet();
		double total = 0;
		System.out.println("============================================================================");
		System.out.println("                                Sale Revenue                                ");
		System.out.println("============================================================================");
		System.out.println("                               SCSE RESTAURANT                              ");
		System.out.println("                               Nanyang Avenue                               ");
		System.out.println("                                  65432107                                  ");
		System.out.println("============================================================================");
		
		for(MenuItem item: itemSet){
			System.out.printf("%-50s %-10.2f %-5d\n", item.getName(),  item.getPrice(), collatedOrder.get(item));
			total += item.getPrice() * collatedOrder.get(item);
		}
		System.out.println("============================================================================");
		System.out.printf("%52s %10.2f\n","Total: ", total);
		System.out.println();
		System.out.println();
		System.out.println("============================================================================");
	}

	/**
	 * Get user input to print revenue by day/month/food
	 * 
	 */
	public void printSaleRevUI() {
		try{
			int c;
			do{
				System.out.println("1: Print sale revenue by day");
				System.out.println("2: Print sale revenue by month" );
				System.out.println("3. Print sale revenue by food");
				System.out.println("4: Back");
				c = sc.nextInt();
				LocalDate date;
				switch (c){
					case 1:
						Map<TemporalAdjuster, ArrayList<Order>> dailyOrders = collateRevByDay();
						printRevByPeriod(toString(dailyOrders));
						break;
					case 2:
						Map<TemporalAdjuster, ArrayList<Order>> monthlyOrders = collateRevByMonth();
						printRevByPeriod(toString(monthlyOrders));
						break;
					case 3:
						printRevByFood(collateOrderByFood());
						break;
					case 4:
						break;
					default:
						System.out.println("Error: invalid input!");
						break;
					
				}
			} while (c != 4);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			printSaleRevUI();
		}
	}
	
	
	/**
	 * Merge the Orders on the same day to one single order
	 * @param start
	 * @return
	 */
	private Map<TemporalAdjuster, ArrayList<Order>> collateRevByDay() {
		Map<TemporalAdjuster, ArrayList<Order>> dailyOrders = new HashMap<TemporalAdjuster, ArrayList<Order>>();
		
		for (Order order: orderList){
			LocalDate date = order.getDate();
			if (dailyOrders.get(date) == null){
				dailyOrders.put(date, new ArrayList<Order>());
			}
			dailyOrders.get(date).add(order);
		
		}
		return dailyOrders;
		
		
	}
	

	/**
	 * Convert the collated order to string for printing
	 * @param collatedOrder
	 * @return
	 */
	private ArrayList<String> toString (Map<TemporalAdjuster, ArrayList<Order>> collatedOrder){
		ArrayList<String> dailyDetails = new ArrayList<String>();
		for (TemporalAdjuster t: collatedOrder.keySet()){
			ArrayList<Order> orderList = collatedOrder.get(t);
			double total = 0;
			for (Order order: orderList){
				total += order.getPrice();
			}
			String detail = t.toString() + "," + orderList.size() + "," + total;
			dailyDetails.add(detail);
		}
		return dailyDetails;
	}
	
	/**
	 * Merge the Orders on the same month to one single order
	 * @param start
	 * @return
	 */
	private Map<TemporalAdjuster, ArrayList<Order>> collateRevByMonth (){
		Map<TemporalAdjuster, ArrayList<Order>> monthlyOrders = new HashMap <TemporalAdjuster, ArrayList<Order>>();
		Map<TemporalAdjuster, ArrayList<Order>> dailyOrders = collateRevByDay();
		
		for (TemporalAdjuster date: dailyOrders.keySet()){
			Month month = ((LocalDate) date).getMonth();
			if (monthlyOrders.get(month) == null){
				monthlyOrders.put(month, new ArrayList<Order>());
			}
			monthlyOrders.get(month).addAll(dailyOrders.get(date));	
		}
		return monthlyOrders;
	}


	/**
	 * Print revenue by period (day/month)
	 * @param details
	 */
	public void printRevByPeriod(ArrayList<String> details) {
		
		System.out.println("============================================================================");
		System.out.println("                                Sale Revenue                                ");
		System.out.println("============================================================================");
		System.out.println("                               SCSE RESTAURANT                              ");
		System.out.println("                               Nanyang Avenue                               ");
		System.out.println("                                  65432107                                  ");
		System.out.println("============================================================================");
		System.out.printf("%-20s %-20s %-20s\n","Date", "Total Order", "Total Revenue");
		for (String day : details){
			String[] detail = day.split(","); 
			System.out.printf("%-20s %-20s %-20s\n",detail[0], detail[1], detail[2]);
		}
		System.out.println("============================================================================");
		System.out.println();
		System.out.println();
		System.out.println("============================================================================");
		
	}


		
	



}
