package restaurantReservationApp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Iterator;

import restaurantReservationApp.Staff.Gender;

public class FileMgr {

	public static void loadFood(FoodMgr foodMgr) {
		String fileName = "foodDB.txt";
		Path pathToFile = Paths.get(fileName);
		try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.UTF_8)){
			String line = br.readLine();
			while(line != null){
				String[] attributes = line.split(",");
				foodMgr.addFood(new Food(attributes));
				line = br.readLine();
			}
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	}
	
	public static void writeFood(ArrayList <Food> foodList){
		try {
			FileWriter fwStream = new FileWriter("foodDB.txt");
			BufferedWriter bwStream = new BufferedWriter(fwStream);
			PrintWriter pwStream = new PrintWriter(bwStream);
			Iterator<Food> itr = foodList.iterator();
			while(itr.hasNext()){
				Food food = itr.next();
				pwStream.println(food.getID()+","+food.getCategory().toString()+","+food.getName()+","+food.getPrice());
			}
			pwStream.close();
		}
		catch(IOException e){
			System.out.println("IO Error!" + e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}
		
	}

	public static void loadPromoSet(PromoSetMgr promoSetMgr) {
		String fileName = "promoSetDB.txt";
		Path pathToFile = Paths.get(fileName);
		try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.UTF_8)){
			int numOfSet = Integer.parseInt(br.readLine());
			for (int i = 0; i < numOfSet; i++){
				String line = br.readLine();
				int setID = Integer.parseInt(line);
				PromoSet promoSet = new PromoSet(setID);
				promoSet.setName(br.readLine());
				int numOfFood = Integer.parseInt(br.readLine());
				for (int j = 0; j< numOfFood; j++){
					String foodStr = br.readLine();
					String[] attributes = foodStr.split(",");
					int foodID = Integer.parseInt(attributes[0]);
					Food food = FoodMgr.searchFood(foodID);
					promoSet.addFood(food);
				}
				double discountPrice = Double.parseDouble(br.readLine());
				promoSet.setPrice(discountPrice);
				promoSetMgr.AddPromoSet(promoSet);
			}
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	}
	
	public static void writePromoSet(ArrayList<PromoSet> promoSetList){
		try {
			FileWriter fwStream = new FileWriter("promoSetDB.txt");
			BufferedWriter bwStream = new BufferedWriter(fwStream);
			PrintWriter pwStream = new PrintWriter(bwStream);
			pwStream.println(promoSetList.size());
			Iterator<PromoSet> itr = promoSetList.iterator();
			while(itr.hasNext()){
				PromoSet promoSet = itr.next();
				pwStream.println(promoSet.getID());
				pwStream.println(promoSet.getName());
				ArrayList<Food> foodList = promoSet.getFoodList();
				pwStream.println(foodList.size());
				for(Food food: foodList)
					pwStream.println(food.getID()+","+food.getCategory().toString()+","+food.getName()+","+food.getPrice());
				pwStream.println(promoSet.getPrice());
			}
			pwStream.close();
		}
		catch(IOException e){
			System.out.println("IO Error!" + e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}
		
	}
	
	public static void loadTables(Table[] tables){
		String fileName = "tableDB.txt";
		Path pathToFile  = Paths.get(fileName);
		int count = 0;
		String line = null;
		try(BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.UTF_8)){
			while((line = br.readLine()) != null){
				String[] tableInfo = line.split(",");
				int tableID = (Integer.parseInt(tableInfo[0]));
				int Capacity = (Integer.parseInt(tableInfo[1]));
				String status = (tableInfo[2]);
				tables[count] = new Table (tableID, Capacity, status);
				count += 1;
			}
		}catch(IOException e){
			System.out.println(e.getMessage());
			System.out.println(e.getClass());
		}
	}
	
	public static void writeTable(Table[] tables){
		try {
			FileWriter fwStream = new FileWriter("tableDB.txt");
			BufferedWriter bwStream = new BufferedWriter(fwStream);
			PrintWriter pwStream = new PrintWriter(bwStream);
			for (Table table:tables){
				pwStream.println(table.getTableID()+","+table.getCapacity() + "," + table.getStatus() );
			}
			pwStream.close();
		}
		catch(IOException e){
			System.out.println("IO Error!" + e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}
		
	}
	
	public static void loadReservationMatrix(ReservationMgr reservationMgr){
		String fileName = "reservationDB.txt";
		File file = new File(fileName);
		try{
			FileReader fr = new FileReader(file.getAbsoluteFile());
			BufferedReader br = new BufferedReader(fr);
			String resInfo;
			try{
				while((resInfo = br.readLine()) != null){
					String[] segmentInfo = resInfo.split(",");
					Reservation res = new Reservation(segmentInfo);
					if (res.getArrDate().compareTo(LocalDate.now()) > 0)
						reservationMgr.addReservation(segmentInfo);
					reservationMgr.deleteExpiredRes();
				}
				br.close();
			}catch (IOException e){
				e.printStackTrace();
			}
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}
	}
	
	public static void writeReservation(Reservation[][][] matrix){
		try {
			FileWriter fwStream = new FileWriter("reservationDB.txt");
			BufferedWriter bwStream = new BufferedWriter(fwStream);
			PrintWriter pwStream = new PrintWriter(bwStream);
			for (int i = 0; i< 30; i++){
				for (int j = 0; j < 30; j++){
					for (int k= 0; k< 2; k++){
						if (matrix[i][j][k] != null){
							Reservation res = matrix[i][j][k];
							pwStream.println(res.getCustName() + "," +res.getHp()+ "," + res.getPax() + ","+ res.getTableId() + "," + res.getArrDate().toString() + "," + res.getArrTime().toString());
						}
							
							
					}
				}
			}
			pwStream.close();
		}
		catch(IOException e){
			System.out.println("IO Error!" + e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}
		
	}
	public static void writeStaff(ArrayList <Staff> staffList){
		try {
			FileWriter fwStream = new FileWriter("StaffDB.txt");
			BufferedWriter bwStream = new BufferedWriter(fwStream);
			PrintWriter pwStream = new PrintWriter(bwStream);
			Iterator<Staff> itr = staffList.iterator();
			while(itr.hasNext()){
				Staff staff = itr.next();
				pwStream.println(staff.getName()+","+staff.getGender()+","+staff.getempID()+","+staff.getJobTitle());
			}
			pwStream.close();
		}
		catch(IOException e){
			System.out.println("IO Error!" + e.getMessage());
			e.printStackTrace();
			System.exit(0);
		}
		
	}
	
	public static void loadStaff(StaffMgr sm){
		try {
			FileReader frStream = new FileReader("StaffDB.txt");
			BufferedReader brStream = new BufferedReader(frStream);
			String str;

			while ((str = brStream.readLine()) != null){
				String [] staff = str.split(",");
				String name = staff[0];
				Gender gender = Gender.valueOf(staff[1]);
				int id = Integer.parseInt(staff[2]);
				String job = staff[3];
	
				sm.addStaff(name, gender, id, job);
			}
			brStream.close();
		}
		catch(FileNotFoundException e){
			System.out.println("Error opening the input file!" + e.getMessage());
			System.exit(0);
		}
		catch (IOException e) {
			e.printStackTrace();
		}
	}
}
