package restaurantReservationApp;


public interface Menu {
	public void add(MenuItem item);
	public int remove(MenuItem item);
	public int update(MenuItem item, int choice, String value);
}
