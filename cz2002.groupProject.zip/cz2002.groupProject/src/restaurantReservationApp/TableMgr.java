package restaurantReservationApp;

import java.time.*;


public class TableMgr {
	/**
	 * Array of Tables in the restaurant
	 */
	private Table[] tables;
	private int tableNum;
	public ReservationMgr reservationMgr;
	
	/**
	 * Initiate Table[] tables from database
	 */
	public TableMgr(){ // always pass in (30,30) in this project
		this.tableNum = 30;
		tables = new Table[tableNum];
		FileMgr.loadTables(tables);
		reservationMgr = new ReservationMgr(this);
		resetReservedTable(LocalTime.now().getHour() < 15);		
	}

	/**
	 * Delete the expired reservations and reset tables
	 * @param AM
	 */
	public void resetReservedTable(boolean AM){
		reservationMgr.deleteExpiredRes();
		reservationMgr.setTables(tables, AM);
	}
	
	/**
	 * Find an available table to accommodate given number of diners.
	 * If found, change status of the Table to "occupied". Otherwise, return -1.
	 * @param pax
	 * @return
	 */
	public int assignTable(int pax) {
		resetReservedTable(LocalTime.now().getHour() < 15);
		for (int i = 0 ; i< tableNum; i++){
			if (tables[i].getCapacity() >= pax && tables[i].getStatus().equalsIgnoreCase("vacant")){
				tables[i].changeStatus("occupied");
				return tables[i].getTableID();
			}	
		}
		System.out.println("Sorry, there is no available table.");
		return -1;
	}
	
	/**
	 * Print the current status of the tables
	 */
	public void printTableStatus(){
		resetReservedTable(LocalTime.now().getHour() < 15);
		System.out.printf("%-8s | %-8s | %-10s\n", "Table", "Capacity", "Status" );
		for (int i = 0; i < tableNum; i++){
			System.out.printf("%-8d | %-8d | %-10s\n", tables[i].getTableID(),tables[i].getCapacity(), tables[i].getStatus());
		}
	}

	
	public int getCapacity(int i) {
		return tables[i].getCapacity();
	}


	public int getTableID(int i) {
		return tables[i].getTableID();
	}


	/**
	 * Change the status of the table with corresponding table index.
	 * @param tableIndex
	 * @param status
	 */
	public void changeStatus(int tableIndex, String status) {
		tables[tableIndex].changeStatus(status);
	}

	/**
	 * Get status of the table with corresponding table index.
	 * @param tableIndex
	 * @return
	 */
	public String getStatus(int tableIndex) {
		return tables[tableIndex].getStatus();
	}
	/**
	 * Update database
	 */
	public void updateDB() {
		FileMgr.writeTable(tables);
	}

	
	
	
}
