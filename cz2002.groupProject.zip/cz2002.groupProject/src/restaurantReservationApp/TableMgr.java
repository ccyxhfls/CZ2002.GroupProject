package restaurantReservationApp;

import java.time.*;

// !!need a function at main system to switch between AM and PM session to activate the reservation status.
// IMPORTANT REMINDER
public class TableMgr {
	private Table[] tables;
	private int tableNum;
	public ReservationMgr reservationMgr;
	
	public TableMgr(){ // always pass in (30,30) in this project
		this.tableNum = 30;
		tables = new Table[tableNum];
		FileMgr.loadTables(tables);
		reservationMgr = new ReservationMgr(this);
		resetReservedTable(LocalTime.now().getHour() < 15);		
	}

	
	public void resetReservedTable(boolean AM){
		if (reservationMgr == null)
			return;
		reservationMgr.deleteExpiredRes();
		reservationMgr.setTables(tables, AM);
	}
	
	public int assignTable(int pax) {
		resetReservedTable(LocalTime.now().getHour() < 15);
		for (int i = 0 ; i< tableNum; i++){
			if (tables[i].getCapacity() >= pax && tables[i].getStatus().equalsIgnoreCase("vacant")){
				tables[i].changeStatus("occupied");
				return tables[i].getTableID();
			}	
		}
		System.out.println("Sorry, there is no available table.");
		return -1;
	}

	
	public int getCapacity(int i) {
		return tables[i].getCapacity();
	}


	public int getTableID(int i) {
		return tables[i].getTableID();
	}
	
	public void printTableStatus(){
		System.out.printf("%-8s | %-8s | %-10s\n", "Table", "Capacity", "Status" );
		for (int i = 0; i < tableNum; i++){
			System.out.printf("%-8d | %-8d | %-10s\n", tables[i].getTableID(),tables[i].getCapacity(), tables[i].getStatus());
		}
	}


	public void changeStatus(int tableIndex, String status) {
		tables[tableIndex].changeStatus(status);
	}


	public void updateDB() {
		FileMgr.writeTable(tables);
	}
}
