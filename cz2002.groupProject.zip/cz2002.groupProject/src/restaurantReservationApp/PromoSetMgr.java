package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Iterator;

import exceptions.ItemNotFoundException;


public class PromoSetMgr {
	private static ArrayList<PromoSet> promoSetList = new ArrayList<PromoSet>();

	public PromoSetMgr(){
		FileMgr.loadPromoSet(this);
	}
	
	
	public void addPromoSet(int ID, String name, String foodListStr, double price, String description) {
		ArrayList<Food> foodList = new ArrayList<Food>();
		String[] IDList = foodListStr.split(" ");
		for (int i = 0; i < IDList.length; i++){
			Food food = FoodMgr.searchFood(Integer.parseInt(IDList[i]));
			foodList.add(food);
		}
		PromoSet promoSet = new PromoSet(ID, name, foodList, price, description);
		promoSetList.add(promoSet);
		System.out.println("PromoSet successfully added!");
		promoSet.print();
	}
	
	public void AddPromoSet(PromoSet promoSet) {
		promoSetList.add(promoSet);	
	}

	
	public PromoSet removePromoSet(int ID){
		PromoSet promoSet = searchPromoSet(ID);
		promoSetList.remove(promoSet);
		return promoSet;
	}
	
	public static PromoSet searchPromoSet(int ID){
		Iterator<PromoSet> itr = promoSetList.iterator();
		while(itr.hasNext()){
			PromoSet promoSet = itr.next();
			if (promoSet.getID() == ID){
				return promoSet;
			}
		}
		System.out.println("Error: promotion set not found!");
		return null;
	}
	
	public PromoSet addFood (int ID, Food food){
		PromoSet promoSet = searchPromoSet(ID);
		promoSet.addFood(food);
		return promoSet;
	}
	
	public PromoSet removeFood (int ID, Food food){
		PromoSet promoSet = searchPromoSet(ID);
		promoSet.removeFood(food);
		return promoSet;
	}
	
	public void printPromoSets(){
		Iterator<PromoSet> itr = promoSetList.iterator();
		while(itr.hasNext()){
			PromoSet promoSet = itr.next();
			promoSet.print();
		}
	}

	public void updatePromoSet(int ID, int choice, String value){
		PromoSet promoSet = searchPromoSet(ID);
		switch(choice){
		case 1: 
			promoSet.setName(value);
			break;
		case 2:
			promoSet.setPrice(Double.parseDouble(value));
			break;
		case 3:
			promoSet.setDescription(value);
			break;
		}
		System.out.println("PromoSet successfully updated! ");
		promoSet.print();
	}


	

	
}
