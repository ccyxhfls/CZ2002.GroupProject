package restaurantReservationApp;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;



public class PromoSetMgr {
	private Scanner sc = new Scanner(System.in);
	
	/**
	 * Array list which contains all the promotional sets
	 */
	private static ArrayList<PromoSet> promoSetList = new ArrayList<PromoSet>();
	

	/**
	 * Initiate promoSetList by calling "loadPromoSet" function in FileMgr
	 */
	public PromoSetMgr(){
		FileMgr.loadPromoSet(this);
	}
	
	
	/**
	 * Create a promotional set with given parameters
	 * @param ID
	 * @param name
	 * @param foodListStr: String of food IDs, will be parsed and find corresponding Food using "FoodMgr.getFoodByID(int id)" function
	 * @param price
	 * @param description
	 * @throws ItemNotFoundException
	 */
	public void addPromoSet(int ID, String name, String foodListStr, double price, String description) throws ItemNotFoundException {
		ArrayList<Food> foodList = new ArrayList<Food>();
		String[] IDList = foodListStr.split(" ");
		for (int i = 0; i < IDList.length; i++){
			Food food = FoodMgr.getFoodByID(Integer.parseInt(IDList[i]));
			if (food == null)
				throw new ItemNotFoundException("food");
			foodList.add(food);
		}
		PromoSet promoSet = new PromoSet(ID, name, foodList, price, description);
		promoSetList.add(promoSet);
		System.out.println("PromoSet successfully added!");
		printPromoSet(promoSet);
	}
	
	/*
	 * Add the PromoSet to promoSetList
	 */
	public void AddPromoSet(PromoSet promoSet) {
		promoSetList.add(promoSet);	
	}

	/**
	 * If promoSetList contains the PromoSet, remove it, return 0;
	 * Else return -1;
	 * @param promoSet
	 */
	public int removePromoSet(PromoSet promoSet){
		if(!promoSetList.remove(promoSet))
			return -1;
		return 0;
	}
	
	/**
	 * Get the PromoSet with corresponding ID, if not found, return null
	 * @param ID
	 * @return
	 */
	public static PromoSet getPromoSetByID(int ID){
		Iterator<PromoSet> itr = promoSetList.iterator();
		while(itr.hasNext()){
			PromoSet promoSet = itr.next();
			if (promoSet.getID() == ID){
				return promoSet;
			}
		}
		return null;
	}
	
	/**
	 * Print all the promotional sets
	 */
	public void printPromoSets(){
		Iterator<PromoSet> itr = promoSetList.iterator();
		while(itr.hasNext()){
			PromoSet promoSet = itr.next();
			printPromoSet(promoSet);
		}
	}

	/**
	 * If promoSetList contains the PromoSet, update it, return 0;
	 * Else, return -1
	 * @param promoSet
	 * @param choice: 1. updateName; 2. updatePrice; 3. updateDescription
	 * @param value
	 */
	public int updatePromoSet(PromoSet promoSet, int choice, String value){
		if(!promoSetList.contains(promoSet))
			return -1;
		switch(choice){
		case 1: 
			promoSet.setName(value);
			break;
		case 2:
			promoSet.setPrice(Double.parseDouble(value));
			break;
		case 3:
			promoSet.setDescription(value);
			break;
		}
		System.out.println("PromoSet successfully updated! ");
		printPromoSet(promoSet);
		return 0;
	}
	
	/**
	 * Print the details of the PromoSet
	 * @param promoSet
	 */
	public void printPromoSet(PromoSet promoSet){
		ArrayList<Food> foodList = promoSet.getFoodList();
		System.out.println("---------------------------------------------------------------------------------------------");
		System.out.println("Set ID:" + promoSet.getID());
		System.out.println("Name: " + promoSet.getName());
		
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			System.out.println(food.toString());
		}
		System.out.println("discount price:" + promoSet.getPrice());
		System.out.println("---------------------------------------------------------------------------------------------");
	}


	/*
	 * Update "promoSet.txt"
	 */
	public void updateDB() {
		FileMgr.writePromoSet(promoSetList);
	}

	/**
	 * User interface for
	 * 1. create PromoSet; 2.update PromoSet; 3. Remove promoSet; 4. Print all promoSet
	 * @throws ItemNotFoundException
	 */
	public void promoSetUI() throws ItemNotFoundException {
		System.out.println("1: Create promotion");
		System.out.println("2: Update promotion");
		System.out.println("3: Remove promotion");
		System.out.println("4: Print promotion");
		System.out.println("5: Quit");
		int c;
		try{
			c= sc.nextInt();
		
			switch(c)
			{
				case 1://add promoset
					addPromoSetUI();
					break;
				case 2://update promoset//
					updatePromoSetUI();
					break;
				case 3://remove promoSet
					removePromoSetUI();
					break;
				case 4: //print promoSet
					printPromoSets();
					break;
				case 5: // quit
					break;
				default:
					System.out.println("Error: invalid input!");
					break;
			}
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			promoSetUI();
		}
	}

	/**
	 * User interface to remove promoSet
	 * Get user input: promoSet ID
	 * @throws ItemNotFoundException
	 */
	private void removePromoSetUI() throws ItemNotFoundException {
		try{
			System.out.print("Enter the promotion id:");
			int id=sc.nextInt();
			PromoSet promoSet = getPromoSetByID(id);
			if( promoSet == null){
				throw new ItemNotFoundException("promotional set");
			}
			removePromoSet(promoSet);
			System.out.println("Remove successfully!");
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			removePromoSetUI();
		}
	}

	/**
	 * User interface to update promoSet
	 * Get user input: 1. promoSet ID; 2. choice of attribute to be updated; 3. new value
	 * @throws ItemNotFoundException 
	 *
	 */
	private void updatePromoSetUI() throws ItemNotFoundException {
		try{
			System.out.print("Enter the promotion id:");
			int id=sc.nextInt();
			PromoSet promoSet = getPromoSetByID(id);
			if( promoSet == null){
				throw new ItemNotFoundException("promotional set");
			}
			int c;
			do
			{
				System.out.println("1: Update name");
				System.out.println("2: Update price");
				System.out.println("3: Update description");
				System.out.println("4: Quit");
				c= sc.nextInt();
				if (c>0 && c<4)
				{
					sc.nextLine(); //flush
					System.out.println("New value");
					String value = sc.nextLine();
					updatePromoSet(promoSet, c, value);
				}
			}while(c>0 && c<4);
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			updatePromoSetUI();
		}
		
	}

	/**
	 * User interface to create a PromoSet
	 * Get user input: 1. ID; 2. name; 3. list of food IDs (String); 4. price; 5. description
	 * @throws ItemNotFoundException: if the food list contains invalid food ID
	 */
	private void addPromoSetUI() throws ItemNotFoundException {
		try{
			System.out.println("ID:");
			int id = sc.nextInt();
			if (getPromoSetByID(id) != null){
				System.out.println("Error: promoSet ID exist");
				return;
			}
			sc.nextLine(); //flush
			System.out.print("Name:");
			String name =sc.nextLine();
			System.out.println("food list");
			String foodListStr = sc.nextLine();
			System.out.print("Price:");
			double price=sc.nextDouble();
			sc.nextLine(); //flush
			System.out.print("Description:");
			String description =sc.nextLine();
			addPromoSet(id, name, foodListStr, price, description);	
		}catch(InputMismatchException e){
			System.out.println("Error: invalid input");
			sc.nextLine();
			addPromoSetUI();
		}
	}

	

	
}
