package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;



public class PromoSetMgr {
	private static ArrayList<PromoSet> promoSetList = new ArrayList<PromoSet>();
	private Scanner sc = new Scanner(System.in);

	public PromoSetMgr(){
		FileMgr.loadPromoSet(this);
	}
	
	
	public void addPromoSet(int ID, String name, String foodListStr, double price, String description) {
		ArrayList<Food> foodList = new ArrayList<Food>();
		String[] IDList = foodListStr.split(" ");
		for (int i = 0; i < IDList.length; i++){
			Food food = FoodMgr.searchFood(Integer.parseInt(IDList[i]));
			foodList.add(food);
		}
		PromoSet promoSet = new PromoSet(ID, name, foodList, price, description);
		promoSetList.add(promoSet);
		System.out.println("PromoSet successfully added!");
		printPromoSet(promoSet);
	}
	
	public void AddPromoSet(PromoSet promoSet) {
		promoSetList.add(promoSet);	
	}

	
	public void removePromoSet(PromoSet promoSet){
		promoSetList.remove(promoSet);
	}
	
	public static PromoSet searchPromoSet(int ID){
		Iterator<PromoSet> itr = promoSetList.iterator();
		while(itr.hasNext()){
			PromoSet promoSet = itr.next();
			if (promoSet.getID() == ID){
				return promoSet;
			}
		}
		return null;
	}
	
	public void printPromoSets(){
		Iterator<PromoSet> itr = promoSetList.iterator();
		while(itr.hasNext()){
			PromoSet promoSet = itr.next();
			printPromoSet(promoSet);
		}
	}

	public void updatePromoSet(PromoSet promoSet, int choice, String value){
		switch(choice){
		case 1: 
			promoSet.setName(value);
			break;
		case 2:
			promoSet.setPrice(Double.parseDouble(value));
			break;
		case 3:
			promoSet.setDescription(value);
			break;
		}
		System.out.println("PromoSet successfully updated! ");
		printPromoSet(promoSet);
	}
	
	public void printPromoSet(PromoSet promoSet){
		ArrayList<Food> foodList = promoSet.getFoodList();
		System.out.println("---------------------------------------------------------------------------------------------");
		System.out.println("Set ID:" + promoSet.getID());
		System.out.println("Name: " + promoSet.getName());
		
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			System.out.println(food.toString());
		}
		System.out.println("discount price:" + promoSet.getPrice());
		System.out.println("---------------------------------------------------------------------------------------------");
	}


	public void updateDB() {
		FileMgr.writePromoSet(promoSetList);
	}

	public void promoSetUI() throws ItemNotFoundException {
		System.out.println("1: Create promotion");
		System.out.println("2: Update promotion");
		System.out.println("3: Remove promotion");
		System.out.println("4: Print promotion");
		System.out.println("5: Quit");
		int c = sc.nextInt();
		switch(c)
		{
			case 1://add promoset
				addPromoSetUI();
				break;
			case 2://update promoset//
				updatePromoSetUI();
				break;
			case 3://remove promoSet
				removePromoSetUI();
				break;
			case 4: //print promoSet
				printPromoSets();
				break;
			case 5: // quit
				break;
			default:
				System.out.println("Error: invalid input!");
				break;
		}			
	}

	private void removePromoSetUI() throws ItemNotFoundException {
		System.out.print("Enter the promotion id:");
		int id=sc.nextInt();
		PromoSet promoSet = searchPromoSet(id);
		if( promoSet == null){
			throw new ItemNotFoundException("promotional set");
		}
		removePromoSet(promoSet);
		System.out.println("Remove successfully!");
	}

	private void updatePromoSetUI() {
		System.out.print("Enter the promotion id:");
		int id=sc.nextInt();
		PromoSet promoSet = searchPromoSet(id);
		if( promoSet == null){
			System.out.println("Error: promotional set not found!");
			return;
		}
		int c;
		do
		{
			System.out.println("1: Update name");
			System.out.println("2: Update price");
			System.out.println("3: Update description");
			System.out.println("4: Quit");
			c= sc.nextInt();
			if (c>0 && c<4)
			{
				sc.nextLine(); //flush
				System.out.println("New value");
				String value = sc.nextLine();
				updatePromoSet(promoSet, c, value);
			}
		}while(c>0 && c<4);
		
	}

	private void addPromoSetUI() {
		System.out.println("ID:");
		int id = sc.nextInt();
		if (searchPromoSet(id) != null){
			System.out.println("Error: promoSet ID exist");
			return;
		}
		sc.nextLine(); //flush
		System.out.print("Name:");
		String name =sc.nextLine();
		System.out.println("food id list:");
		String foodListStr = sc.nextLine();
		System.out.print("Price:");
		double price=sc.nextDouble();
		sc.nextLine(); //flush
		System.out.print("Description:");
		String description =sc.nextLine();
		addPromoSet(id, name, foodListStr, price, description);	
	}

	

	
}
