package restaurantReservationApp;

public class ItemNotFoundException extends Exception {
	public ItemNotFoundException(){
		super("Error: item not found!");
	}
	public ItemNotFoundException(String message){
		super(message);
	}
}
