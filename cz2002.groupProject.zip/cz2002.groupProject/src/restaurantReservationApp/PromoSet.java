package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Iterator;

public class PromoSet extends MenuItem {
	ArrayList<Food> foodList;

	public PromoSet(int ID, String name, ArrayList<Food> foodList, double price, String description) {
		this.ID = ID;
		this.name = name;
		this.foodList = foodList;
		this.price = price;
		this.description = description;
		
	}
	
	public PromoSet(int ID){
		this.ID = ID;
		foodList = new ArrayList<Food>();
	}
	
	public ArrayList<Food> getFoodList() {
		return foodList;
	}
	

	public void addFood(Food food){
		foodList.add(food);
		price += food.getPrice();
	}
	
	public void removeFood(Food food){
		foodList.remove(food);
		price -= food.getPrice();
	}
/*
	public void print() {
		System.out.println("---------------------------------------------------------------------------------------------");
		System.out.println("Set ID:" + ID);
		System.out.println("Name: " + name);
		
		Iterator<Food> itr = foodList.iterator();
		while(itr.hasNext()){
			Food food = itr.next();
			System.out.println(food.toString());
		}
		System.out.println("discount price:" + price);
		System.out.println("---------------------------------------------------------------------------------------------");

	}
	*/


	
	
	
}
