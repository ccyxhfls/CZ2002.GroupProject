package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Iterator;

public class PromoSet extends MenuItem {
	/**
	 * Promotional set contains array list of Food
	 */
	ArrayList<Food> foodList;

	/**
	 * Create a PromoSet with given parameters
	 * @param ID
	 * @param name
	 * @param foodList
	 * @param price
	 * @param description
	 */
	public PromoSet(int ID, String name, ArrayList<Food> foodList, double price, String description) {
		this.ID = ID;
		this.name = name;
		this.foodList = foodList;
		this.price = price;
		this.description = description;
		
	}
	
	/**
	 * Create a PromoSet with only ID
	 * @param ID
	 */
	public PromoSet(int ID){
		this.ID = ID;
		foodList = new ArrayList<Food>();
	}
	
	
	/**
	 * @return All the food in the PromoSet
	 */
	public ArrayList<Food> getFoodList() {
		return foodList;
	}
	

	/**
	 * Add the food to the PromoSet
	 * @param food
	 */
	public void addFood(Food food){
		foodList.add(food);
	}
	
	/**
	 * If the PromoSet contains the food, remove the Food from the PromoSet, return 0;
	 * Else return -1;
	 * @param food
	 * @return
	 */
	public int removeFood(Food food){
		if(!foodList.remove(food))
			return -1;
		return 0;
	}
}
