package restaurantReservationApp;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.InputMismatchException;
import java.util.Scanner;


public class RRPSS {
	private static FoodMgr foodMgr;
	private static PromoSetMgr promoSetMgr;
	private static OrderMgr orderMgr;
	private static TableMgr tableMgr;
	private static StaffMgr staffMgr;
	public static Scanner sc = new Scanner (System.in);
	
	
	public static void main(String[] args) {
		foodMgr = new FoodMgr();
		promoSetMgr = new PromoSetMgr();
		tableMgr = new TableMgr();
		staffMgr = new StaffMgr();
		orderMgr = new OrderMgr();
		
		int choice =0;
		do 
		{
			System.out.println("**********************************************************");
			System.out.println("                     SCSE RESTAURANT                      ");
			System.out.println("**********************************************************");
			System.out.println("Enter your choice: ");
			System.out.println("1: Create/Update/Remove/Print menu item ");
			System.out.println("2: Create/Update/Remove/Print promotion");
			System.out.println("3: Create Order");
			System.out.println("4: View Order");
			System.out.println("5: Add/Remove order item/s to/from order");
			System.out.println("6: Create reservation booking");
			System.out.println("7: Check/Remove reservation booking");
			System.out.println("8: Check table availability");
			System.out.println("9: Print order invoice");
			System.out.println("10: Print sale revenue report by period");
			System.out.println("11: Quit");
			System.out.println("**********************************************************");
			try{
				choice = sc.nextInt();	
				switch(choice)
				{
					case 1: //add/update/remove menu item
						case1();
						break;
					case 2://add/update/remove promoset
						case2();
						break;
					case 3://create an order
						case3();
						break;
					case 4://view order
						case4();
						break;
					case 5://add/remove order item/s to/from order
						case5();
						break;
					case 6://reservation booking
						case6();
						break;
					case 7:// check/remove reservation booking
						case7();
						break;
					case 8 :
						tableMgr.printTableStatus();
						break;
					case 11 ://quit
						break;
					default:
						System.out.println("Error: invalid input!");
						break;
				}
			}catch (InputMismatchException e){
				System.out.println("Error: invalid input");
				System.out.println("End of program execution!");
				return;
			}catch (Exception e){
				System.out.println(e.getMessage());
			}
		}while (choice != 11);
	}

	private static void case7(){
		System.out.println("1. Check reservation");
		System.out.println("2. Remove reservation");
		System.out.println("3. Back");
		
		System.out.println("Enter your choice: ");
		int c = sc.nextInt();
		switch (c){
			case 1 : case 2:
			{
				System.out.println("Contact Number?");
				int hp = sc.nextInt();
				int result = tableMgr.findReservation(hp, c);
				if (result == -1)
					System.out.println("Cannot find reservation.");
				break;
			}
			case 3:
				break;
			default:
				System.out.println("Error: invalid input!");
				break;	
		}
	
	}

	private static void case6() {
		LocalDate arrDate = null;
		LocalTime arrTime = null;
		try{
			System.out.println("Input arrival date (Format: yyyy-MM-dd, e.g. 2014-01-01): ");
			String dateStr = sc.next();
			arrDate = LocalDate.parse(dateStr);
			if (arrDate.isBefore(LocalDate.now()))
				throw new Exception ("Error: invalid date");
			System.out.println("Input arrival time (Format: HH:MM:00, e.g. 18:00:00): ");
			String timeStr = sc.next();
			arrTime = LocalTime.parse(timeStr);
		}catch(DateTimeParseException e){
			System.out.println("Error: incorrect date/time format");
			return;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return;
		}
		
		System.out.println("Input number of people: ");
		int pax = sc.nextInt();
		
		Reservation res = tableMgr.addReservation(arrDate, arrTime, pax);
		
		if (res == null){
			System.out.println("Sorry, reservation full");
			return;
		}
		
		sc.nextLine(); // flush
		System.out.print("Pleases enter the customer name:");
		String name = sc.nextLine();
		res.setName(name);
		System.out.print("Contact: ");
		int contact = sc.nextInt();
		res.setContact(contact);
		System.out.println("Reservation successful!");
		tableMgr.printReservation(res);
		
	}

	private static void case5() {
		System.out.print("Enter the order id:");
		int orderId=sc.nextInt();
		Order order= orderMgr.getOrderById(orderId);
		if(order ==null){
			System.out.println("This order does not exist.");
		}
		System.out.println("1: Add order items to order");
		System.out.println("2: Remove order items from order");
		System.out.println("3: Quit");
		int c=sc.nextInt();
		switch(c) 
		{
			case 1:	//add stuff to the order
			{
				addStuffToOrder(order);
				System.out.println("Successfully added to the order!");
				order.printOrder();
				break;
			}
			case 2: // remove from order
			{
				order.printOrder();
				removeFromOrder(order);
				System.out.println("Successfully removed from the order!");
				order.printOrder();
				break;
			}
			default: 
			{
				System.out.println("Error: invalid input!");
				break;
			}
		}
	}

	private static void removeFromOrder(Order order) {
		int c;
		do{
			System.out.println("1: Remove food");
			System.out.println("2: Remove promotional set" );
			System.out.println("3. Quit");
			c = sc.nextInt();
			switch (c){
				case 1:
					removeFood(order);
					break;
				case 2:
					removePromoSet(order);
					break;
				case 3:
					break;
				default:
					System.out.println("Error: invalid input!");
					break;
				
			}
		} while (c != 3);
	}

	private static void removePromoSet(Order order) {
		System.out.println("1: Enter the promotional set id and the amount");
		int id=sc.nextInt();
		int quantity=sc.nextInt();
		order.removePromoSet(PromoSetMgr.searchPromoSet(id), quantity);
	}

	private static void removeFood(Order order) {
		System.out.println("1: Enter the food id and the amount");
		int id=sc.nextInt();
		int quantity=sc.nextInt();
		order.removeFood(FoodMgr.searchFood(id), quantity);
	}

	private static void case4() {
		System.out.print("Enter the order id:");
		int orderId=sc.nextInt();
		Order order= orderMgr.getOrderById(orderId);
		if(order ==null){
			System.out.println("This order does not exist.");
		}
		else
			order.printOrder();
	}

	private static void case3() {
		System.out.print("Pax:");
        int pax = sc.nextInt();
		System.out.print("Enter staff ID: ");
		int staffId = sc.nextInt();
		int tableId = tableMgr.assignTable(pax);
		if (tableId == -1){
			System.out.println("No available table");
			return;
		}
		
		Order order = orderMgr.addOrder(tableId, staffId);
		System.out.println("You are assigned to table " + order.getTableID());
		System.out.println("Your order ID is : " + order.getOrderID());
		System.out.println();
		addStuffToOrder(order);
		System.out.println("Order is successfully placed!");
		order.printOrder();
		
	}

	private static void addStuffToOrder(Order order) {
		int c;
		do{
			System.out.println("1: Add food");
			System.out.println("2: Add promotional set" );
			System.out.println("3. Quit");
			c = sc.nextInt();
			switch (c){
				case 1:
					addFood(order);
					break;
				case 2:
					addPromoSet(order);
					break;
				case 3:
					break;
				default:
					System.out.println("Error: invalid input!");
					break;
				
			}
		} while (c != 3);
		
	}

	private static void addPromoSet(Order order) {
		System.out.println("Enter promotional set id and the quantity");
		int id = sc.nextInt();
		if (promoSetMgr.searchPromoSet(id) == null)
			return;
		int quantity=sc.nextInt();
		order.addPromoSet(PromoSetMgr.searchPromoSet(id), quantity);
	}

	private static void addFood(Order order) {
		System.out.println("Enter food id and the quantity");
		int id=sc.nextInt();
		if (foodMgr.searchFood(id) == null)
			return;
		int quantity=sc.nextInt();
		order.addFood(foodMgr.searchFood(id), quantity);
	}

	private static void case2() {
		System.out.println("1: Create promotion");
		System.out.println("2: Update promotion");
		System.out.println("3: Remove promotion");
		System.out.println("4: Print promotion");
		System.out.println("5: Quit");
		int c = sc.nextInt();
		switch(c)
		{
			case 1://add promoset
				addPromoSet();
				break;
			case 2://update promoset//
				updatePromoSet();
				break;
			case 3://remove promoSet
				removePromoSet();
				break;
			case 4: //print promoSet
				promoSetMgr.printPromoSets();
				break;
			case 5: // quit
				break;
			default:
				System.out.println("Error: invalid input!");
				break;
		}			
	}

	private static void removePromoSet() {
		System.out.print("Enter the promotion id:");
		int id=sc.nextInt();
		if(promoSetMgr.searchPromoSet(id) == null)
			return;
		promoSetMgr.removePromoSet(id);
	}

	private static void updatePromoSet() {
		System.out.print("Enter the promotion id:");
		int id=sc.nextInt();
		if(promoSetMgr.searchPromoSet(id) == null)
			return;
		int c;
		do
		{
			System.out.println("1: Update name");
			System.out.println("2: Update price");
			System.out.println("3: Update description");
			System.out.println("4: Quit");
			c= sc.nextInt();
			if (c>0 && c<4)
			{
				sc.nextLine(); //flush
				System.out.println("New value");
				String value = sc.nextLine();
				promoSetMgr.updatePromoSet(id, c, value);
			}
		}while(c>0 && c<4);
		
	}

	private static void addPromoSet() {
		System.out.println("ID:");
		int id = sc.nextInt();
		if (promoSetMgr.searchPromoSet(id) != null){
			System.out.println("Error: promoSet ID exist");
			return;
		}
		sc.nextLine(); //flush
		System.out.print("Name:");
		String name =sc.nextLine();
		System.out.println("food id list:");
		String foodListStr = sc.nextLine();
		System.out.print("Price:");
		double price=sc.nextDouble();
		sc.nextLine(); //flush
		System.out.print("Description:");
		String description =sc.nextLine();
		promoSetMgr.addPromoSet(id, name, foodListStr, price, description);	
	}

	private static void case1() 
	{
		System.out.println("1: Create menu item");
		System.out.println("2: Update menu item");
		System.out.println("3: Remove menu item");
		System.out.println("4: Print menu");
		System.out.println("5: Quit");
		int c=sc.nextInt();
		
		switch(c)
		{
			case 1://add food
				addFood();
				break;
			case 2://update food
				updateFood();
				break;
			case 3://remove food
				removeFood();
				break;
			case 4: //print menu
				printMenu();
			case 5:
				break;
			default:
				System.out.println("Error: invalid input!");
				break;
		}
	}

	private static void printMenu() {
		System.out.println("0: ALL");
		foodMgr.printCategories();
		System.out.println("Enter your choice");
		int c =sc.nextInt();
		if (c == 0)
			foodMgr.printMenu();
		else 
			foodMgr.printMenuByCategory(c);
		
	}
	
	private static void removeFood() {
		System.out.print("Enter the food id:");
		int id=sc.nextInt();
		if (foodMgr.searchFood(id) == null)
			return;
		foodMgr.removeFood(id);	
	}

	private static void updateFood() {
		System.out.print("Enter the food id: ");
		int id=sc.nextInt();
		if (foodMgr.searchFood(id) == null)
			return;
		int c;
		do
		{
			System.out.println("1: Update name");
			System.out.println("2: Update price");
			System.out.println("3: Update description");
			System.out.println("4: Quit");
			c = sc.nextInt();
			sc.nextLine(); // flush
			switch(c){
				case 1: case 2: case 3:
					System.out.println("New Value:");
					String value = sc.nextLine();
					foodMgr.updateFood(id, c, value);
					break;
				case 4:
					break;
				default:
					System.out.println("Error: invalid input!");
			}
				
		}while(c>0 &&c<4);
		
	}

	private static void addFood(){
		System.out.print("Food ID:");
        int id = sc.nextInt();
        if (foodMgr.searchFood(id) != null){
        	System.out.println("Error: food id exist");
			return;
        }
        sc.nextLine(); // flush
		System.out.print("Food name:");
		String name =sc.nextLine();
		System.out.print("Food price:");
		double price=sc.nextDouble();
		System.out.println("Food category:");
		foodMgr.printCategories();
		int category = sc.nextInt();
		sc.nextLine(); //flush
		System.out.print("Food description:");
        String description = sc.nextLine();
        foodMgr.addFood(id, name, price, category, description);
		
	}
		
}
