package restaurantReservationApp;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.InputMismatchException;
import java.util.Scanner;


public class RRPSS {
	private static FoodMgr foodMgr;
	private static PromoSetMgr promoSetMgr;
	private static OrderMgr orderMgr;
	private static TableMgr tableMgr;
	private static StaffMgr staffMgr;
	private static ReservationMgr reservationMgr;
	public static Scanner sc = new Scanner (System.in);
	
	
	public static void main(String[] args) {
		foodMgr = new FoodMgr();
		promoSetMgr = new PromoSetMgr();
		tableMgr = new TableMgr();
		staffMgr = new StaffMgr();
		orderMgr = new OrderMgr();
		reservationMgr = tableMgr.reservationMgr;
		
		int choice =0;
		do 
		{
			System.out.println("**********************************************************");
			System.out.println("                     SCSE RESTAURANT                      ");
			System.out.println("**********************************************************");
			System.out.println("Enter your choice: ");
			System.out.println("1: Create/Update/Remove/Print menu item ");
			System.out.println("2: Create/Update/Remove/Print promotion");
			System.out.println("3: Create Order");
			System.out.println("4: View Order");
			System.out.println("5: Add/Remove order item/s to/from order");
			System.out.println("6: Create reservation booking");
			System.out.println("7: Check/Remove reservation booking");
			System.out.println("8: Check table availability");
			System.out.println("9: Print order invoice");
			System.out.println("10: Print sale revenue report by period");
			System.out.println("11: Quit");
			System.out.println("**********************************************************");
			try{
				choice = sc.nextInt();	
				switch(choice)
				{
					case 1: //add/update/remove menu item
						foodUI();
						break;
					case 2://add/update/remove promoset
						promoSetUI();
						break;
					case 3://create an order
						createOrderUI();
						break;
					case 4://view order
						viewOrderUI();
						break;
					case 5://add/remove order item/s to/from order
						modifyOrderUI();
						break;
					case 6://reservation booking
						bookReservationUI();
						break;
					case 7:// check/remove reservation booking
						checkReservationUI();
						break;
					case 8 :
						tableMgr.printTableStatus();
						break;
					case 9:
						checkOutUI();
					case 11 ://quit
						System.out.println("End of program execution!");
						break;
					default:
						System.out.println("Error: invalid input!");
						break;
				}
			}catch (ItemNotFoundException e){
				System.out.println("Error: " + e.getMessage() + " not found!");
			}catch (InputMismatchException e1){
				System.out.println("Error: invalid input data type!");
				System.out.println("End of program execution!");
				return;
			}catch (Exception e2){
				System.out.println(e2.getMessage());
			}
		}while (choice != 11);
	}

	private static void checkOutUI() {
		System.out.println("Enter order ID");
		int orderID = sc.nextInt();
		int tableId = orderMgr.checkOut(orderID);
		if (tableId == -1)
			return;
		else
			tableMgr.changeStatus(tableId-1, "vacant");
	}

	private static void checkReservationUI(){
		System.out.println("1. Check reservation");
		System.out.println("2. Remove reservation");
		System.out.println("3. Back");
		
		System.out.println("Enter your choice: ");
		int c = sc.nextInt();
		switch (c){
			case 1 : case 2:
			{
				System.out.println("Contact Number?");
				int hp = sc.nextInt();
				int result = reservationMgr.findReservation(hp, c);
				if (result == -1)
					System.out.println("Cannot find reservation.");
				break;
			}
			case 3:
				break;
			default:
				System.out.println("Error: invalid input!");
				break;	
		}
	
	}

	private static void bookReservationUI() {
		LocalDate arrDate = null;
		LocalTime arrTime = null;
		try{
			System.out.println("Input arrival date (Format: yyyy-MM-dd, e.g. 2014-01-01): ");
			String dateStr = sc.next();
			arrDate = LocalDate.parse(dateStr);
			if (arrDate.isBefore(LocalDate.now()))
				throw new Exception ("Error: invalid date");
			System.out.println("Input arrival time (Format: HH:MM:00, e.g. 18:00:00): ");
			String timeStr = sc.next();
			arrTime = LocalTime.parse(timeStr);
		}catch(DateTimeParseException e){
			System.out.println("Error: incorrect date/time format");
			return;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return;
		}
		
		System.out.println("Input number of people: ");
		int pax = sc.nextInt();
		
		Reservation res = reservationMgr.addReservation(arrDate, arrTime, pax);
		
		if (res == null){
			return;
		}
		
		sc.nextLine(); // flush
		System.out.print("Pleases enter the customer name:");
		String name = sc.nextLine();
		res.setName(name);
		System.out.print("Contact: ");
		int contact = sc.nextInt();
		res.setContact(contact);
		System.out.println("Reservation successful!");
		reservationMgr.printReservation(res);
		
	}

	private static void modifyOrderUI() throws ItemNotFoundException {
		System.out.print("Enter the order id:");
		int orderId=sc.nextInt();
		Order order= orderMgr.getOrderById(orderId);
		if(order ==null){
			System.out.println("This order does not exist.");
		}
		System.out.println("1: Add order items to order");
		System.out.println("2: Remove order items from order");
		System.out.println("3: Quit");
		int c=sc.nextInt();
		switch(c) 
		{
			case 1:	//add stuff to the order
			{
				addItemUI(order);
				break;
			}
			case 2: // remove from order
			{
				removeItemUI(order);
				break;
			}
			default: 
			{
				System.out.println("Error: invalid input!");
				break;
			}
		}
	}

	private static void removeItemUI(Order order) throws ItemNotFoundException {
		int c;
		do{
			System.out.println("1: Remove food");
			System.out.println("2: Remove promotional set" );
			System.out.println("3. Quit");
			c = sc.nextInt();
			switch (c){
				case 1:
					removeFoodUI(order);
					break;
				case 2:
					removePromoSetUI(order);
					break;
				case 3:
					break;
				default:
					System.out.println("Error: invalid input!");
					break;
				
			}
		} while (c != 3);
	}

	private static void removePromoSetUI(Order order) throws ItemNotFoundException {
		System.out.println("1: Enter the promotional set id and the amount");
		int id=sc.nextInt();
		PromoSet promoSet = promoSetMgr.searchPromoSet(id);
		if (promoSet== null){
			throw new ItemNotFoundException("promotional set");
		}
		int quantity=sc.nextInt();
		order.removePromoSet(promoSet, quantity);
	}

	private static void removeFoodUI(Order order) throws ItemNotFoundException {
		System.out.println("1: Enter the food id and the amount");
		int id=sc.nextInt();
		Food food = FoodMgr.searchFood(id);
		if(food == null){
			throw new ItemNotFoundException("food");
		}
		int quantity=sc.nextInt();
		int result = order.removeFood(food, quantity);
		if(result == 0)
			System.out.println("Food successfully removed!");
		else
			System.out.println("Error: not able to remove food. Check order!");
	}

	private static void viewOrderUI() throws ItemNotFoundException {
		System.out.print("Enter the order id:");
		int orderId=sc.nextInt();
		Order order= orderMgr.getOrderById(orderId);
		if(order ==null){
			throw new ItemNotFoundException("order");
		}
		orderMgr.printOrder(order);
	}

	private static void createOrderUI() throws ItemNotFoundException {
		int tableId, staffId;
		
		System.out.print("Do you have a reservation? y/n ");
		int result = sc.next().charAt(0);
		if (result == 'n'){  //without reservation
			System.out.print("Pax:");
	        int pax = sc.nextInt();

			tableId = tableMgr.assignTable(pax);
			if (tableId == -1){
				System.out.println("Error: no available table!");
				return;
			}
		}
		else if (result == 'y'){ //with reservation
			System.out.println("Contact number: ");
			int contact = sc.nextInt();
			tableId = reservationMgr.findReservation(contact, 3); //reservation guest arrive, get tableId;
			if (tableId == -1){
				System.out.println("Error: reservation not found!");
				return;
			}
		}
		else{
			System.out.println("Error: invalid input!");
			return;
		}
		
		System.out.print("Enter staff ID: ");
		staffId = sc.nextInt();
		Order order = orderMgr.addOrder(tableId, staffId);
		System.out.println("You are assigned to table " + order.getTableID());
		System.out.println("Your order ID is : " + order.getOrderID());
		System.out.println();
		addItemUI(order);
		System.out.println("Order is successfully placed!");
		orderMgr.printOrder(order);
	}

	private static void addItemUI(Order order) throws ItemNotFoundException {
		int c;
		do{
			System.out.println("1: Add food");
			System.out.println("2: Add promotional set" );
			System.out.println("3. Quit");
			c = sc.nextInt();
			switch (c){
				case 1:
					addFoodUI(order);
					break;
				case 2:
					addPromoSetUI(order);
					break;
				case 3:
					break;
				default:
					System.out.println("Error: invalid input!");
					break;
				
			}
		} while (c != 3);
		
	}

	private static void addPromoSetUI(Order order) throws ItemNotFoundException {
		System.out.println("Enter promotional set id and the quantity");
		int id = sc.nextInt();
		PromoSet promoSet = promoSetMgr.searchPromoSet(id);
		if (promoSet == null){
			throw new ItemNotFoundException("promotional set");
		}
		int quantity=sc.nextInt();
		order.addPromoSet(promoSet, quantity);
	}

	private static void addFoodUI(Order order) throws ItemNotFoundException {
		System.out.println("Enter food id and the quantity");
		int id=sc.nextInt();
		Food food = foodMgr.searchFood(id);
		if (food == null){
			throw new ItemNotFoundException("food");
		}
		int quantity=sc.nextInt();
		order.addFood(food, quantity);
	}

	private static void promoSetUI() throws ItemNotFoundException {
		System.out.println("1: Create promotion");
		System.out.println("2: Update promotion");
		System.out.println("3: Remove promotion");
		System.out.println("4: Print promotion");
		System.out.println("5: Quit");
		int c = sc.nextInt();
		switch(c)
		{
			case 1://add promoset
				addPromoSetUI();
				break;
			case 2://update promoset//
				updatePromoSetUI();
				break;
			case 3://remove promoSet
				removePromoSetUI();
				break;
			case 4: //print promoSet
				promoSetMgr.printPromoSets();
				break;
			case 5: // quit
				break;
			default:
				System.out.println("Error: invalid input!");
				break;
		}			
	}

	private static void removePromoSetUI() throws ItemNotFoundException {
		System.out.print("Enter the promotion id:");
		int id=sc.nextInt();
		PromoSet promoSet = promoSetMgr.searchPromoSet(id);
		if( promoSet == null){
			throw new ItemNotFoundException("promotional set");
		}
		promoSetMgr.removePromoSet(promoSet);
		System.out.println("Remove successfully!");
	}

	private static void updatePromoSetUI() {
		System.out.print("Enter the promotion id:");
		int id=sc.nextInt();
		PromoSet promoSet = promoSetMgr.searchPromoSet(id);
		if( promoSet == null){
			System.out.println("Error: promotional set not found!");
			return;
		}
		int c;
		do
		{
			System.out.println("1: Update name");
			System.out.println("2: Update price");
			System.out.println("3: Update description");
			System.out.println("4: Quit");
			c= sc.nextInt();
			if (c>0 && c<4)
			{
				sc.nextLine(); //flush
				System.out.println("New value");
				String value = sc.nextLine();
				promoSetMgr.updatePromoSet(promoSet, c, value);
			}
		}while(c>0 && c<4);
		
	}

	private static void addPromoSetUI() {
		System.out.println("ID:");
		int id = sc.nextInt();
		if (promoSetMgr.searchPromoSet(id) != null){
			System.out.println("Error: promoSet ID exist");
			return;
		}
		sc.nextLine(); //flush
		System.out.print("Name:");
		String name =sc.nextLine();
		System.out.println("food id list:");
		String foodListStr = sc.nextLine();
		System.out.print("Price:");
		double price=sc.nextDouble();
		sc.nextLine(); //flush
		System.out.print("Description:");
		String description =sc.nextLine();
		promoSetMgr.addPromoSet(id, name, foodListStr, price, description);	
	}

	private static void foodUI() throws ItemNotFoundException 
	{
		System.out.println("1: Create menu item");
		System.out.println("2: Update menu item");
		System.out.println("3: Remove menu item");
		System.out.println("4: Print menu");
		System.out.println("5: Quit");
		int c=sc.nextInt();
		
		switch(c)
		{
			case 1://add food
				addFoodUI();
				break;
			case 2://update food
				updateFoodUI();
				break;
			case 3://remove food
				removeFoodUI();
				break;
			case 4: //print menu
				printMenu();
			case 5:
				break;
			default:
				System.out.println("Error: invalid input!");
				break;
		}
	}

	private static void printMenu() {
		System.out.println("0: ALL");
		foodMgr.printCategories();
		System.out.println("Enter your choice");
		int c =sc.nextInt();
		if (c == 0)
			foodMgr.printMenu();
		else 
			foodMgr.printMenuByCategory(c);
		
	}
	
	private static void removeFoodUI() throws ItemNotFoundException {
		System.out.print("Enter the food id:");
		int id=sc.nextInt();
		Food food = foodMgr.searchFood(id);
		if (food == null){
			throw new ItemNotFoundException("food");
		}
		foodMgr.removeFood(food);	
	}

	private static void updateFoodUI() throws ItemNotFoundException {
		System.out.print("Enter the food id: ");
		int id=sc.nextInt();
		Food food = foodMgr.searchFood(id);
		if (food == null){
			throw new ItemNotFoundException("food");
		}
		int c;
		do
		{
			System.out.println("1: Update name");
			System.out.println("2: Update price");
			System.out.println("3: Update description");
			System.out.println("4: Quit");
			c = sc.nextInt();
			sc.nextLine(); // flush
			switch(c){
				case 1: case 2: case 3:
					System.out.println("New Value:");
					String value = sc.nextLine();
					foodMgr.updateFood(food, c, value);
					break;
				case 4:
					break;
				default:
					System.out.println("Error: invalid input!");
			}
				
		}while(c>0 &&c<4);
		
	}

	private static void addFoodUI(){
		System.out.print("Food ID:");
        int id = sc.nextInt();
        if (foodMgr.searchFood(id) != null){
        	System.out.println("Error: food id exist!");
        	return;
        }
        sc.nextLine(); // flush
		System.out.print("Food name:");
		String name =sc.nextLine();
		System.out.print("Food price:");
		double price=sc.nextDouble();
		System.out.println("Food category:");
		foodMgr.printCategories();
		int category = sc.nextInt();
		sc.nextLine(); //flush
		System.out.print("Food description:");
        String description = sc.nextLine();
        foodMgr.addFood(id, name, price, category, description);
		
	}
		
}
