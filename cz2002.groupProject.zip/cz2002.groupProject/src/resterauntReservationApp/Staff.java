package resterauntReservationApp;

import java.util.*;

public class Staff {
	Scanner sc = new Scanner(System.in);
	
	private String name;
	private String gender;
	private int employeeID;
	private String jobTitle;
	
	public Staff(){
		setName();
		setGender();
		setEmployeeID();
		setJobTitle();
	}
	
	public String getName(){
		return name;
	}
	public String getGender(){
		return gender;
	}
	public int getEmployeeID(){
		return employeeID;
	}
	public String getJobTitle(){
		return jobTitle;
	}
	
	public void setName(){
		System.out.println("Enter name:");
		name = sc.next();
	}
	public void setGender(){
		System.out.println("Enter gender: M/F");
		name = sc.next();
	}
	public void setEmployeeID(){
		System.out.println("Enter employee ID:");
		employeeID = sc.nextInt();
	}
	public void setJobTitle(){
		System.out.println("Enter jobTitle:");
		jobTitle = sc.next();
	}
	
}
