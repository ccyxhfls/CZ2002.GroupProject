package resterauntReservationApp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Employees {
	private static List<Staff> employees = new ArrayList<Staff>();
	
	public void addStaff(){
		employees.add(new Staff());
	}
	
	public static Staff searchStaffByID(int id){
		Iterator<Staff> itr = employees.iterator();
		while(itr.hasNext()){
			Staff staff = itr.next();
			if (staff.getEmployeeID() == id){
				return staff;
			}
		}
		return null;
	}
}
