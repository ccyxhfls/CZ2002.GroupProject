package resterauntReservationApp;


public class PromotionalPackage extends CollectionOfItems {

	private double totalPrice;
	private double packagePrice;

	public PromotionalPackage(){
		System.out.print("Enter number of items in the package: ");
		int n = sc.nextInt();
		for (int i = 0; i < n; i ++){
			System.out.print("Enter item ID to be added to a package: ");
			int itemID = sc.nextInt();
			Item item = Menu.searchItemByID (itemID);
			if (item != null)
				addItem(item);
			else{
				System.out.println("Invalide itemID");
				i--;
			}
		}
		System.out.println("Total price is " + getTotalPrice());
		System.out.println("Set promotional package price: ");
		packagePrice = sc.nextDouble();
	}
	public double getTotalPrice(){
		return totalPrice;
	}
	public double getPackagePrice(){
		return packagePrice;
	}
	public void updatePackage(){
		System.out.print("Enter the information to be updated: 1-add new item to package, 2-remove item from package");
		int choice = sc.nextInt();
		switch(choice) {
			case 1: {
				System.out.println("Enter item ID to add: ");
				int itemID = sc.nextInt();
				Item item = Menu.searchItemByID(itemID);
				addItem(item);
				break;
			}
			case 2: {
				System.out.println("Enter item ID to remove: ");
				int itemID = sc.nextInt();
				removeItem(itemID);
				break;
			}
			default: System.out.println("ERROR");
		}
	}
	public void addItem (Item item){
		super.addItem(item);
		totalPrice += item.getItemPrice();
	}
	public Item removeItem (int itemID){
		Item item = super.removeItem(itemID);
		if (item != null) {
			totalPrice -= item.getItemPrice();
		}
		return item;
	}
	public void print(){
		for (int i = 0; i< items.size(); i++){
			items.get(i).print();
		}
		System.out.println();
		System.out.printf("%77s %-10.2f \n", "Total Price", totalPrice);
		System.out.printf("%77s %-10.2f \n", "Package Price", packagePrice);
	}
}
