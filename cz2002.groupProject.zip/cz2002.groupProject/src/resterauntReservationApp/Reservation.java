package resterauntReservationApp;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Reservation {
	Scanner sc = new Scanner(System.in);
	
	private Date date;
	private boolean morning;
	private int pax;
	private String name;
	private String contactNum;
	private Table table;
	
	public void Reservation(){
		setDate();
		setMorning();
		setPax();
		setName();
		setContactNum();
		setTable();
	}
	
	public void setMorning(){
		System.out.println("Morning or afternnon?  1- morning, 2-afternoon");
		morning = sc.nextInt() == 1 ? true:false;
	}
	public void setTable(){
		Day day = Month.getDay(date);
		day.printAvailableTables(morning, pax);
		Table table = day.reserveAvailableTable(morning, pax);
		this.table = table;
		
	}
	public void setDate(){
		System.out.println("Enter date in dd/mm/yyyy format");
		String dateStr = sc.next();
		DateFormat df = new SimpleDateFormat("dd/mm/yyyy");
		try {
			date  = df.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}

	}
	
	public void setPax(){
		System.out.println("Enter number of pax");
		pax = sc.nextInt();
	}
	
	public void setName(){
		System.out.println("Enter name");
		name = sc.next();
	}
	
	public void setContactNum(){
		System.out.println("Enter contact number");
		contactNum = sc.next();
	}
}
