package resterauntReservationApp;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import resterauntReservationApp.Table.TableStatus;

public class Day {
	Scanner sc = new Scanner("System.in");
	
	private Date date;
	private Table[] tables = new Table[30];
	private List<Order> orders;
	
	public Day (){
		setDate();
		for (int i = 0; i < 30; i++){
			if (i < 5)
				tables[i] = new Table (i, 10);
			else if (i < 10)
				tables[i] = new Table (i, 8);
			else if (i < 20)
				tables[i] = new Table (i, 4);
			else
				tables[i] = new Table (i, 2);
		}
		orders = new ArrayList<Order>();
	}
	
	public Day (Date date){
		this.date = date;
		for (int i = 1; i < 30; i++){
			if (i < 5)
				tables[i] = new Table (i, 10);
			else if (i < 10)
				tables[i] = new Table (i, 8);
			else if (i < 20)
				tables[i] = new Table (i, 4);
			else
				tables[i] = new Table (i, 2);
		}
		orders = new ArrayList<Order>();
	}
	
	public Date setDate(){
		System.out.println("Enter date in dd/mm/yyyy format:");
		String dateStr = sc.next();
		DateFormat df = new SimpleDateFormat("dd/mm/yyyy");
		try {
			date  = df.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	public static void printDate(Date date){
		DateFormat df = new SimpleDateFormat("dd/mm/yyyy");
		String newDateString = df.format(date);
        System.out.println("print date" + newDateString);
	}
	
	public Date getDate (){
		return date;
	}

	public void addOrder(){
		Order order = new Order();
		addOrder(order);
	}
	public void addOrder(Order order){
		orders.add(order);
	}
	
	public ArrayList<Table> findAvailabeTables(boolean morning, int pax){
		ArrayList<Table> availableTable = new ArrayList<Table>();
		for (int i = 0; i < 30; i++){
			if (morning){
				if(tables[i].getCapacity() >= pax && tables[i].getMorningStatus() == TableStatus.VACANT){
					availableTable.add(tables[i]);
				}
			}
			else{
				if(tables[i].getCapacity() >= pax && tables[i].getMorningStatus() == TableStatus.VACANT){
					availableTable.add(tables[i]);
				}
			}
		}
		return availableTable;
	}
	
	public void printAvailableTables (boolean morning, int pax){
		ArrayList<Table> availableTables = findAvailabeTables(morning, pax);
		Iterator<Table> itr = availableTables.iterator();
		while(itr.hasNext()){
			Table table = itr.next();
			table.printTableInfor();
		}
	}
	
	public Table assignAvailableTable(boolean morning, int pax){
		Table table = findAvailabeTables(morning, pax).get(0);
		if(morning)
			table.occupyMorining();
		else
			table.occupyAfternoon();
		return table;
	}
	

	
	public Table reserveAvailableTable(boolean morning, int pax){
		Table table = findAvailabeTables(morning, pax).get(0);
		if(morning)
			table.reserveMorining();
		else
			table.reserveAfternoon();
		return table;
	}
	

}
