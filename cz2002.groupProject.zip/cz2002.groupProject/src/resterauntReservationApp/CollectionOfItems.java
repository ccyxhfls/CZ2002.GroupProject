package resterauntReservationApp;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public abstract class CollectionOfItems {
	Scanner sc = new Scanner(System.in);
	
	protected List<Item> items = new ArrayList<Item>();
	
	public int getNumOfItems(){
		return items.size();
	}	
	public void addItem (Item item){
		items.add(item);
	}
	public Item searchItem (int itemID){
		Iterator<Item> itr = items.iterator();
		while(itr.hasNext()){
			Item item = itr.next();
			if (item.getItemID() == itemID){
				return item;
			}
		}
		return null;
	}
	public Item removeItem (int itemID){
		Item item = searchItem(itemID);
		if ( item != null){
			items.remove(item);
		}
		return item;
	}
	public Item updateItem (int itemID){
		Item item = searchItem (itemID);
		if (item != null){
			item.updateItem();
		}
		return item;
	}
	public abstract void print();
		
}
