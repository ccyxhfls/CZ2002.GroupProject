package resterauntReservationApp;

import java.util.Scanner;

import resterauntReservationApp.Category.KindOfItem;


public class Item {
	
	Scanner sc = new Scanner(System.in);

	protected int itemID;
	protected String itemName;
	protected double itemPrice;
	protected KindOfItem itemCategory;
	
	public Item (String[] metaData){
		itemID = Integer.parseInt(metaData[0]);
		itemCategory = KindOfItem.valueOf(metaData[1]);
		itemName = metaData[2];
		itemPrice = Double.parseDouble(metaData[3]);
	}
	
	public Item(){
		setItemName();
		setItemPrice();
		setItemCategory();
	}
	
	public int getItemID(){
		return itemID;
	}
	
	public String getItemName(){
		return itemName;
	}
	
	public double getItemPrice(){
		return itemPrice;
	}
	
	public KindOfItem getItemCategory(){
		return itemCategory;
	}
	
	public void setItemID(int id){
		itemID= id;
	}
	
	public void setItemName(String name){
		itemName = name;
	}
	
	public void setItemName(){
		System.out.println("Enter name:");
		String name = sc.nextLine();
		setItemName(name);
	}
	
	public void setItemPrice(double price){
		itemPrice = price;
	}
	
	public void setItemPrice(){
		System.out.println("Enter price:");
		double price = sc.nextDouble();
		setItemPrice(price);
	}
	
	public void setItemCategory(KindOfItem kind){
		itemCategory = kind;
	}
	
	public void setItemCategory(){
		System.out.println("Enter Category number:");
		Category.printListOfCategory();
		int categoryValue = sc.nextInt();
		KindOfItem kind = KindOfItem.values()[categoryValue-1];
		setItemCategory(kind);
	}
	
	public void updateItem(){
		setItemName();
		setItemPrice();
	}
	
	public void print(){
		System.out.printf("%-5d %-20s %-50s %-10.2f\n", itemID , itemCategory, itemName, itemPrice);
	}
}
