package resterauntReservationApp;

public class OrderItem extends Item{
	private int quantity;
	
	public OrderItem(){
		super();
		setItemQuantity();
	}
	
	public void setItemQuantity(int quantity){
		this.quantity = quantity;
	}
	
	public void setItemQuantity(){
		System.out.println("Enter quantity:");
		int quantity = sc.nextInt();
		setItemQuantity(quantity);
	}
	
	
}
