package resterauntReservationApp;

import java.util.*;


public class Menu {
	Scanner sc = new Scanner(System.in);
	
	public static final int NUMOFCATEGORIES  = Category.getNumOfCategories();
	
	private static Category[] categories;
	private static List<PromotionalPackage> promotionalPackages;
	IOHandler io = new IOHandler();
	
	public Menu(String fileName){
		categories = new Category[NUMOFCATEGORIES];
		promotionalPackages = new ArrayList<PromotionalPackage>();
		for (int i = 0; i < NUMOFCATEGORIES; i++){
			categories[i] = new Category(i);
		}
		io.loadMenuFromFile(fileName, categories);
	}
	
	public int getNumOfItems(){
		int totalItem = 0;
		for (int i = 0; i < NUMOFCATEGORIES; i++){
			totalItem += categories[i].getNumOfItems();
		}
		return totalItem;
	}
	
	public int getNumOfPackages(){
		return promotionalPackages.size();
	}

	public static Item searchItemByID (int itemID){
		int categoryValue = itemID/100;
		Item item = categories[categoryValue-1].searchItem(itemID);
		return item;
	}
	
	public void addPromotionalPackages(){
		PromotionalPackage pp = new PromotionalPackage();
		promotionalPackages.add(pp);
		System.out.println("Promotion package added");
		pp.print();
		System.out.println("Print updated menu? y/n ");
		if (sc.next().charAt(0) == 'y')
				printMenu();
	}
	
	public void updatePromotionalPackage(){
		System.out.print("Enter ID of the package to be updated: ");
		int packageID = sc.nextInt();
		PromotionalPackage pp = promotionalPackages.get(packageID -1);
		pp.updatePackage();
		System.out.println("Promotion package updated");
		pp.print();
		System.out.println("Print updated menu? y/n ");
		if (sc.next().charAt(0) == 'y')
				printMenu();
	}
	
	public void removePromotionalPackage(){
		printMenu();
		System.out.print("Enter ID of the package to be removed: ");
		int packageID = sc.nextInt();
		PromotionalPackage pp = promotionalPackages.remove(packageID-1);
		System.out.println("Promotion package removed");
		pp.print();
		System.out.println("Print updated menu? y/n ");
		if (sc.next().charAt(0) == 'y')
				printMenu();
	}
	
	public void addMenuItem(){
		MenuItem item = new MenuItem();
		int categoryValue = item.getItemCategory().ordinal();
		categories[categoryValue].addItem(item);
		System.out.println("Added to menu");
		item.print();
		System.out.println("Print updated menu? y/n ");
		if (sc.next().charAt(0) == 'y')
				printMenu();
		
	}
	
	public void removeMenuItem(){
		printMenu();
		System.out.print("Enter ID of the item to be removed: ");
		int itemID = sc.nextInt();
		int categoryValue = itemID/100;
		Item item = categories[categoryValue-1].removeItem(itemID);
		System.out.println("removed to menu");
		item.print();
		System.out.println("Print updated menu? y/n ");
		if (sc.next().charAt(0) == 'y')
				printMenu();
	}
	
	public void updateMenuItem(){
		printMenu();
		System.out.print("Enter ID of the item to be updated: ");
		int itemID = sc.nextInt();
		Item item = searchItemByID (itemID);
		item.updateItem();
		System.out.println("Item updated");
		item.print();
		System.out.println("Print updated menu? y/n ");
		if (sc.next().charAt(0) == 'y')
				printMenu();
	}
	
	public void printMenu(){
		//System.out.println("DEBUG in printMenu" + items.size());
		System.out.println("************************************************************************************");
		System.out.println("                                        MENU                                        ");
		System.out.println("************************************************************************************");
		System.out.printf("%-5s %-20s %-50s %-10s", "ID", "Category", "Name", "Price(S$)" );
		System.out.println();
		System.out.println("-------------------------------------ALA CARTE--------------------------------------");
		for (int i = 0; i < NUMOFCATEGORIES; i++) {
			categories[i].print();
		}
		System.out.println("************************************************************************************");
		System.out.println("                                        PROMOTION                                        ");
		System.out.println("************************************************************************************");
		if (promotionalPackages.size() == 0)
			System.out.println("N.A");
		for (int i = 0; i < promotionalPackages.size(); i++){
			System.out.println("PACKAGE ID: " + (i+1));
			promotionalPackages.get(i).print();
			System.out.println("-----------------------------------------------------------------------------------");
		}
		System.out.println("----------------------------------------END----------------------------------------");
	}
}
