package resterauntReservationApp;

import java.util.*;

public class Order extends CollectionOfItems{
	public static final double GST = 0.07;
	public static final double SERVICECHARGE = 0.1;
	
	private Staff staff;
	private Table table;
	private Calendar timeStamp;
	private int pax;
	private double subtotal;
	private double total;
	
	public Order(){
		setStaff();
		setTimeStamp();
		setTable();
		setPax();
	}
	
	public void setStaff(){
		System.out.println("Enter staff ID:");
		staff = Employees.searchStaffByID(sc.nextInt());
	}
	
	public void setTimeStamp(){
		timeStamp = new GregorianCalendar();
	}
	
	public void setPax(){
		System.out.println("Enter number of pax.");
		pax = sc.nextInt();
	}
	public void setTable (){
		Day today = Month.getToday();
		boolean morning = timeStamp.get(Calendar.HOUR_OF_DAY) < 12? true:false;
		today.printAvailableTables(morning, pax);
		Table table = today.assignAvailableTable(morning, pax);
		this.table = table;
	}
	
	public void addItem (OrderItem item){
		super.addItem(item);
		subtotal += item.getItemPrice();
		total = subtotal * (1 + GST + SERVICECHARGE);
	}
	
	public Item removeItem (int itemID){
		Item item = super.removeItem(itemID);
		subtotal -= item.getItemPrice();
		total = subtotal * (1 + GST + SERVICECHARGE);
		return item;
	}
	public void print(){
		
	}
	
}
