package resterauntReservationApp;

import resterauntReservationApp.Category.KindOfItem;

public class MenuItem extends Item{
	private int item_vegan;
	private int item_chefRecommend;
	private int item_spicy;
	private String itemDescription;
	
	public MenuItem (String[] metaData) {
		super(metaData);
		item_vegan = Integer.parseInt(metaData[4]);
		item_chefRecommend = Integer.parseInt(metaData[5]);
		item_spicy = Integer.parseInt(metaData[6]);
		itemDescription = getItemDescription();
	}
	
	public MenuItem(){
		super();
		setItemVegan();
		setItemChefRecommend();
		setItemSpicy();
		itemDescription = getItemDescription();
	}
	
	
	
	public String getItemDescription(){
		StringBuilder sb = new StringBuilder();
		if (item_vegan == 1)
			sb.append("*Vegan*");
		if (item_chefRecommend == 1)
			sb.append("*Chef recommend*");
		if (item_spicy == 1)
			sb.append("*Spicy*");
		return (sb.toString());
	}
	
	public void setItemVegan(){
		System.out.println("vegan? y/n ");
		char choice = sc.next().charAt(0);
		switch(choice){
			case 'y':{ item_vegan = 1;break;}
			case 'n':{ item_vegan = 0;break;}
			default: System.out.println("ERROR");
		}
	}
	public void setItemChefRecommend(){
		System.out.println("Chef recommend? y/n ");
		char choice = sc.next().charAt(0);
		switch(choice){
			case 'y':{ item_chefRecommend = 1; break;}
			case 'n':{ item_chefRecommend = 0; break;}
			default: System.out.println("ERROR");
		}
		
	}
	public void setItemSpicy(){
		System.out.println("Spicy? y/n ");
		char choice = sc.next().charAt(0);
		switch(choice){
			case 'y': {item_spicy = 1; break;}
			case 'n': {item_spicy = 0; break;}
			default: System.out.println("ERROR");
		}
		
	}
	public void updateItem(){
		super.updateItem();
		setItemVegan();
		setItemChefRecommend();
		setItemSpicy();
		itemDescription = getItemDescription();
	}
	
	public void print(){
		System.out.printf("%-5d %-20s %-50s %-10.2f %-40s \n", itemID , itemCategory, itemName, itemPrice, itemDescription);
	}

}
