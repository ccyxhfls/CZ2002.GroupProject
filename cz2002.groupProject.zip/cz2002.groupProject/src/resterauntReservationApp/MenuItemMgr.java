package restaurantReservationApp;

public class MenuItemMgr {
	public Food addFood (String[] attributes, int categoryIndex){
		Food food = new Food(attributes);
		CategoryList.get(categoryIndex).addFood(food);
		return food;
	}
	
	public Food removeFood (int ID){
		int categoryIndex = ID/100;
		Food food = searchFood(ID);
		foodList.remove(food);
		return food;
	}
	
	public Food updateName(int ID, String name){
		Food food = searchFood(ID);
		food.setFoodName(name);
		return food;
	}
	
	public Food updatePrice(int ID, int price){
		Food food = searchFood(ID);
		food.setFoodPrice(price);
		return food;
	}
	
	
}
