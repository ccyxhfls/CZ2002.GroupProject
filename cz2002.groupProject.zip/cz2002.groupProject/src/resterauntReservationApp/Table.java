package resterauntReservationApp;

public class Table {
	public enum TableStatus {VACANT, OCCUPIED, RESERVED};
	
	private int tableNumber;
	private int capacity;
	private TableStatus morningStatus;
	private TableStatus afternoonStatus;
	
	public Table(int tableNumber, int capacity){
		this.tableNumber = tableNumber;
		this.capacity = capacity;
		morningStatus = TableStatus.VACANT;
		afternoonStatus = TableStatus.VACANT;
	}
	
	public void occupyMorining(){
		morningStatus = TableStatus.OCCUPIED ;
	}
	
	public void occupyAfternoon(){
		afternoonStatus = TableStatus.OCCUPIED;
	}
	
	public void reserveMorining(){
		morningStatus = TableStatus.RESERVED ;
	}
	
	public void reserveAfternoon(){
		afternoonStatus = TableStatus.RESERVED;
	}
	
	public void vacantMorning(){
		morningStatus = TableStatus.VACANT;
	}
	
	public void freeAfternoon(){
		afternoonStatus = TableStatus.VACANT;
	}
	
	public TableStatus getMorningStatus(){
		return morningStatus;
	}
	
	public TableStatus getAfternoonStatus(){
		return morningStatus;
	}
	
	public int getTableNumber(){
		return tableNumber;
	}
	
	public int getCapacity(){
		return capacity;
	}
	public void printTableStatus(){
		System.out.println(morningStatus.toString() + afternoonStatus.toString());
	}
	
	public void printTableInfor(){
		System.out.println(tableNumber + capacity);
	}
}
