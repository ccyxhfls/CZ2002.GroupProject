package resterauntReservationApp;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Month {
	Scanner sc = new Scanner(System.in);
	
	public static final int NUMOFDAYSINMONTH = 30;
	public static List<Day> month = new ArrayList<Day>();
	
	public Month(){
		Day day = new Day(new Date());
		for (int i = 0; i< NUMOFDAYSINMONTH; i++ ){
			month.add(day);
			day = addOneDay(day);
		}
	}
	
	public Day addOneDay(Day day){
		Date date = day.getDate();
		long time = date.getTime();
		Date newDate = new Date(date.getTime() + (1000*60*60*24));
		Day newDay = new Day(newDate);
		return newDay;
	}
	
	
	public static Day getToday(){
		return getDay(new Date());
	}
	
	public static Day getDay (Date date){
		Date todayDate = new Date();
		int difference = (int)(date.getTime() - todayDate.getTime())/(1000 * 60 * 60 * 24);
		return month.get(difference);
	}

}
