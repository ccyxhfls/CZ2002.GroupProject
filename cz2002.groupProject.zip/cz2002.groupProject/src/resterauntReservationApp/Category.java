package resterauntReservationApp;


public class Category extends CollectionOfItems{
	public static int NumOfCategory = 14;
	public static enum KindOfItem{
		ADVANCEDORDER,
		APPETIZER,
		SOUP,
		FISH,
		FRESHPRAWN,
		CLASSICZICHAR,
		VEGETABLE,
		EGGNTOFU,
		DESSERT,
		NOODLENRICE,
		HOTDRINK,
		COLDDRINK,
		FRESHJUICE,
		BEER
	};
	
	private KindOfItem kind;
	
	public Category(int i){
		kind = KindOfItem.values()[i];
	}
	
	public static void printListOfCategory(){
		for (int i = 0; i <NumOfCategory; i++)
			System.out.printf("%d: %s\n", i+1, KindOfItem.values()[i]);
	}
	
	public static int getNumOfCategories(){
		return NumOfCategory;
	}
	
	public void addItem(MenuItem item){
		super.addItem(item);
		int itemID = (kind.ordinal()+1) * 100 + items.size();
			// Calculate itemID: Category number * 100 + Item number
		item.setItemID(itemID);
	}
	
	public Item removeItem (int itemID){
		Item item = super.removeItem(itemID);
		
		//Recalculate item ID for subsequent items in the category
		if (item != null){
			int index = itemID - (kind.ordinal()+1) * 100;
			for (int i = index-1; i < items.size(); i++){
				Item it = items.get(i);
				int oldID = it.getItemID();
				//System.out.println("DEBUG: BEFORE: " + oldID);
				int newID = oldID-1;
				//System.out.println("DEBUG: BEFORE: " + newID);
				it.setItemID(newID);
			}
		}
		return item;
	}
	
	public void print() {
		for (int i = 0; i < items.size(); i++){
			items.get(i).print();
		}
	}
	
}
