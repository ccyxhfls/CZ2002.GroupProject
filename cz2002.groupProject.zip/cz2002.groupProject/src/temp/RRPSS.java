package restaurantReservationApp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Scanner;


public class RRPSS {
	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		Restaurant restaurant = new Restaurant();
		int choice, choice2, choice3;
		do 
		{
			System.out.println("1: Create/Update/Remove menu item ");
			System.out.println("2: Create/Update/Remove promotion");
			System.out.println("3: Create Order");
			System.out.println("4: View Order");
			System.out.println("5: Add/Remove order item/s to/from order");
			System.out.println("6: Create reservation booking");
			System.out.println("7: Check/Remove reservation booking");
			System.out.println("8: Check table availability");
			System.out.println("9: Print order invoice");
			System.out.println("10: Print sale revenue report by period");
			System.out.println("11: Quit");
			
			choice = sc.nextInt();
			switch(choice)
			{
				case 1: //add/update/remove menu item
				{
					System.out.println("1: Create menu item");
					System.out.println("2: Update menu item");
					System.out.println("3: Remove menu item");
					System.out.println("4: Quit");
					choice2=sc.nextInt();
					
					switch(choice2)
					{
						case 1://add food
						{
	                        System.out.print("ID:");
	                        int id = sc.nextInt();
	                        sc.nextLine(); // flush
							System.out.print("Name:");
							String name =sc.nextLine();
							System.out.print("Price:");
							double price=sc.nextDouble();
							System.out.print("Category:");
							restaurant.printCategories();
							int category = sc.nextInt();
							System.out.print("Description:");
		                    String description = sc.nextLine();
		                    restaurant.addFood(id, name, price, category);
		                    break;
						}
						case 2://update food
						{
							System.out.print("Enter the food id");
							int id=sc.nextInt();
							do
							{
								System.out.println("1: Update name");
								System.out.println("2: Update price");
								System.out.println("3: Update description");
								System.out.println("4: Quit");
								choice3= sc.nextInt();
								sc.nextLine(); // flush
								if (choice3>0 && choice3<4)
								{
									System.out.println("New Value:");
									String value = sc.nextLine();
									restaurant.updateFood(id, choice3, value);
								}
							}while(choice3>0 &&choice3<4);
							break;
						}
						case 3://remove food
						{
							System.out.print("Enter the food id:");
							int id=sc.nextInt();
							restaurant.removeFood(id);
							break;
						}
						case 4: //quit
						{
							break;
						}
						default:
						{
							System.out.println("Wrong data input");
							break;
						}
					}
					break;
				}
				
				
				case 2://add/update/remove promoset
				{
					System.out.println("1: Create promotion");
					System.out.println("2: Update promotion");
					System.out.println("3: Remove promotion");
					System.out.println("4: Quit");
					choice2 = sc.nextInt();
					switch(choice2)
					{
						case 1://add promoset
						{
							System.out.println("ID:");
							int id = sc.nextInt();
							System.out.print("Name:");
							String name =sc.nextLine();
							System.out.println("food id list:");
							String foodListStr = sc.nextLine();
							System.out.print("Price:");
							double price=sc.nextDouble();
							System.out.print("Description:");
							String description =sc.nextLine();
							restaurant.addPromoSet(id, name, foodListStr, price, description);
							break;
						}
						case 2://update promoset//
						{
							System.out.print("Enter the promotion id:");
							int id=sc.nextInt();
							do
							{
								System.out.println("1: Update name");
								System.out.println("2: Update price");
								System.out.println("3: Update description");
								System.out.println("4: Quit");
								choice3= sc.nextInt();
								if (choice3>0 && choice3<4)
								{
									System.out.println("New value");
									String value = sc.nextLine();
									restaurant.updatePromoSet(id, choice3, value);
								}
							}while(choice3>0 && choice3<4);
							break;
						}
						
						case 3://remove promoSet
						{
							System.out.print("Enter the promotion id:");
							int id=sc.nextInt();
							restaurant.removePromoSet(id);
							break;
						}
						case 4: // quit
						{
							break;
						}
						default:
						{	
							System.out.println("wrong input");
							break;
						}
					}		
					break;
				}
				case 3://create an order
				{
	                System.out.print("pax:");
	                int pax = sc.nextInt();
					System.out.print("Enter staff ID: ");
					int staffId = sc.nextInt();
					Order order = restaurant.createOrder(pax, staffId);
					
					//add food
					do{
						System.out.println("1: Enter the food id and the amount");
						System.out.println("2: Quit");
						choice2=sc.nextInt();
						if(choice2 ==1)
						{
							System.out.println("Enter the food id:");
							int id=sc.nextInt();
							System.out.println("Enter the amount:");
							int quantity=sc.nextInt();
							order.addFood(id, quantity);
						}
					}while(choice2 ==1);
					//add promoset
					do{
						System.out.println("1: Enter the promotional set id and the amount");
						System.out.println("2: Quit");
						choice2=sc.nextInt();
						if(choice2 ==1)
						{
							System.out.println("Enter the promotional set id:");
							int id=sc.nextInt();
							System.out.println("Enter the amount:");
							int quantity=sc.nextInt();
							order.addPromoSet(id, quantity);

						}
					}while(choice2 ==1);
					
					break;
				}
				
				case 4://view order
				{
					System.out.print("Enter the order id:");
					int orderId=sc.nextInt();
					Order order= restaurant.getOrderById(orderId);
					if(order ==null){
						System.out.println("This order does not exist.");
					}
					else
						order.printOrder();
					break;
				}
				case 5://Add/Remove order item/s to/from order
				{
					System.out.print("Enter the order id:");
					int orderId=sc.nextInt();
					Order order= restaurant.getOrderById(orderId);
					if(order ==null){
						System.out.println("This order does not exist.");
					}
					System.out.println("1: Add order items to order");
					System.out.println("2: Remove order items from order");
					System.out.println("3: Quit");
					choice2=sc.nextInt();
					switch(choice2) 
					{
						case 1:	//add stuff to the order
						{
							//add food
							do{
								System.out.println("1: Enter the food id and the amount");
								System.out.println("2: Quit");
								choice2=sc.nextInt();
								if(choice2 ==1)
								{
									System.out.println("Enter the food id:");
									int id=sc.nextInt();
									System.out.println("Enter the amount:");
									int quantity=sc.nextInt();
									order.addFood(id, quantity);
								}
							}while(choice2 ==1);
							//add promoset
							do{
								System.out.println("1: Enter the promotional set id and the amount");
								System.out.println("2: Quit");
								choice2=sc.nextInt();
								if(choice2 ==1)
								{
									System.out.println("Enter the promotional set id:");
									int id=sc.nextInt();
									System.out.println("Enter the amount:");
									int quantity=sc.nextInt();
									order.addPromoSet(id, quantity);

								}
							}while(choice2 ==1);
							break;
						}
						case 2: // remove from order
						{
							order.printOrder();
							//remove food
							do{
								System.out.println("1: Enter the food id and the amount");
								System.out.println("2: Quit");
								choice2=sc.nextInt();
								if(choice2 ==1)
								{
									System.out.println("Enter the food id:");
									int id=sc.nextInt();
									System.out.println("Enter the amount:");
									int quantity=sc.nextInt();
									order.removeFood(id, quantity);
								}
							}while(choice2 ==1);
							//remove promoset
							do{
								System.out.println("1: Enter the promotional set id and the amount");
								System.out.println("2: Quit");
								choice2=sc.nextInt();
								if(choice2 ==1)
								{
									System.out.println("Enter the promotional set id:");
									int id=sc.nextInt();
									System.out.println("Enter the amount:");
									int quantity=sc.nextInt();
									order.removePromoSet(id, quantity);

								}
							}while(choice2 ==1);
							break;
						}
						default: break;
					}
					break;
				}
				case 6://Reservation booking
				{
					sc.nextLine(); // flush
					System.out.print("Pleases enter the customer name:");
					String name = sc.nextLine();
	
					// Input customer contact number
					System.out.print("Contact: ");
					int contact = sc.nextInt();
			
					// Input date of the reservation
					System.out.println("Input arrivlal date to reserve (Format: yyyy-MM-dd, e.g. 2014-01-01): ");
					SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
					sc.nextLine(); //flush
					String dateStr = sc.nextLine();
					// Input time of the reservation
					System.out.println("Input arrivlal time to reserve (Format: HH:MM:00, e.g. 18:00:00): ");
					SimpleDateFormat timeformat = new SimpleDateFormat("HH-MM-SS");
					String timeStr = sc.nextLine();
					
					// Parse and format the String input
					LocalDate arrDate;
					LocalTime arrTime;
					try {
						arrDate = LocalDate.parse(dateStr);
						arrTime = LocalTime.parse(timeStr);
					} catch (Exception e) {
						System.out.println("Error: Wrong date format!");
						e.printStackTrace();
						continue;
					}
					
					// Input number of people 
					System.out.println("Input number of people: ");
					int pax = sc.nextInt();
					
					// Check for any expired reservations
					restaurant.deleteExpiredRes();
					
					// Search a suitable table for this reservation
					boolean result = restaurant.newReservation(name,contact,pax,arrDate,arrTime);
					
					// If table is null, it means the restaurant is full
					if (result == false) {
						System.out.println("No table is allocated because the restaurant is full or no table with enough seats is available!");
					} 
					// If true, create the reservation
					else {
						System.out.println("A new reservation is created.");
					}
					break;
				}
				case 7:// Check/Remove reservation booking
				{
			
					// Options
					System.out.println("1. Check reservation");
					System.out.println("2. Remove reservation");
					System.out.println("3. Back");
					
					System.out.println("Enter your choice: ");
					choice2 = sc.nextInt();
					
					System.out.println("Contact Number?");
					int hp = sc.nextInt();
					restaurant.checkReservation(hp, choice2);
					break;
					
				}
				
				case 8 :
				{
					restaurant.checkAvailability();
				}
				
				default:{
					{System.out.println("ERROR");}
					break;
				}
			}
			
		}while (choice != 11);
	}
}
