package resterauntReservationApp;
import java.time.LocalDate;
import java.util.Scanner;
public class Restaurant(1) {
	
	public static void main(String[]args){
		Menu menu =new Menu();
		//TableMgr tableMgr = new TableMgr(); 	
		//OrderMgr orderMgr = new OrderMgr();
		//ReservationMgr reservationMgr =new ReservationMgr();
		//StaffMgr staffMgr = new StaffMgr();
		//MemberMgr memberMgr = new MemberMgr();
		Scanner sc=new Scanner(System.in);
		int choice,choice2, choice3, staffId,tableNumber, reservationId,id,numPeople,amount,orderId;
		double price;
		String name, description;
		Food fo;
		PromoSet ps;
		do{
			System.out.println("1: Create/Update/Remove menu item ");
			System.out.println("2: Create/Update/Remove promotion");
			System.out.println("3: Create Order");
			System.out.println("4: View Order");
			System.out.println("5: Add/Remove order item/s to/from order");
			System.out.println("6: Create reservation booking");
			System.out.println("7: Check/Remove reservation booking");
			System.out.println("8: Check table availability");
			System.out.println("9: Print order invoice");
			System.out.println("10: Print sale revenue report by period");
			System.out.println("11: Quit");
			choice =sc.nextInt();
			switch(choice){
			case 1://add/update/remove food
				do{
					System.out.println("1: Create menu item");
					System.out.println("2: Update menu item");
					System.out.println("3: Remove menu item");
					System.out.println("4: Quit");
					choice2=sc.nextInt();
					switch(choice2){
					case 1://add food
                        System.out.print("ID:");
                        id = sc.nextInt();
                        System.out.print("Category:");
                        printCategories();
                        category = sc.nextLine();
						System.out.print("Name:");
						name =sc.nextLine();
						System.out.print("Price:");
						price=sc.nextDouble();
						System.out.print("Description:");
						
						/*** initiate here or pass to foodMgr to initiate to show composition ***/
						fo = new Food(id,name,price,description);
						menu.addFood(fo);
						menu.printMenu();
						break;
					case 2://update food
						System.out.print("Enter the food id");
						id=sc.nextInt();
						fo = menu.getFoodById(id);
						do{
							System.out.println("1: Update name");
							System.out.println("2: Update price");
							System.out.println("3: Update description");
							System.out.println("4: Quit");
							choice3= sc.nextInt();
							switch(choice3){
							case 1:
								System.out.print("Enter food name:");
								name=sc.nextLine();
								/*** set name here or pass the user input to mgr **/
								fo.setName();
								menu.printMenu();
								break;
							case 2:
								System.out.print("Enter food price:");
								price=sc.nextDouble();
								fo.setPrice();
								menu.printMenu();
								break;
							case 3:
								System.out.print("Enter food description:");
								description=sc.nextLine();
								fo.setDescription();
								menu.printMenu();
								break;
							case 4:
								break;			
							
							}
						}while(choice3>0 &&choice3<4);
						break;
					case 3://remove food
						System.out.print("Enter the food id:");
						id=sc.nextInt();
						menu.removeFood(id);
						menu.printMenu();
						break;
					case 4:
						break;
					}
				}while(choice2>0&&choice2<4);
				break;
			case 2://add/update/remove promoset
				do{
					System.out.println("1: Create promotion");
					System.out.println("2: Update promotion");
					System.out.println("3: Remove promotion");
					System.out.println("4: Quit");
					choice2 = sc.nextInt();
					switch(choice2){
					
					/*** initiate promoSet need array of Food (String foodListStr ) ***/
					case 1://add promoset
						System.out.print("Name:");
						name =sc.nextLine();
						System.out.print("Price:");
						price=sc.nextDouble();
						System.out.print("Description:");
						ps = new PromoSet(name,price, description);
						menu.addPromoSet(ps);
						menu.printMenu();
						break;
					case 2://update promoset//
						System.out.print("Enter the promotion id:");
						id=sc.nextInt();
						ps= menu.getPromoSetById(id);
						do{
							System.out.println("1: Update name");
							System.out.println("2: Update price");
							System.out.println("3: Update description");
							System.out.println("4: Quit");
							choice3= sc.nextInt();
							switch(choice3){
							case 1:
								System.out.print("Enter promotion name:");
								name = sc.nextLine();
								ps.setName(name);
								menu.printMenu();
								break;
							case 2:
								System.out.print("Enter promotion price:");
								price =sc.nextDouble();
								ps.setPrice();
								menu.printMenu();
								break;
							case 3:
								System.out.print("Enter promotion description:");
								description=sc.nextLine();
								ps.setDescription();
								menu.printMenu();
								break;
							case 4:
								break;
					
							}
						}while(choice3>0 && choice3<4);
						break;
					case 3://remove promoset
						System.out.print("Enter the promotion id:");
						id=sc.nextInt();
						menu.removePromoSet(id);
						menu.printMenu();
						break;
					case 4:
						break;
					}
				}while(choice2>0 && choice2<4);
				break;
			case 3://create an order
				 /****************************
                System.out.print("pax:");
                pax = sc.nextLine();
                table = tableMgr.findAvailableTable(pax);
                ****************************/
				
				System.out.print("Enter the table number:");
				tableNumber= sc.nextInt();
				table = tableMgr.getTableById(tableNumber);				
				
				//check if the table is occupied
				if (tableMgr.tableStatus(tableNumber)==false)
					System.out.println("This table is not occupied");
				else{
					System.out.println("This table is occupied");
					continue;}
				
				//check the capacity
				System.out.println("Enter the number of people");
				numPeople=sc.nextInt();
				if (tableMgr.tableCapacity(tableNumber)>= numPeople)
					System.out.println("This table has enough capacity");
				else{
					System.out.println("This table is not big enough");
					continue;
				}
				
				// Assign a Staff to the Order
				System.out.print("Enter staff ID: ");
				staffId = sc.nextInt();
				staff = staffMgr.getStaffById(staffId);
				
								
				// Create new order 
				order = orderMgr.createOrder(table,staff);
				// get order id
				System.out.print("Give Id to this order:");
				orderId=sc.nextInt();
				order.setOrderId(orderId);
				// Print menu
				menu.printMenu();
				
				//add food
				do{
					System.out.println("1: Enter the food id and the amount");
					System.out.println("2: Quit");
					choice2=sc.nextInt();
					switch(choice2){
					case 1:
						System.out.print("Enter the food id:");
						id=sc.nextInt();
						fo=menu.getFoodById(id);
						Sytstem.out.print("Enter the amount:");
						amount=sc.nextInt();
						order.addFood(fo,amount);
						break;
					case 2:
						break;
					}
					
				}while(choice2<2 && choice2>0);
				//add promoset
				do{
					System.out.println("1: Enter the promoset id and the amount");
					System.out.println("2: Quit");
					choice2=sc.nextInt();
					switch(choice2){
					case 1:
						System.out.print("Enter the promoset id:");
						id=sc.nextInt();
						ps=menu.getPromoSetById(id);
						Sytstem.out.print("Enter the amount:");
						amount=sc.nextInt();
						order.addPromoSet(ps,amount);
						break;
					case 2:
						break;
					}
				}while(choice2<2 &&choice2>0);
				
				break;
			case 4://view order
				System.out.print("Enter the order id:");
				orderId=sc.nextInt();
				order= orderMgr.getOrderById(orderId);
				if(order ==null){
					System.out.println("This order does not exist.");
					continue;}
				else:
					order.printOrder();
				break;
			case 5://Add/Remove order item/s to/from order
				System.out.print("Enter the order id:");
				orderId=sc.nextInt();
				order= orderMgr.getOrderById(orderId);
				if(order ==null){
					System.out.println("This order does not exist.");
					continue;}
			
				System.out.println("1: Add order items to order");
				System.out.println("2: Remove order items from order");
				System.out.println("3: Quit");
				choice2=sc.nextInt();
				switch(choice2) {
				case 1:	//add stuff to the order			
					menu.printMenu();
					//add food
					do{
						System.out.println("1: Enter the food id and the amount");
						System.out.println("2: Quit");
						choice2=sc.nextInt();
						switch(choice3){
						case 1:
							System.out.print("Enter the food id:");
							id=sc.nextInt();
							fo=menu.getFoodById(id);
							Sytstem.out.print("Enter the amount:");
							amount=sc.nextInt();
							order.addFood(fo,amount);
							break;
						case 2:
							break;
						}
						
					}while(choice3<2 && choice3>0);
					//add promoset
					do{
						System.out.println("1: Enter the promoset id and the amount");
						System.out.println("2: Quit");
						choice2=sc.nextInt();
						switch(choice2){
						case 1:
							System.out.print("Enter the promoset id:");
							id=sc.nextInt();
							ps=menu.getPromoSetById(id);
							Sytstem.out.print("Enter the amount:");
							amount=sc.nextInt();
							order.addPromoSet(ps,amount);
							break;
						case 2:
							break;
						}
					}while(choice2<2 &&choice2>0);
					break;
				case 2:
					order.printOrder();
					//remove food
					do{
						System.out.println("1: Enter the food id and the amount");
						System.out.println("2: Quit");
						choice2=sc.nextInt();
						switch(choice3){
						case 1:
							System.out.print("Enter the food id that you want to remove:");
							id=sc.nextInt();
							//should i check if the food that customer wants to remove is not in the order?
							 /****************************
	                         
	                         ****************************/
							fo=menu.removeFoodById(id);
							Sytstem.out.print("Enter the amount that you want to remove:");
							amount=sc.nextInt();
							order.removeFood(fo,amount);
							break;
						case 2:
							break;
						}
						
					}while(choice3<2 && choice3>0);
					//remove promoset
					do{
						System.out.println("1: Enter the promoset id and the amount");
						System.out.println("2: Quit");
						choice2=sc.nextInt();
						switch(choice2){
						case 1:
							System.out.print("Enter the promoset id that you want to remove:");
							id=sc.nextInt();
							//should i check if the promoset that customer wants to remove is not in the order?
							ps=menu.removePromoSetById(id);
							System.out.print("Enter the amount that you want remove:");
							amount=sc.nextInt();
							order.removePromoSet(ps,amount);
							break;
						case 2:
							break;
						}
					}while(choice2<2 &&choice2>0);
				
				break;
			case 6://Reservation booking
				System.out.print("Pleases enter the customer name:");
				name = sc.nextLine();
/*				
				do{

                    System check whether the customer is a member in its membership list

					System.out.println("Does the customer has a membership?");
					System.out.println("1: Yes");
					System.out.println("2: No");
					choice2=sc.nextInt();
					switch(choice2){
					case 1:
						System.out.println("Please enter the membership id");
						break;
					case 2:
						break;
					}
				}while (choice2>0 && choice2<2);
				do {
					print("Membership (Y/N)? ");
					membershipString = sc.nextLine();
					
					if (membershipString.equalsIgnoreCase("y")) {
						membership = true;
					} else if (membershipString.equalsIgnoreCase("n")) {
						membership = false;
					} else {
						println("Error: Please enter only Y or N!");
					}
				} while (!membershipString.equalsIgnoreCase("y") && !membershipString.equalsIgnoreCase("n"));
*/		
				// Input customer contact number
				print("Contact: ");
				contact = sc.nextLine();
		
				// Input date of the reservation
				System.out.println("Input arrivlal date to reserve (Format: yyyy-MM-dd, e.g. 2014-01-01): ");
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				dateString = sc.nextLine();
				// Input time of the reservation
				System.out.println("Input arrivlal time to reserve (Format: HH:MM:00, e.g. 18:00:00): ");
				SimpleDateFormat format = new SimpleDateFormat("HH-MM-SS");
				timeString = sc.nextLine();
				
				// Parse and format the String input
				try {
					LocalDate arrDate = LocalDate.parse(dateStr);
					LocalTime arrTime = LocalTime.parse(timeStr);
				} catch (ParseException e) {
					println("Error: Wrong date format!");
					e.printStackTrace();
					continue;
				}
				
				// Input number of people 
				print("Input number of people: ");
				numPeople = sc.nextInt();
				
				// Check for any expired reservations
				tableMgr.deleteExpiredRes();
				
				// Search a suitable table for this reservation
				table = tableMgr.newReservation(name,contact,numPeople,arrDate,arrTime);
				
				// If table is null, it means the restaurant is full
				if (table == false) {
					println("No table is allocated because the restaurant is full or no table with enough seats is available!");
				} 
				// If true, create the reservation
				else {
					System.out.println("A new reservation is created.");
				}
				break;
			case 7:// Check/Remove reservation booking
				// Input reservation ID
				print("Enter reservation ID: ");
				reservationId = sc.nextInt();
								
				// Options
				println("1. Check reservation");
				println("2. Remove reservation");
				println("3. Back");
				
				// Submenu selection
				print("Enter your choice: ");
				subChoice = sc.nextInt();
				
				switch (subChoice) {
				case 1:
					// If checkReservation() returns 1, it will printout the details of the reservation
					// If it returns -1, the reservation with the specified ID does not exist
					if (reservationManager.checkReservation(reservationId) == -1) {
						println("Error: Reservation with ID: " + reservationId + " does not exist!");
					}
					
					break;
					
				case 2:
					// If cancelReservation() returns 1, the reservation has been removed
					// Otherwise, the removal is unsuccessful
					if (reservationManager.cancelReservation(reservationId) == 1) {
						println("Reservation with ID: " + reservationId + " has been removed!");
					} else {
						println("Error: Reservation with ID: " + reservationId + " does not exist!");
					}
					
					break;
				}
				break;
			case 8://Check table availability
				// Input table number / ID
				
				 /****************************
                availability of all tables or a single table?
                ****************************/
				print("Input table number: ");
				tableId = sc.nextInt();
				
				// Get the Table object with the specified number / ID
				table = tableManager.getTableById(tableId);
				
				// Error checking
				if (table == null) {
					println("Error: Table number " + tableId + " does not exist!\n");
				} else {
					// Check whether the Table is available
					if (table.getAvailability()) {
						println("Table number " + tableId + " is available!");
					} else {
						println("Table number " + tableId + " is unavailable!");
					}
				}
				
				break;
			case 9://print invoice order
				// Input table number / ID
				print("Enter table number: ");
				tableId = sc.nextInt();
				sc.nextLine();
				
				// Get the Table object specified by the number / ID
				table = tableManager.getTableById(tableId);
				
				// Error checking
				if (table == null) {
					println("Error: Table number " + tableId + " does not exist!\n");
					continue;
				}
				
				// The table must be assigned if it wants to print the order invoice
				if (table.getAvailability()) {
					println("Error: Table number " + tableId + " does not have customer!\n");
					continue;
				}

				// Get Order object from Table 
				
				order = table.getOrder();
				
				// Error checking
				if (order == null) {
					println("Error: Table number " + tableId + " does not have any order!\n");
					continue;
				}
				
				/*
				 * 	Checking of customer membership:
				 * 	1. Check whether there is a reservation for this table and its status is "checked-in" currently
				 * 	2. If there is, it means the customer of this table is customer with reservation
				 * 		- Get the customer membership through the Reservation object
				 *  3. If there is not, it means the customer is a walk-in customer
				 *  	- Directly ask whether the customer has a membership
				 */
				
				reservation = reservationManager.getReservationByTableId(tableId, "Checked-in");
				if (reservation == null) {
					print("Membership (Y/N)? ");
					membershipString = sc.nextLine();
					
					if (membershipString.equalsIgnoreCase("y")) {
						membership = true;
					} else {
						membership = false;
					}
					
					table.setAvailability(true);
					
				} else {
					membership = reservation.getCustomer().getMembership();
					
					// Release the reservation + table (See Reservation.setStatus())
					reservation.setStatus("Finished");
				}
				
				// Close the order AND release the table
				order.setStatus("Closed");
				table.setOrder(null);
				
				
				// Create Order Invoice
				orderInvoice = orderInvoiceManager.createOrderInvoice(order, membership, tableId);
				
				// Print the order invoice
				orderInvoice.printInvoice();
				break;
			case 10://revenue
				String period;
				int check;
				
				// Input the revenue report period
				print("Enter period (MMYYYY or DDMMYYYY): ");
				period = sc.next();
				
				// Print the report and check the return value
				check = RevenueReport.printReport(period, orderInvoiceManager.getOrderInvoices());
				if (check == -1)
				{
					println("Error: There is no order invoice within the specified date or month!");
				}
				else if (check == -2)
				{
					println("Error: Wrong period input! Please give the period in the format of MMYYYY or DDMMYYYY");
				}
				break;
			case 11:
				break;
			}
		}while(choice>0 && choice<11);	}

}
//*Qns: promoset linked with food???
	/*** promoSet contains ArrayList<Food> ***/
//should we create table, staff in the form of database
	/***cannot use database I think, actually I'm not sure I get what you mean ***/ 
//when remove/update promoset/food should check if the thing exists in the menu
	/***can call promoset/food manager to check, if not in menu, manager will return -1 ***/
//when add food/promoset should create a copy???
	/***hmmm, interesting, if food/promoset cannot be modified in order, then no need create a copy ba ***/