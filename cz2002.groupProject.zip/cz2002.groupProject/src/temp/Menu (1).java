package resterauntReservationApp;
import java.util.ArrayList;



public class Menu (){
  
	private ArrayList<Food> food = new ArrayList();
	private ArrayList<PromoSet> promoSet = new ArrayList(); 
	private ArrayList<Staff> staff = new ArrayList();
	private ArrayList<Table> table = new ArrayList();
	private ArrayList<Reservation> reservation = new ArrayList();
	private ArrayList<Order> order = new ArrayList();
	private ArrayList<Member> member = new ArrayList();
    
	
	
	public Menu() {
		food = new ArrayList<Food>;
		promoSet = new ArrayList<PromoSet>;
		staff = new ArrayList<Staff>;
		table = new ArrayList<Table>;
		reservation= new Array<Reservation>;
		order =new Array<Order>;
		member=new Array<Member>;
		}
	
	
	
	public ArrayList<Food> getFood(){
		return food;}
	public ArrayList<PromoSet> getPromoSet(){
		return promoSet;}
	
	
	
	////////////////////////////////
	public ArrayList<Staff> getStaff(){
		return staff;}
	public ArrayList<Table> getTable(){
		return table;}
	public ArrayList<Reservation> getReservation(){
		return reservation;}
	public ArrayList<Order> getOrder(){
		return order;}
	public ArrayList<Member> getMember(){
		return member;}
	
	///////////////////////////////////	
 
	//get something by entering the id
	public Food getFoodById(int id){		
		for(int i=0;i<food.size();i++){
			if(food.get(i).getFoodId() ==id)
				return food.get(i);
			}}
	public PromoSet getPromoSetById(int id){
		for(int i=0; i<promoSet.size();i++){
			if(promoSet.get(i).getPromoSetId()== id)
				return promoSet.get(i);	}
		
	}
	
	//add something
	public void addFood(Food fo){
		
		food.add(fo);		
	}
	public void addPromoSet(PromoSet ps){
		
		promoSet.add(ps);
	}


	//remove something
	public 	void removeFood(int id){
		for(int i=0;i<food.size();i++){
			if(food.get(i).getFoodId()==i)
				food.remove(i);
		}
		printMenu();
	}
	public void removePromoSet(int id){
		for(int i=0; i<promoSet.size();i++){
			if(promoSet.get(i).getPromoSetId()==i)
				promoSet.remove(i);}
		printMenu();
	}
	
    //print menu
	public void printMenu () {
		System.out.println("***********************************");
		System.out.println("             Menu                  ");
		System.out.println("***********************************");
		
		
		System.out.println("************Food*******************");
		for(int i=0;i<food.size();i++)
			food.get(i).printFood();
		System.out.println("**********PromoSet*****************");
		for(int i=0;i<promoSet.size();i++)
			promoSet.get(i).printPromoSet();
		System.out.println("**********End**********************");
		
	}
		
		
		
}