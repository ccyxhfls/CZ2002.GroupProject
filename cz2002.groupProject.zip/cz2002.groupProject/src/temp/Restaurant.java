package restaurantReservationApp;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Restaurant {

	private FoodMgr foodMgr;
	private PromoSetMgr promoSetMgr;
	private OrderMgr orderMgr;
	private TableMgr tableMgr;
	private StaffMgr staffMgr;
	
	public Restaurant(){
		foodMgr = new FoodMgr();
		promoSetMgr = new PromoSetMgr();
		tableMgr = new TableMgr();
		staffMgr = new StaffMgr();
		orderMgr = new OrderMgr();
	}
	
	public void addFood(int ID, String name, double price, int category, String description) {
		foodMgr.addFood(ID, name, price, category, description);
	}
	
	public void removeFood (int ID){
		foodMgr.removeFood(ID);
	}
	
	public void updateFood(int ID, int choice, String value ){
		foodMgr.updateFood(ID, choice, value);
	}
	
	
	/*public void addPromoSet(int ID, String name, String foodListStr, double price, String description) {
		
		ArrayList<Food> foodList = new ArrayList<Food>();
		String[] IDList = foodListStr.split(" ");
		for (int i = 0; i < IDList.length; i++){
			Food food = foodMgr.searchFood(Integer.parseInt(IDList[i]));
			foodList.add(food);
		}
		promoSetMgr.addPromoSet(ID, name, foodList, price, description);
		
	}*/
	
	
	public void removePromoSet(int ID) {
		promoSetMgr.removePromoSet(ID);
	}


	public void printCategories() {
		foodMgr.printCategories();
	}

	public void checkAvailability() {
		tableMgr.printTableStatus();	
	}

	public void deleteExpiredRes() {
		tableMgr.deleteExpiredRes();
	}

	public boolean newReservation(String name, int contact, int pax, LocalDate arrDate, LocalTime arrTime) {
		return tableMgr.newReservation(name, contact, pax, arrDate, arrTime);
	}

	public void checkReservation(int hp , int choice) {
		tableMgr.checkReservation(hp,choice);
	}

	public Staff getStaffById(int staffId) {
		return staffMgr.searchStaff(staffId);
	}

	public Order createOrder(int pax, int staffId) {
		Table table = tableMgr.findAvailableTable(pax);
		int tableId = table.getTableID();
		Order order = orderMgr.addOrder(tableId, staffId);
		return order;
	}

	public Order getOrderById(int orderId) {
		return orderMgr.getOrderById(orderId);
	}

	public void updatePromoSet(int id, int c, String value) {
		promoSetMgr.updatePromoSet(id, c, value);
		
	}

	public void printMenuByCategory(int c) {
		foodMgr.printMenuByCategory(c);
		
	}

	public void printMenu() {
		foodMgr.printMenu();	
	}

	public void printPromoSets() {
		promoSetMgr.printPromoSets();
		
	}

	

	

	

	

	

	
	
	

	
}
