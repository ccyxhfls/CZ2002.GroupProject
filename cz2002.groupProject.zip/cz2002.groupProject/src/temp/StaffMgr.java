package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Iterator;

import restaurantReservationApp.Staff.Gender;

public class StaffMgr {
	ArrayList <Staff> staffList;
	
	public StaffMgr (){
		staffList = new ArrayList<Staff>();
		Staff s = new Staff("Shi", Gender.Female, 111, "manager");
		staffList.add(s);
	}

	public Staff getStaffById(int Id) {
		Iterator<Staff> itr = staffList.iterator();
		while(itr.hasNext()){
			Staff staff = itr.next();
			if (staff.getempID() == Id){
				return staff;
			}
		}
		return null;
	}
}
