package restaurantReservationApp;

//import java.text.SimpleDateFormat;
import java.time.*;

public class Reservation {
	private String name;
	private int contactNum;
	private int noOfPax;
	private int tableId;
	LocalDate arrDate;
	LocalTime arrTime;
	
	public Reservation(){}
	
	public Reservation(String name, int contactNum, int noOfPax, int tableId, LocalDate date, LocalTime time){
		this.name = name;
		this.contactNum = contactNum;
		this.noOfPax = noOfPax;
		this.tableId = tableId; 
		arrDate = date;
		arrTime = time;
	}
	
	public int getTableId(){
		return tableId;
	}
	
	public LocalTime getArrTime(){
		return arrTime;
	}
	
	public LocalDate getArrDate(){
		return arrDate;
	}
		
	public String getCustName(){
		return name;
	}
	
	public int getContactNum(){
		return contactNum;
	}
	
	public int getPax(){
		return noOfPax;
	}
	
	public void setArrTime(LocalTime time){
		arrTime = time;
	}
	
	public void setArrDate(LocalDate date){
		arrDate = date;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public void setContact(int num){
		contactNum = num;
	}
	
	public void setPax(int pax){
		noOfPax = pax;
	}
	
}
