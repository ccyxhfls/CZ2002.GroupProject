package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Iterator;


public class PromoSetMgr {
	private ArrayList<PromoSet> promoSetList = new ArrayList<PromoSet>();

	public PromoSetMgr(){
		FileMgr.loadPromoSet(this);
	}
	
	public void addPromoSet(int ID, String name, ArrayList<Food> foodList, double price, String description) {
		PromoSet promoSet = new PromoSet(ID, name, foodList, price, description);
		promoSet.print();
		promoSetList.add(promoSet);
	}
	
	public void AddPromoSet(PromoSet promoSet) {
		promoSetList.add(promoSet);	
	}

	
	public PromoSet removePromoSet(int ID){
		PromoSet promoSet = searchPromoSet(ID);
		promoSetList.remove(promoSet);
		return promoSet;
	}
	  PromoSet searchPromoSet(int ID){
		Iterator<PromoSet> itr = promoSetList.iterator();
		while(itr.hasNext()){
			PromoSet promoSet = itr.next();
			if (promoSet.getID() == ID){
				return promoSet;
			}
		}
		return null;
	}
	
	public PromoSet addFood (int ID, Food food){
		PromoSet promoSet = searchPromoSet(ID);
		promoSet.addFood(food);
		return promoSet;
	}
	
	public PromoSet removeFood (int ID, Food food){
		PromoSet promoSet = searchPromoSet(ID);
		promoSet.removeFood(food);
		return promoSet;
	}
	
	public void printPromoSet(){
		Iterator<PromoSet> itr = promoSetList.iterator();
		while(itr.hasNext()){
			PromoSet promoSet = itr.next();
			promoSet.print();
		}
	}


	public void updateName(int ID, String name) {
		PromoSet promoSet = searchPromoSet(ID);

	}


	public void updatePrice(int ID, double price) {
		PromoSet promoSet = searchPromoSet(ID);
		promoSet.setDiscountPrice(price);
	}


	public void updateDescription(int ID, String description) {
		PromoSet promoSet = searchPromoSet(ID);
		promoSet.setDescription(description);
		
	}


	

	
}
