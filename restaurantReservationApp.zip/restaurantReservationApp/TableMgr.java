package restaurantReservationApp;

import java.io.*;
import java.time.*;
import java.util.ArrayList;

// !!need a function at main system to switch between AM and PM session to activate the reservation status.
// IMPORTANT REMINDER
public class TableMgr {
	private Table[] tables;
	public Reservation[][][] matrix;
	LocalDate currentDate;
	LocalTime currentTime;
	int tableNum; // in this project, it is 30 tables.
	int days; // in this project, it is set as one month (30 days)
	
	public TableMgr(){ // always pass in (30,30) in this project
		this.tableNum = 30;
		this.days = 30;
		tables = new Table[tableNum];
		matrix = new Reservation[days][tableNum][2]; // 2- AM & PM
		FileMgr.loadTables(tables);
		FileMgr.loadReservationMatrix(matrix);
		
		currentDate = LocalDate.now(); // retrieve current date
		currentTime = LocalTime.now(); // retrieve current time
		if (currentTime.getHour() < 12 )
			setReservationAM();
		else
			setReservationPM();		
	}

	
	//check all table availability
	public void printTableStatus(){
		for (int i = 0; i < tableNum; i++){
			if (tables[i] == null)
				System.out.println("sad");
			else
				System.out.println("happy");
			System.out.println("Table status" + tables[i].getTableID() + "is" + tables[i].getStatus());
		}
	}
	
	public void setReservationAM(){
		for (int i = 0; i < tableNum; i++){
			if (matrix[0][i][0] != null){
				tables[i].changeStatus("reserved");
			}
		}
	}
	
	public void setReservationPM(){
		for (int i = 0; i < tableNum; i++){
			if (matrix[0][i][1] != null){
				tables[i].changeStatus("reserved");
			}
		}
	}
	
	public boolean newReservation(String name, int contact, int pax,LocalDate arrDate, LocalTime arrTime){
        if (arrDate.compareTo(currentDate) >= 0 && arrDate.compareTo(currentDate) < 30){
        	Reservation res = new Reservation(name, contact, pax,arrDate, arrTime);
        	int daysAfterToday = arrDate.compareTo(currentDate);
        	boolean isAM = arrTime.getHour() < 12;
         	int index = 0;
         	if (!isAM){ index = 1;} // if it's PM reservation, goes to matrix cell index 1.
        	for (int i = 0; i < tableNum; i++){
            	if (pax <= tables[i].getCapacity() && matrix[daysAfterToday][i][index] == null){
                	matrix[daysAfterToday][i][index] = res;
                 	System.out.println("Your reservation is successful.");
                 	return true;
                }
        	}
        	System.out.println("Sorry, there is no more available tables on that date and time slot for reservation.");
            return false;
        }
        else{
        	System.out.println("You cannot make reservation on that date.");
        	return false;
        }
}
	
	// method to delete expired reservation at current moment
	public void deleteExpiredRes(){ //will only check current day's reservation
		currentTime = LocalTime.now();
		for (int i = 0; i < tableNum; i++) {
			for (int j = 0; j < 2; j++){
				LocalTime expiryTime = matrix[0][i][j].getArrTime().plusMinutes(30); // get expiryTime = arrTime + 30mins
				if (expiryTime.compareTo(currentTime) < 0){ //expiryTime past already
					matrix[0][i][j] = null; //delete expired reservations
				}
			}
		}
	}

	
	// method to assign dine-in guests without prior reservation to a table.
	public boolean tableAssignNoReservation(int pax){
		deleteExpiredRes();
		for (int k = 1; k < tableNum; k++){
			if (pax < tables[k].getCapacity() && tables[k].getStatus() == "vacated"){
				System.out.println("Table assigned successfully with table id " + tables[k].getTableID());
				tables[k].changeStatus("occupied");
				return true;
			}
		}
		System.out.println("There is no available table for current guest.");
		return false;
	}
	
	// method to assign guest with prior reservation to designated table
	public void tableAssignWithReservation(int contactNum, boolean isAM){
		if (isAM){ // Check for AM reservation
			for (int i = 0; i < tableNum; i++){
				if (contactNum == matrix[0][i][0].getContactNum()){
					System.out.println("The guest reserves table with tableID " + tables[i].getTableID());
					tables[i].changeStatus("occupied");
					return;
				}
			}
		} // Check for PM reservation
		else {
			for (int i = 0; i < tableNum; i++){
				if (contactNum == matrix[0][i][1].getContactNum()){
					System.out.println("The guest reserves table with tableID " + tables[i].getTableID());
					tables[i].changeStatus("occupied");
					return;
				}
			}
		}
	}
	
	// method to up-shift the whole matrix by one when the next day is coming
	public void matrixShiftUp(){
		for (int j = 0; j < days-1; j++){
			matrix[j] = matrix[j+1];
		}
		matrix[days-1] = new Reservation[tableNum-1][2]; // set last line (the last day) as empty since no reservation yet
	}
	
	// export reservation matrix into a reservation txt file which contains all reservations.
	public void exportTables(String fileName){
		try{
			FileWriter fileWriter = new FileWriter(fileName);
			PrintWriter printWriter = new PrintWriter(fileWriter);
			
			// create matrix of 0s and 1s to indicate the presence of reservation for file I/O purpose
			int[][][] ifReservedMatrix = new int[days][tableNum][2];
			// create ArrayList of reservations for file I/O purpose
			ArrayList<Reservation> resList = new ArrayList<Reservation>();
						
			// traverse through reservation matrix
			for (int i = 0; i < days; i++){
				for (int j = 0; j < tableNum; j++){
					for (int k = 0; k < 2; k++){
						if (matrix[i][j][k] != null){
							ifReservedMatrix[i][j][k] = 1; // indicate there is element inside the index
							resList.add(matrix[i][j][k]);
						}
						else
							ifReservedMatrix[i][j][k] = 0; // indicate there is not any element inside the index
					}
				}
			}
			printWriter.println("Reservation Reference list:");
			// print a list of 0s and 1s to be used as a reference for reservation file read in.
			for (int i = 0; i < days; i++){
				for (int j = 0; j < tableNum; j++){
					for (int k = 0; k < 2; k++){
						printWriter.print(ifReservedMatrix[i][j][k]+",");
					}
				}
			}
			printWriter.println("\nReservations:");
			Reservation res = resList.get(0);
			while (res != null){
				String resInfo = res.getCustName() +"," 
						+ String.valueOf(res.getContactNum()) + "," 
						+ String.valueOf(res.getPax()) + "," 
						+ res.getArrDate().toString() + "," 
						+ res.getArrTime().toString();
				printWriter.println(resInfo);
			}
			printWriter.close();
		}
		catch (IOException e){
			System.out.println("Error in exporting the file!");
		}
	}
	
	
	
	// Construct a new set of tables.
/*	public void tablesConstruct(){
		for (int a = 0; a < 10; a++){
			tables[a] = new Table(a+1,2,"vacated");
		}
		for (int b = 10; b < 20; b++){
			tables[b] = new Table(b+1,4,"vacated");
		}
		for (int c = 20; c < 25; c++){
			tables[c] = new Table(c+1,8,"vacated");
		}
		for (int d = 25; d < 30; d++){
			tables[d] = new Table(d+1,10,"vacated");
		}
		// check reservation for the current day (later used for walk-in guest
		for (int e = 0; e < tableNum; e++){
			if (matrix[0][e][0] != null && currentTime.getHour() < 12){
				tables[e].changeStatus("reserved");
			}
			if (matrix[0][e][1] != null && currentTime.getHour() >= 12){
				tables[e].changeStatus("reserved");
			}
		}
	}
*/
	
	// Load existing table information from system file.
/*	public void tablesLoaded(){
		tables = loadTables ("Tables.txt");
	}
*/
}
