package restaurantReservationApp;

public class Staff {
	
	enum Gender {Male, Female};
	
	private String name;
	private int empID;
	private String jobTitle;
	private Gender gender;
	
	public Staff(String name, Gender gender, int empID, String jobTitle){
		
		this.name = name;
		this.gender = gender;
		this.empID = empID;
		this.jobTitle = jobTitle;
	}
	
	public String getName(){
		return name;
	}
	
	public Gender getGender(){
		return gender;
	}
	
	public int getempID(){
		return empID;
	}
	
	public String getJobTitle(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public void setGender(Gender gender){
		this.gender = gender;
	}
	
	public void setEmpID(int empID){
		this.empID = empID;;
	}
	
	public void setJobTitle(String jobTitle){
		this.jobTitle = jobTitle;
	}
}
