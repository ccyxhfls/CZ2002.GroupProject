package restaurantReservationApp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class FileMgr {

	public static void loadFood(FoodMgr foodMgr) {
		String fileName = "/Users/shiganyu/Documents/Eclipse/workspace/cz2002.groupProject/src/restaurantReservationApp/DB/foodDB.txt";
		Path pathToFile = Paths.get(fileName);
		try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.UTF_8)){
			String line = br.readLine();
			while(line != null){
				String[] attributes = line.split(",");
				foodMgr.addFood(attributes);
				line = br.readLine();
			}
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	}

	public static void loadPromoSet(PromoSetMgr promoSetMgr) {
		String fileName = "/Users/shiganyu/Documents/Eclipse/workspace/cz2002.groupProject/src/restaurantReservationApp/DB/promoSetDB.txt";
		Path pathToFile = Paths.get(fileName);
		try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.UTF_8)){
			int numOfSet = Integer.parseInt(br.readLine());
			for (int i = 0; i < numOfSet; i++){
				int setID = Integer.parseInt(br.readLine());
				PromoSet promoSet = new PromoSet(setID);
				int numOfFood = Integer.parseInt(br.readLine());
				for (int j = 0; j< numOfFood; j++){
					String foodStr = br.readLine();
					String[] attributes = foodStr.split(",");
					int foodID = Integer.parseInt(attributes[0]);
					Food food = FoodMgr.searchFood(foodID);
					promoSet.addFood(food);
				}
				double discountPrice = Double.parseDouble(br.readLine());
				promoSet.setPrice(discountPrice);
				promoSetMgr.AddPromoSet(promoSet);
			}
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	}
	
	public static void loadTables(Table[] tables){
		String fileName = "/Users/shiganyu/Documents/Eclipse/workspace/cz2002.groupProject/src/restaurantReservationApp/DB/tableDB.txt";
		Path pathToFile  = Paths.get(fileName);
		int count = 0;
		String line = null;
		try(BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.UTF_8)){
			while((line = br.readLine()) != null){
				String[] tableInfo = line.split(",");
				int tableID = (Integer.parseInt(tableInfo[0]));
				int Capacity = (Integer.parseInt(tableInfo[1]));
				String status = (tableInfo[2]);
				tables[count] = new Table (tableID, Capacity, status);
				count += 1;
			}
		}catch(IOException e){
			System.out.println("here");
			System.out.println(e.getMessage());
			System.out.println(e.getClass());
		}
	}


//import file with reservations data
	public static void loadReservationMatrix(Reservation[][][] matrix){
		int days = 30;
		int tableNum = 30;
		String fileName = "/Users/shiganyu/Documents/Eclipse/workspace/cz2002.groupProject/src/restaurantReservationApp/DB/reservationDB.txt";
		File file = new File(fileName);
		int[][] ifReservedMatrix = new int[days][tableNum * 2];
		ArrayList<Reservation> resList = new ArrayList<Reservation>();
		String resInfo = null;


		try{
			FileReader fr = new FileReader(file.getAbsoluteFile());
			BufferedReader br = new BufferedReader(fr);
			try{
				br.readLine(); // dummies are to store empty or useless lines to be discarded
				for (int i = 0; i< 30; i++){
					String line = br.readLine();
					String[] tableRes = line.split(",");
					for (int j =0; j < 60; j++){
						ifReservedMatrix[i][j] = Integer.parseInt(tableRes[j]);
					}
				}
				br.readLine(); //dummy
				br.readLine(); //dummy
				while((resInfo = br.readLine()) != null){
					String[] segmentInfo = resInfo.split(",");
					String guestName = segmentInfo[0];
					int contact = (Integer.parseInt(segmentInfo[1]));
					int pax = (Integer.parseInt(segmentInfo[2]));
					int tableId = (Integer.parseInt(segmentInfo[3]));
					LocalDate arrDate = LocalDate.parse(segmentInfo[4]); //may have errors
					LocalTime arrTime = LocalTime.parse(segmentInfo[5]); //may have errors
					Reservation res = new Reservation(guestName,contact,pax, tableId, arrDate,arrTime);
					resList.add(res);
				}
				br.close();
			}catch (IOException e){
				e.printStackTrace();
			}
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}
		
		int resIndex = 0;
		for (int i = 0; i < days; i++){
			for (int j = 0; j < tableNum; j++){
				for (int k = 0; k < 2; k++){
					if (ifReservedMatrix[i][2*j+k] == 0)
						matrix[i][j][k] = null;
					else{
						matrix[i][j][k] = resList.get(resIndex);
						resIndex++;
					}	
				}
			}
		}
	}	
}
