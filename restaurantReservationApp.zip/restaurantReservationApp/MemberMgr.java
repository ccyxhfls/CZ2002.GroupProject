package restaurantReservationApp;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;

public class MemberMgr {
	ArrayList<Member> memberList;
	
	public MemberMgr (String fileName){
		Path pathToFile = Paths.get(fileName);
		try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.UTF_16)){
			String line = br.readLine();
			while(line != null){
				String[] attributes = line.split(",");
				addMember(attributes);
				line = br.readLine();
			}
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	}
	
	public Member addMember(String[] attributes){
		String name = attributes[0];
		String IC = attributes[1];
		String gender = attributes[2];
		String hp = attributes[3];
		Member member = new Member (name, IC, gender, hp);
		return member;
	}
	
	public Member removeMember(String IC){
		Member member = searchMember(IC);
		memberList.remove(member);
		return member;
	}
	
	public Member updateMember(String IC, String hp){
		Member member = searchMember(IC);
		member.setHp(hp);
		return member;
	}
	
	private Member searchMember(String IC){
		Iterator<Member> itr = memberList.iterator();
		while(itr.hasNext()){
			Member member = itr.next();
			if (member.getIC().equalsIgnoreCase(IC)){
				return member;
			}
		}
		return null;
	}

}
