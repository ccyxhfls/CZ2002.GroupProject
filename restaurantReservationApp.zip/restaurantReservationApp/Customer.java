package restaurantReservationApp;

public class Customer {
	String name;
	String hp;
	int pts;
}
