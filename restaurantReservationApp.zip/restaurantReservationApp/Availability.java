package restaurantReservationApp;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Availability {
	Reservation[][] availability;
	
	public Availability (String fileName){
		Path pathToFile = Paths.get(fileName);
		try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.UTF_16)){
			String line = br.readLine();
			while(line != null){
				String[] attributes = line.split(",");
				addReservation(attributes);
				line = br.readLine();
			}
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	}
	public void addReservation(int tableID, String name, String hp, int pax, Calendar time) {
		int row =0;
		//row = date - today;
		int offset =0;
		//offset = morning? 0 :30;
		int col = tableID;
		Reservation reservation = new Reservation(tableID, name, hp, pax, time);
		availability[row][col] = reservation;
		
	} 
	public void addReservation(String[] attributes){
		int row = Integer.parseInt(attributes[0]);
		int col = Integer.parseInt(attributes[1]);
		int tableID = Integer.parseInt(attributes[2]);
		String name = attributes[3];
		String hp = attributes[4];
		int pax = Integer.parseInt(attributes[5]);
		Calendar time = new GregorianCalendar();
		// date format;
		Reservation reservation = new Reservation(tableID, name, hp, pax, time);
	}
	public int checkAvailability (Calendar time, int pax){
		
		int start = 0;
		int end = 30;
			
		switch (pax){
		case 1: case 2: start = 0;
		case 3: case 4: start = 10;
		case 5: case 6: case 7: start = 15;
		case 8: case 9: case 10: start = 20;
		}
		int offset = 0;
		//if(time > afternoon){
			//offset = 30;
			//start += afternoon;
			//end += afternoon;
		//}
		
		int row = 0;
		//int row = date - today;
		for (int col = start; col < end ; col++){
			if (availability[row][col] == null){
				return (col-offset);
			}
		}
		return -1;
		
	}
	
	public void cancelReservation (String date, String hp){
		int row = 0;
		//int row = date - today;
		for (Reservation reservation : availability[row]){
			if (reservation.getHp().equalsIgnoreCase(hp)){
				reservation = null;
			}
		}
	}

	

}
