package restaurantReservationApp;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Order {
	private int ID;
	private Calendar date;
	ArrayList<Food> foodList;
	ArrayList<PromoSet> promoSetList;
	Table table;
	
	public Order(int ID, ArrayList<Food> foodList, ArrayList<PromoSet> promoSetList, Table table) {
		this.ID = ID;
		date = new GregorianCalendar();
		this.foodList.addAll(foodList);
		this.promoSetList.addAll(promoSetList);
		this.table = table;
	}
	
	public int getID(){
		return ID;
	}

	public void addFood(Food food){
		foodList.add(food);
	}
	
	public void removeFood(Food food){
		foodList.remove(food);
	}
	
	public void addSet(PromoSet set){
		promoSetList.add(set);
	}
	
	public void removeSet(PromoSet set){
		promoSetList.remove(set);
	}
	
}
