package restaurantReservationApp;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Scanner;


public class RRPSS {
	public static Restaurant restaurant = new Restaurant();
	public static Scanner sc = new Scanner (System.in);
	
	public static void main(String[] args) {
		int choice, choice2, choice3;
		do 
		{
			System.out.println("**********************************************************");
			System.out.println("                     SCSE RESTAURANT                      ");
			System.out.println("**********************************************************");
			System.out.println("Enter number to perform corresponding action: ");
			System.out.println("1: Create/Update/Remove menu item ");
			System.out.println("2: Create/Update/Remove promotion");
			System.out.println("3: Create Order");
			System.out.println("4: View Order");
			System.out.println("5: Add/Remove order item/s to/from order");
			System.out.println("6: Create reservation booking");
			System.out.println("7: Check/Remove reservation booking");
			System.out.println("8: Check table availability");
			System.out.println("9: Print order invoice");
			System.out.println("10: Print sale revenue report by period");
			System.out.println("11: Quit");
			System.out.println("**********************************************************");
			
			choice = sc.nextInt();
			switch(choice)
			{
				case 1: //add/update/remove menu item
					case1();
					break;
				case 2://add/update/remove promoset
					case2();
					break;
				case 3://create an order
					case3();
					break;
				case 4://view order
					case4();
					break;
				case 5://Add/Remove order item/s to/from order
					case5();
					break;
				case 6://Reservation booking
				{
					case6();
					break;
					
				}
				case 7:// Check/Remove reservation booking
				{
					case7();
					break;
				}
				
				case 8 :
				{
					restaurant.checkAvailability();
				}
				
				default:
				{
					System.out.println("Please enter a number from 1 to 11");
					break;
				}
			}
			
		}while (choice != 11);
	}

	private static void case7() {
		System.out.println("1. Check reservation");
		System.out.println("2. Remove reservation");
		System.out.println("3. Back");
		
		System.out.println("Enter your choice: ");
		int c = sc.nextInt();
		
		System.out.println("Contact Number?");
		int hp = sc.nextInt();
		restaurant.checkReservation(hp, c);
		
	}

	private static void case6() {
		sc.nextLine(); // flush
		System.out.print("Pleases enter the customer name:");
		String name = sc.nextLine();

		// Input customer contact number
		System.out.print("Contact: ");
		int contact = sc.nextInt();

		// Input date of the reservation
		System.out.println("Input arrivlal date to reserve (Format: yyyy-MM-dd, e.g. 2014-01-01): ");
		SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
		sc.nextLine(); //flush
		String dateStr = sc.nextLine();
		// Input time of the reservation
		System.out.println("Input arrivlal time to reserve (Format: HH:MM:00, e.g. 18:00:00): ");
		SimpleDateFormat timeformat = new SimpleDateFormat("HH-MM-SS");
		String timeStr = sc.nextLine();
		
		// Parse and format the String input
		LocalDate arrDate;
		LocalTime arrTime;
		try {
			arrDate = LocalDate.parse(dateStr);
			arrTime = LocalTime.parse(timeStr);
		} catch (Exception e) {
			System.out.println("Error: Wrong date format!");
			e.printStackTrace();
			return;
		}
		
		// Input number of people 
		System.out.println("Input number of people: ");
		int pax = sc.nextInt();
		
		// Check for any expired reservations
		restaurant.deleteExpiredRes();
		
		// Search a suitable table for this reservation
		boolean result = restaurant.newReservation(name,contact,pax,arrDate,arrTime);
		
		// If table is null, it means the restaurant is full
		if (result == false) {
			System.out.println("No table is allocated because the restaurant is full or no table with enough seats is available!");
		} 
		// If true, create the reservation
		else {
			System.out.println("A new reservation is created.");
		}
	}

	private static void case5() {
		System.out.print("Enter the order id:");
		int orderId=sc.nextInt();
		Order order= restaurant.getOrderById(orderId);
		if(order ==null){
			System.out.println("This order does not exist.");
		}
		System.out.println("1: Add order items to order");
		System.out.println("2: Remove order items from order");
		System.out.println("3: Quit");
		int c=sc.nextInt();
		switch(c) 
		{
			case 1:	//add stuff to the order
			{
				addFood(order);
				addPromoSet(order);
				break;
			}
			case 2: // remove from order
			{
				order.printOrder();
				removeFood(order);
				removeRromoSet(order);
				
				break;
			}
			default: break;
		}
	}

	private static void removeRromoSet(Order order) {
		int c;
		do{
			System.out.println("1: Enter the promotional set id and the amount");
			System.out.println("2: Quit");
			c=sc.nextInt();
			if(c ==1)
			{
				System.out.println("Enter the promotional set id:");
				int id=sc.nextInt();
				System.out.println("Enter the amount:");
				int quantity=sc.nextInt();
				order.removePromoSet(PromoSetMgr.searchPromoSet(id), quantity);

			}
		}while(c ==1);	
	}

	private static void removeFood(Order order) {
		int c;
		do{
			System.out.println("1: Enter the food id and the amount");
			System.out.println("2: Quit");
			c=sc.nextInt();
			if(c ==1)
			{
				System.out.println("Enter the food id:");
				int id=sc.nextInt();
				System.out.println("Enter the amount:");
				int quantity=sc.nextInt();
				order.removeFood(FoodMgr.searchFood(id), quantity);
			}
		}while(c ==1);
		
	}

	private static void case4() {
		System.out.print("Enter the order id:");
		int orderId=sc.nextInt();
		Order order= restaurant.getOrderById(orderId);
		if(order ==null){
			System.out.println("This order does not exist.");
		}
		else
			order.printOrder();
	}

	private static void case3() {
		System.out.print("pax:");
        int pax = sc.nextInt();
		System.out.print("Enter staff ID: ");
		int staffId = sc.nextInt();
		Order order = restaurant.createOrder(pax, staffId);
		System.out.println("You are assigned to table " + order.getTableID());
		System.out.println("Your order ID is : " + order.getOrderID());
		addFood(order);
		addPromoSet(order);
	}

	private static void addPromoSet(Order order) {
		do{
			System.out.println("Enter the promotional set id and the quantity");
			int id=sc.nextInt();
			int quantity=sc.nextInt();
			order.addPromoSet(PromoSetMgr.searchPromoSet(id), quantity);
			System.out.println("continue? y/n");
		}while (sc.next().charAt(0) == 'y');
	}

	private static void addFood(Order order) {
		do{
			System.out.println("Enter the food id and the quantity");
			int id=sc.nextInt();
			int quantity=sc.nextInt();
			order.addFood(FoodMgr.searchFood(id), quantity);
			System.out.println("continue? y/n");
		}while (sc.next().charAt(0) == 'y');
	}

	private static void case2() {
		System.out.println("1: Create promotion");
		System.out.println("2: Update promotion");
		System.out.println("3: Remove promotion");
		System.out.println("4: Quit");
		int c = sc.nextInt();
		switch(c)
		{
			case 1://add promoset
			{
				addPromoSet();
				break;
			}
			case 2://update promoset//
			{
				updatePromoSet();
				break;
			}
			
			case 3://remove promoSet
			{
				System.out.print("Enter the promotion id:");
				int id=sc.nextInt();
				restaurant.removePromoSet(id);
				break;
			}
			case 4: // quit
			{
				break;
			}
			default:
			{	
				System.out.println("wrong input");
				break;
			}
		}			
	}

	private static void updatePromoSet() {
		System.out.print("Enter the promotion id:");
		int id=sc.nextInt();
		int c;
		do
		{
			System.out.println("1: Update name");
			System.out.println("2: Update price");
			System.out.println("3: Update description");
			System.out.println("4: Quit");
			c= sc.nextInt();
			if (c>0 && c<4)
			{
				sc.nextLine(); //flush
				System.out.println("New value");
				String value = sc.nextLine();
				restaurant.updatePromoSet(id, c, value);
			}
		}while(c>0 && c<4);
		
	}

	private static void addPromoSet() {
		System.out.println("ID:");
		int id = sc.nextInt();
		sc.nextLine(); //flush
		System.out.print("Name:");
		String name =sc.nextLine();
		System.out.println("food id list:");
		String foodListStr = sc.nextLine();
		System.out.print("Price:");
		double price=sc.nextDouble();
		sc.nextLine(); //flush
		System.out.print("Description:");
		String description =sc.nextLine();
		restaurant.addPromoSet(id, name, foodListStr, price, description);	
	}

	private static void case1() 
	{
		System.out.println("1: Create menu item");
		System.out.println("2: Update menu item");
		System.out.println("3: Remove menu item");
		System.out.println("4: Print menu");
		System.out.println("5: Quit");
		int c=sc.nextInt();
		
		switch(c)
		{
			case 1://add food
			{
				addFood();
				break;
			}
			case 2://update food
			{
				updateFood();
				break;
			}
			case 3://remove food
			{
				System.out.print("Enter the food id:");
				int id=sc.nextInt();
				restaurant.removeFood(id);
				break;
			}
			case 4: //print menu
			{
				FoodMgr.printMenu();
				break;
			}
			case 5:
				break;
			default:
			{
				System.out.println("Wrong data input");
				break;
			}
		}
	}

	private static void updateFood() {
		System.out.print("Enter the food id: ");
		int id=sc.nextInt();
		int c;
		do
		{
			System.out.println("1: Update name");
			System.out.println("2: Update price");
			System.out.println("3: Update description");
			System.out.println("4: Quit");
			c = sc.nextInt();
			sc.nextLine(); // flush
			if (c>0 && c<4)
			{
				System.out.println("New Value:");
				String value = sc.nextLine();
				restaurant.updateFood(id, c, value);
			}
		}while(c>0 &&c<4);
		
	}

	private static void addFood() {
		System.out.print("Food ID:");
        int id = sc.nextInt();
        sc.nextLine(); // flush
		System.out.print("Food name:");
		String name =sc.nextLine();
		System.out.print("food price:");
		double price=sc.nextDouble();
		System.out.print("food category:");
		restaurant.printCategories();
		int category = sc.nextInt();
		sc.nextLine(); //flush
		System.out.print("Food description:");
        String description = sc.nextLine();
        
        restaurant.addFood(id, name, price, category, description);
		
	}
		
}
