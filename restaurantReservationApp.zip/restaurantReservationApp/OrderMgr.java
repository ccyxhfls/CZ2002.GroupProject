package restaurantReservationApp;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;

public class OrderMgr {
	ArrayList<Order> orderList;
	
	public void addOrder(ArrayList<Food> foodList, ArrayList<PromoSet> promoSetList, Table table){
		Order order = new Order(orderList.size(), foodList, promoSetList, table);
		orderList.add(order);
	}
	
	public void viewOrder(int ID){
		Order order = searchOrder(ID);
		//print order;
	}
	
	public void addFood (int ID, Food food){
		Order order = searchOrder(ID);
		order.addFood(food);
	}
	
	public void removeFood (int ID, Food food){
		Order order = searchOrder(ID);
		order.removeFood(food);
	}
	
	public void addSet (int ID, PromoSet set){
		Order order = searchOrder(ID);
		order.addSet(set);
	}
	
	public void removeFood (int ID, PromoSet set){
		Order order = searchOrder(ID);
		order.removeSet(set);
	}
	
	
	private Order searchOrder(int ID){
		Iterator<Order> itr = orderList.iterator();
		while(itr.hasNext()){
			Order order = itr.next();
			if (order.getID() == ID){
				return order;
			}
		}
		throw new NullPointerException();
	}
	
	
}
