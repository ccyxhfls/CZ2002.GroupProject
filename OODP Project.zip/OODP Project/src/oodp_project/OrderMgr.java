package oodp_project;

import java.io.FileNotFoundException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

public class OrderMgr 
{
	static Scanner sc = new Scanner(System.in);
	int resID;
	FoodMgr fm = new FoodMgr();

	public void createOrder(ArrayList<Food>foodArray,ArrayList<Set> setArray,Table[] table) throws FileNotFoundException
	{
		int tableChoice = 0,pax = 0,i = 0,intChoice = 0,resIndex = 0,tableIndex = 0;
		String choice,custName = null,membership;
		
		ArrayList<Staff> staffList = new ArrayList<Staff>();
		Staff staff = new Staff();
		
		Restaurant res = new Restaurant();
		Customer cust = new Customer();
		
		staffList = res.getStaffInfo();
		System.out.println("---------------------- Staff Information------------------------");
		for (Staff s: staffList){
			System.out.print(s.toString());
		}
		System.out.print("Enter Staff ID: ");
		intChoice = sc.nextInt();
		
		while(intChoice < 1 || intChoice > staffList.size())
		{
			System.out.print("Enter Staff ID: ");
			intChoice = sc.nextInt();
		}
		
		for (Staff s: staffList){
			if (s.getStaffID() == intChoice){
				staff.setStaffID(s.getStaffID());
				staff.setStaffName(s.getStaffName());
				staff.setGender(s.getGender());
				staff.setJobTitle(s.getJobTitle());
			}
		}
		
		System.out.println("Have you reserved a Table? <Y/N>");
		choice = (sc.next()).toUpperCase();
		
		while(!(choice.equals("Y") ||choice.equals("N")))
		{
			System.out.println("Have you reserved a Table? <Y/N>");
			choice = (sc.next()).toUpperCase();
		}
		
			if(choice.equals("Y"))
		    {
				boolean flag = true;
				while(flag){
				 	System.out.println("Enter Reservation ID: ");
				 	try
				 	{
				 		resID = sc.nextInt();
				 		flag = false;
				 	}
				 	catch(InputMismatchException e)
				 	{
				 		System.out.println("Invalid Input!!");
				 		sc.next();
				 		continue;
				 	}
				 	catch(ArrayIndexOutOfBoundsException e)
				 	{
				 		System.out.println("Invalid ID");
				 		sc.next();
				 		continue;
				 	}
				
					for(Table t: table){
						resIndex = 0;
						for(Reservation r:t.getResArray()){
							if(resID == r.getResID()){
								t.setReserved(false);
								t.setOccupied(true);
								t.setCust(r.getCust());
								break;
							}
							resIndex++;
						}
					tableIndex++;
					}
					try{
						table[tableIndex-1].getResArray().remove(resIndex);
					}
					catch (IndexOutOfBoundsException e){
						System.out.println("Invalid Reservation ID");
						continue;
						
					}
					orderFood(foodArray,setArray,table[tableIndex-1],staff);
				}
		    }
		    
			else if(choice.equals("N"))
		    {
				boolean again = true;
				while(again){
					System.out.println("Enter Customer Name");
					custName = sc.next();
					
					cust.setCustName(custName);
					
					System.out.println("Do you have a Membership Card? <Y/N> ");
					sc.nextLine();//flush
				    membership = (sc.next()).toUpperCase();
				    
				    while(!(membership.equals("Y") || membership.equals("N")))
				    {
				    	System.out.println("Do you have a Membership Card? <Y/N> ");
						sc.nextLine();//flush
					    membership = (sc.next()).toUpperCase();
				    }
				    
				    sc.nextLine();//flush
				    
				    if(membership.equals("Y"))
				    {
				    	cust.setMembership(true);
				    }
				    
				    if(membership.equals("N"))
				    {
				    	cust.setMembership(false);
				    }
					
					System.out.println("Enter no. of pax: ");
					try{
						pax = sc.nextInt();
						again = false;
					}
					catch (InputMismatchException e){
						System.out.println("Invalid input");
						sc.next();
						continue;
					}
					
					for(Table t:table){
						if((pax <= t.getCapacity() && t.isOccupied() == true) || pax <= t.getCapacity() && t.isReserved() == true){
							System.out.println("");
						}
					}
					
					while(pax > 10)
					{
					    	System.out.println("No of Pax Exceeded Table size (Max 10)");
					    	System.out.println("Please do seperate booking for pax above 10");
					    	System.out.println("Enter no. of pax: ");
					    	pax = sc.nextInt();	
					}
				}
				boolean flag = true;
			 	res.showAvailTable(table);
				while(flag){
				    System.out.println("Please Select Table: ");
				    try{
				    	tableChoice = sc.nextInt();
				    }
				    catch(InputMismatchException e){
				    	System.out.println("Invalid input");
				    	sc.next();
				    	continue;
				    }
				    sc.nextLine();//flush
				    try{
					    if(table[tableChoice-1].isReserved() == true || table[tableChoice-1].isOccupied() == true){
					    	System.out.println("Table already reserved/occupied");
					    }
					    else if(table[tableChoice-1].getCapacity() < pax){
					    	System.out.println("Over Table Capacity");
					    }
					    else
					    {
						    table[tableChoice-1].setOccupied(true);
						    table[tableChoice-1].setCust(cust);
						    flag = false;
					    }
				    }
				    catch (ArrayIndexOutOfBoundsException e){
				    	System.out.println("Invalid Table ID");
				    	continue;
				    }
				}	
				orderFood(foodArray,setArray,table[tableChoice -1],staff);
		    }
			
	}
		
	public void orderFood(ArrayList<Food> foodArray,ArrayList<Set> setArray,Table tlb,Staff staff)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		
		
		System.out.println(tlb.toString());
		
		ArrayList<Food> foodOrders = new ArrayList<Food>();
		ArrayList<Set> setOrders = new ArrayList<Set>();
		
		ArrayList<Food> horsArray = new ArrayList<Food>();
		ArrayList<Food> saladArray = new ArrayList<Food>();
		ArrayList<Food> mainArray = new ArrayList<Food>();
		ArrayList<Food> drinksArray = new ArrayList<Food>();
		ArrayList<Food> desArray = new ArrayList<Food>();
		
		Order o = new Order();
		
		int orderNo = (int)(Math.random()*800000);
	    int i = (int) (new Date().getTime()/1000);
	    
	    int foodCategory;
		double totalPrice = 0;
		boolean stopOrder = true;
		String choice;
		
		
		for(Food f: foodArray){
			if(f.getFoodType().equals("Hors d'Oeuvre")){
				horsArray.add(f);
			}
			else if (f.getFoodType().equals("Salads")){
				saladArray.add(f);
			}
			else if(f.getFoodType().equals("Main Course")){
				mainArray.add(f);
			}
			else if(f.getFoodType().equals("Drinks")){
				drinksArray.add(f);
			}
			else if(f.getFoodType().equals("Dessert")){
				desArray.add(f);
			}
		}
		
		while(stopOrder)
		{
			System.out.println("------------------------- Menu Item ----------------------------");
			fm.displayFoodCat();
			foodCategory = sc.nextInt();
			switch(foodCategory)
				{
					case 1:	selectOrder(horsArray,foodOrders);
							break;
					case 2:	selectOrder(saladArray,foodOrders);
							break;
					case 3:	selectOrder(mainArray,foodOrders);
							break;
					case 4:	selectOrder(drinksArray,foodOrders);
							break;
					case 5:	selectOrder(desArray,foodOrders);
							break;
					case 6: selectOrder(foodArray,foodOrders);
							break;
					case 7: selectSet(setArray,setOrders);
							break;
					default:System.out.println("Invalid Choice!");
							continue;
				}
			
			for(Food f : foodOrders)
			{
				totalPrice += f.getPrice();
			}
			for(Set s: setOrders)
			{
				totalPrice += s.getPrice();
			}
			
			System.out.println("Menu Added");
			
			System.out.println("Do you want to continue ordering?<Y/N> ");
			choice = (sc.next()).toUpperCase();
			while(!(choice.equals("Y") || choice.equals("N")))
			{
				System.out.println("Do you want to continue ordering?<Y/N> ");
				choice = (sc.next()).toUpperCase();
			}
				
			if(choice.equals("Y"))
				continue;
			else if (choice.equals("N"))
				stopOrder = false;
		}
		
		o.setOrderNo(orderNo);
		o.setSetArray(setOrders);
		o.setFoodArray(foodOrders);
		o.setPrice(totalPrice);
		o.setStaff(staff);
		o.setDate(dateFormat.format(date));
		
		tlb.getOrderArray().add(o);
				
		System.out.println("Order Submitted! \nOrder Number: "+ orderNo);
	}
	public void showOrders(Table [] table)
	{	
		System.out.println("----------------------------------------------------------------------");
		for(Table t:table){
			for(Order o:t.getOrderArray()){
				System.out.println("Table No: " + t.getTableNo());
				System.out.println("Order ID: " + o.getOrderNo());
				o.printMenu();
			}
		}
	}
	  
	public void addOrders(Table [] table,ArrayList<Food> foodArray,ArrayList<Set> setArray)
	{
		int orderNo = 0,foodCategory;
		String choice;
		boolean stopOrder = true,again = true;
		
		ArrayList<Food> horsArray = new ArrayList<Food>();
		ArrayList<Food> saladArray = new ArrayList<Food>();
		ArrayList<Food> mainArray = new ArrayList<Food>();
		ArrayList<Food> drinksArray = new ArrayList<Food>();
		ArrayList<Food> desArray = new ArrayList<Food>();
		
		ArrayList<Integer> tempArray = new ArrayList<Integer>();
		
		Food food = new Food();
		while (again){
			System.out.println("Enter Order No: ");
			try{
				orderNo = sc.nextInt();
				again = false;
			}
			catch (InputMismatchException e){
				System.out.println("Invalid Input");
				sc.next();
				continue;
			}
			for(Table t: table){
				for(Order o:t.getOrderArray()){
					tempArray.add(o.getOrderNo());
				}
			}
			if(tempArray.contains(orderNo) == false){
				continue;
			}
			else{
				break;
			}
			
		}
		
		for(Food f: foodArray){
			if(f.getFoodType().equals("Hors d'Oeuvre")){
				horsArray.add(f);
			}
			else if (f.getFoodType().equals("Salads")){
				saladArray.add(f);
			}
			else if(f.getFoodType().equals("Main Course")){
				mainArray.add(f);
			}
			else if(f.getFoodType().equals("Drinks")){
				drinksArray.add(f);
			}
			else if(f.getFoodType().equals("Dessert")){
				desArray.add(f);
			}
		}
		for(Table t:table){
			for(Order o:t.getOrderArray()){
				if(o.getOrderNo() == orderNo)
				{
					while(stopOrder){
					fm.displayFoodCat();
					foodCategory = sc.nextInt();
					switch(foodCategory)
					{
							case 1:	addNewOrder(horsArray,o);
									break;
							case 2:	addNewOrder(saladArray,o);
									break;
							case 3:	addNewOrder(mainArray,o);
									break;
							case 4:	addNewOrder(drinksArray,o);
									break;
							case 5:	addNewOrder(desArray,o);
									break;
							case 6: addNewOrder(foodArray,o);
									break;
							case 7: addNewSet(setArray,o);
									break;
							default: System.out.println("Invalid Choice!");
					}
						
					System.out.println("Menu Added");
					System.out.println("Do you want to carry-on ordering?<Y/N> ");
					choice = (sc.next()).toUpperCase();
							
					while(!(choice.equals("Y") ||choice.equals("N")))
					{
						System.out.println("Have you reserved a Table? <Y/N>");
						choice = (sc.next()).toUpperCase();
							
					}
					if(choice.equals("Y"))
						continue;
					else 
						stopOrder = false;
					}
				}
			}
		}
	}
	
	public void removeItem(Table [] table)
	{
		int orderNo = 0,foodID = 0,foodChoice = 0;
		boolean again = true;
		
		ArrayList<Integer> tempArray = new ArrayList<Integer>();
		ArrayList<Food> tempFood = new ArrayList<Food>();
		ArrayList<Set> tempSet = new ArrayList<Set>();
		
		while(again){
			System.out.println("Enter Order No: ");
			
			try{
				orderNo = sc.nextInt();
				again = false;
			}
			catch (InputMismatchException e){
				System.out.println("Invalid Input");
				sc.next();
				continue;
			}
			for(Table t:table){
				for(Order o:t.getOrderArray()){
					tempArray.add(o.getOrderNo());
				}
			}
			for(Table t:table){
				for(Order o:t.getOrderArray()){
					for(Food f:o.getFoodArray()){
						tempFood.add(f);
					}
					for(Set s:o.getSetArray()){
						tempSet.add(s);
					}
				}
			}
		
			if(tempArray.contains(orderNo) == false){
				System.out.println("Invalid Order ID");
				continue;
			}
			else{
				break;
			}
		}
		for(Table t:table){
			for(Order o:t.getOrderArray()){
				if(o.getOrderNo() == orderNo)
				{
					o.printMenu();
					System.out.println("1.Food Item");
					System.out.println("2.Set");
					System.out.println("Please Select Food or Set to delete");
					try{
						foodChoice = sc.nextInt();
					}
					catch (InputMismatchException e){
						System.out.println("Invalid input");
						sc.next();
						continue;
					}
					
					switch(foodChoice){
						case 1:
							System.out.println("Select Food ID to Remove: ");
							try{
								foodID = sc.nextInt();
							}
							catch (InputMismatchException e){
								System.out.println("Invalid Food ID");
							}
							
							for(Food f : tempFood)
							{
								if(f.getFoodID() == foodID)
								{
									try{
										o.getFoodArray().remove(f);
										break;
									}
									catch(IndexOutOfBoundsException e){
										System.out.println("Invalid Input");
									}
								}
								
							}
							break;
						case 2:
							System.out.println("Select Food ID to Remove: ");
							foodID = sc.nextInt();
							
							for(Set s: tempSet){
								if(s.getSetNo() == foodID){
									try{
										o.getSetArray().remove(s);
									}
									catch(IndexOutOfBoundsException e){
										System.out.println("Invalid Input");
									}
								}
							}
							break;
						default:System.out.println("Invalid Input");
							break;
					}

				}
			}
		}
	}
	
	public void selectOrder(ArrayList<Food> foodArray, ArrayList<Food> foodOrders){
		int foodChoice = 0;
		boolean again = true;
		
		Food food = new Food();
		Order o = new Order();
		
		ArrayList<Integer> tempArray = new ArrayList<Integer>();
		
		for(Food f:foodArray){
			tempArray.add(f.getFoodID());
			System.out.println(f.toString());
		}
		
		while(again){
			System.out.println("Select Order:");
			try{
				foodChoice = sc.nextInt();
			}
			catch (InputMismatchException e){
				System.out.println("Invalid Input");
				sc.next();
				continue;
			}
			
			if(tempArray.contains(foodChoice) == false){
				System.out.println("Food ID does not exist");
				continue;
			}
			else{
				break;
			}
		}
		
		for(Food f:foodArray)
		{
    		if(f.getFoodID() == foodChoice)
    		{
    			food.setFoodID(f.getFoodID());
    			food.setFoodName(f.getFoodName());
    			food.setDesc(f.getDesc());
    			food.setPrice(f.getPrice());
    			food.setFoodType(f.getFoodType());
    		}		
    	}
		foodOrders.add(food);
	}
	public void selectSet(ArrayList<Set> setArray, ArrayList<Set> setOrders){
		int setChoice = 0;
		boolean again = true;
		
		Set set = new Set();
		Order o = new Order();
		
		ArrayList<Integer> tempArray = new ArrayList<Integer>();
		
		for(Set s:setArray){
			tempArray.add(s.getSetNo());
			System.out.println(s.toString());
		}
		
		while(again){
			System.out.println("Select Order:");
			try{
				setChoice = sc.nextInt();
			}
			catch (InputMismatchException e){
				System.out.println("Invalid Input");
				sc.next();
				continue;
			}
			
			if(tempArray.contains(setChoice) == false){
				System.out.println("Set ID does not exist");
				continue;
			}
			else{
				break;
			}
		}
		
		for(Set s:setArray)
		{
    		if(s.getSetNo() == setChoice)
    		{
    			set.setSetNo(s.getSetNo());
    			set.setFood(s.getFood());
    			set.setPrice(s.getPrice());
    		}		
    	}
		setOrders.add(set);
	}
	public void addNewOrder(ArrayList<Food> foodArray,Order o){
		int foodChoice = 0;
		boolean again = true;
		
		Food food = new Food();
		//Order o = new Order();
		
		ArrayList<Integer> tempArray = new ArrayList<Integer>();
		
		for(Food f:foodArray){
			tempArray.add(f.getFoodID());
			System.out.println(f.toString());
		}
		
		while(again){
			System.out.println("Select Order:");
			try{
				foodChoice = sc.nextInt();
			}
			catch (InputMismatchException e){
				System.out.println("Invalid Input");
				sc.next();
				continue;
			}
			if(tempArray.contains(foodChoice) == false){
				System.out.println("Food ID does not exist");
				continue;
			}
			else{
				break;
			}
		}
		
		for(Food f:foodArray)
		{
    		if(f.getFoodID() == foodChoice)
    		{
    			food.setFoodID(f.getFoodID());
    			food.setFoodName(f.getFoodName());
    			food.setDesc(f.getDesc());
    			food.setPrice(f.getPrice());
    			food.setFoodType(f.getFoodType());
    		}		
    	}
		o.getFoodArray().add(food);
	}
	public void addNewSet(ArrayList<Set> setArray,Order o){
		int setChoice = 0;
		boolean again = true;
		
		Set set = new Set();
		//Order o = new Order();
		
		ArrayList<Integer> tempArray = new ArrayList<Integer>();
		
		for(Set s:setArray){
			tempArray.add(s.getSetNo());
			System.out.println(s.toString());
		}
		
		while(again){
			try{
				System.out.println("Select Order:");
				setChoice = sc.nextInt();
			}
			catch (InputMismatchException e){
				System.out.println("Invalid Input");
				sc.next();
				continue;
			}
			
			if(tempArray.contains(setChoice) == false){
				System.out.println("Food ID does not exist");
				continue;
			}
			else{
				break;
			}
		}
		
		for(Set s:setArray)
		{
    		if(s.getSetNo() == setChoice)
    		{
    			set.setSetNo(s.getSetNo());
    			set.setFood(s.getFood());
    			set.setPrice(s.getPrice());
    		}		
    	}
		o.getSetArray().add(set);
	}
	
	public void removeOrder (Table [] table){
		int orderID;
		boolean flag = true;
		
		Table [] tempTable = table.clone();
		ArrayList<Order> tempOrder = new ArrayList<Order>();
		
		for(Table t:table){
			for(Order o:t.getOrderArray()){
				tempOrder.add(o);
			}
		}
		
		while(flag)
		{
			try{
				System.out.println("Enter Order ID:");
				orderID = sc.nextInt();
				sc.nextLine();
				flag = false;
			}
			catch (InputMismatchException e){
				System.out.println("Invalid input");
				sc.next();
				continue;
			}
			try{
				for(Table t: tempTable){
					for(Order o: tempOrder){
						if(orderID == o.getOrderNo()){
							t.setOccupied(false);
							t.getOrderArray().remove(o);
						}
					}
				}
				System.out.println("Order removed.");
			}
			catch(IndexOutOfBoundsException e){
				System.out.println("Invalid Order ID");
				continue;
			}
		}
	}
}


