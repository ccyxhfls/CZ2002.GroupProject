package oodp_project;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ReserveMgr {
	
	static Scanner sc = new Scanner(System.in);

	Restaurant rest =  new Restaurant();
	
	String custName,membership;
	int pax,tableNo,resID;
	
	String dateTime;
	
	public void createReservation(Table [] table) throws ParseException{
		int resID = (int)(Math.random()*100000);
	    int i = (int) (new Date().getTime()/1000);
	    
		String rDate,rTime;
		int rDay = 0,rMonth = 0,rYear = 0,rHour = 0,rMin = 0, rSec=0;
		String d[],t[];
		boolean validDate = false,validTime = false,again = true;
	    
	    Reservation res = new Reservation();
	    
	    Customer cust = new Customer();
	    
		Date date = new Date();
		
		//Calendar object to track current date time
		Calendar cal = new GregorianCalendar();
		
		//Calendar object for reservation date time
		Calendar rCal = new GregorianCalendar();
		
		//Set Calendar object to current date time
		cal.setTime(date);
	    
	    resID +=i;
		System.out.println("Enter Customer Name:");
		custName = sc.nextLine();
		cust.setCustName(custName);
		while(again){
			System.out.println("Enter no. of pax: ");
			try{
				pax = sc.nextInt();
				again = false;
			}
			catch (InputMismatchException e){
				System.out.println("Invalid input");
				sc.next();
				continue;
			}
			
			while(pax > 10)
			{
			    	System.out.println("No of Pax Exceeded Table size (Max 10)");
			    	System.out.println("Please do seperate booking for pax above 10");
			    	System.out.println("Enter no. of pax: ");
			    	pax = sc.nextInt();
			}
		}
		System.out.println("Do you have a Membership Card? <Y/N> ");
		sc.nextLine();//flush
	    membership = (sc.next()).toUpperCase();
	    
	    while(!(membership.equals("Y") || membership.equals("N")))
	    {
	    	System.out.println("Do you have a Membership Card? <Y/N> ");
			sc.nextLine();//flush
		    membership = (sc.next()).toUpperCase();
	    }
	    
	    sc.nextLine();//flush
	    if(membership.equals("Y"))
	    {
	    	cust.setMembership(true);
	    }
	    
	    if(membership.equals("N"))
	    {
	    	cust.setMembership(false);
	    }
	    while(validDate == false){
			System.out.println("Enter date of reservation (dd/mm/yyyy): ");
			rDate = sc.nextLine();
			
			d = rDate.split("/");
			try{
			rDay = Integer.parseInt(d[0]);
			rMonth = Integer.parseInt(d[1]);
			rYear = Integer.parseInt(d[2]);
			}
			catch (NumberFormatException e){
				System.out.println("Please enter in proper format.");
				continue;
			}
			catch (ArrayIndexOutOfBoundsException e){
				System.out.println("Please enter in proper format.");
				continue;
			}
			
			if(rYear < cal.get(Calendar.YEAR)){
				System.out.println("Year already passed!");
				validDate = false;
			}
			else if (rYear == cal.get(Calendar.YEAR)){
				if (1>rMonth || rMonth>12){
					System.out.println("Invalid Date!");
					validDate = false;
				}
				else{
					if(rMonth < (cal.get(Calendar.MONTH) + 1)){
						System.out.println("Month already passed!");
						validDate = false;
					}
					else if (rMonth == (cal.get(Calendar.MONTH)+1)){
						if(1>rDay || rDay>31){
							System.out.println("Invalid Date!");
							validDate = false;
						}
						else{
							if(rDay < cal.get(Calendar.DATE)){
								System.out.println("Date already passed!");
								validDate = false;
							}
							else{
								System.out.println("Valid Date");
								validDate = true;
							}
						}
					}
					else{
						System.out.println("Valid Date");
						validDate = true;
					}
				}
			}
			else{
				System.out.println("Valid Date!");
				validDate = true;
			}
		}
			
		if(rYear == cal.get(Calendar.YEAR) && rMonth == cal.get(Calendar.MONTH)+1 && rDay == cal.get(Calendar.DATE)){
			while(validTime == false){
				System.out.println("Enter time of reservation (HH:MM:SS):");
				rTime = sc.nextLine();
				t = rTime.split(":");
				
				try{
				rHour = Integer.parseInt(t[0]);
				rMin = Integer.parseInt(t[1]);
				rSec = Integer.parseInt(t[2]);
				}
			
				catch (NumberFormatException e){
					System.out.println("Please enter in proper format.");
					continue;
				}
				catch (ArrayIndexOutOfBoundsException e){
					System.out.println("Please enter in proper format.");
					continue;
				}
				if(0>rHour || rHour>23){
					System.out.println("Invalid Time!");
					validTime = false;
				}
				else{
					if(rHour < cal.get(Calendar.HOUR_OF_DAY)){
						System.out.println("Time already passed!");
						validTime = false;
					}
					else if (rHour == cal.get(Calendar.HOUR_OF_DAY)){
						if(0>rMin || rMin>59){
							System.out.println("Invalid Time!");
							validTime = false;
						}
						else{
							if(rMin < cal.get(Calendar.MINUTE)){
								System.out.println("Time already passed!");
								validTime = false;
							}
							else if(rMin == cal.get(Calendar.MINUTE)){
								if(0>rSec || rSec>59){
									System.out.println("Invalid Time!");
									validTime = false;
								}
								else{
									if(rSec < cal.get(Calendar.SECOND)){
										System.out.println("Time already passed!");
										validTime = false;
									}
									else{
										System.out.println("Valid Time.");
										validDate = true;
										break;
									}
								}
							}
							else{
								System.out.println("Valid Time.");
								validDate = true;
								break;
							}
						}
					}
					else{
						System.out.println("Valid Time.");
						validDate = true;
						break;
					}
		
					}
				}
		}
		else{
			while(validTime == false){
				try{
					System.out.println("Enter time of reservation (HH:MM:SS):");
					rTime = sc.nextLine();
					t = rTime.split(":");
					rHour = Integer.parseInt(t[0]);
					rMin = Integer.parseInt(t[1]);
					rSec = Integer.parseInt(t[2]);
				}
				catch(ArrayIndexOutOfBoundsException e){
					System.out.println("Please enter in proper format");
					continue;
				}
				catch (NumberFormatException e){
					System.out.println("Please enter in proper format.");
					continue;
				}
				
				if(0>rHour || rHour>23){
					System.out.println("Invalid Time");
					validTime = false;
				}
				else{
					if(0>rMin || rMin >59){
						System.out.println("Invalid Time");
						validTime = false;
					}
					else{
						if(0>rSec || rSec>59){
							System.out.println("Invalid Time");
							validTime = false;
						}
						else{
							validTime = true;
							System.out.println("Valid Time.");
						}
					}
				}
			}
		}
		
		rCal.set(rYear, rMonth-1, rDay, rHour, rMin, rSec);
		
		Date resDate = new Date();
		
		resDate.setTime(rCal.getTimeInMillis());
		
		rest.showAvailTable(table);
		boolean reEnter = true;
		boolean CANRESERVE = false;

		while(reEnter){
		    System.out.println("Please Select Table: ");
		    try{
		    	tableNo = sc.nextInt();
		    }
		    catch(InputMismatchException e){
		    	System.out.println("Invalid input");
		    	continue;
		    }
		    sc.nextLine();//flush
		    try{
			    if(table[tableNo-1].isOccupied() == true){
			    	for(Order o :table[tableNo-1].getOrderArray()){
			    		Date oDate = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(o.getDate());
			    		if((resDate.getTime() - oDate.getTime()) > 7200000){
			    					res.setResID(resID);
									res.setPax(pax);
									res.setCust(cust);
									res.setDate(resDate);
							    	table[tableNo-1].getResArray().add(res);
							    	
								    reEnter = false;
								    System.out.println("Reservation made!");
								    System.out.println("Reservation ID: " + res.getResID());			    					
			    				}
			    		else{
			    			System.out.println("Table already occupied");
			    		}
			    	}
		    	}
			    else if(table[tableNo-1].getCapacity() < pax){
			    	System.out.println("Over Table Capacity");
			    }
			    else if(table[tableNo-1].isReserved() == true){
			    	for(Reservation r:table[tableNo-1].getResArray()){
			    		if((resDate.getTime() - r.getDate().getTime()) < 720000){
							CANRESERVE = true;
						    reEnter = false;
			    		}
			    		else{
			    			System.out.println("Someone already reserved this table");
			    		}
			    	}
			    	if (CANRESERVE){
				    	res.setResID(resID);
						res.setPax(pax);
						res.setCust(cust);
						res.setDate(resDate);
				    	table[tableNo-1].getResArray().add(res);
				    	reEnter = false;
			    	}
			    }
			    else
			    {	res.setResID(resID);
					res.setPax(pax);
					res.setCust(cust);
					res.setDate(resDate);
				
					table[tableNo-1].getResArray().add(res);
				    table[tableNo-1].setReserved(true);
				    reEnter = false;
				    System.out.println("Reservation made!");
				    System.out.println("Reservation ID: " + res.getResID());
			    }
		    }
		    catch (ArrayIndexOutOfBoundsException e){
		    	System.out.println("Invalid Table ID");
		    	continue;
		    }
		}
		
	}
	
	public void removeReservation(Table [] table)
	{
		boolean again = true;
	
		Table [] tempTable = table.clone();
		ArrayList<Reservation> tempRes = new ArrayList<Reservation>();
		
		for(Table t:table){
			for(Reservation r:t.getResArray()){
				tempRes.add(r);
			}
		}
	
		while(again){
				System.out.println("Enter the Reservation ID: ");
				try{
					resID = sc.nextInt();
					sc.nextLine();
					again = false;
				}
				catch (InputMismatchException e){
					System.out.println("Invalid input");
					sc.next();
					continue;
				}
				try{
					for(Table t:tempTable){
						for(Reservation r:tempRes){
							if(resID == r.getResID()){
								t.setReserved(false);
								t.getResArray().remove(r);
								
							}
						}
					}
				System.out.println("Reservation removed.");
				}
				catch(IndexOutOfBoundsException e){
					System.out.println("Invalid Reservation ID");
					sc.next();
					continue;
				}
			}
		
	}
	public void showReservation(Table[] table){
		rest.updateTableStatus(table);
		for(Table t: table){
			for(Reservation r: t.getResArray()){
				System.out.println("Table No: " + t.getTableNo());
				System.out.println(r.toString());
			}
		}
	}
}
