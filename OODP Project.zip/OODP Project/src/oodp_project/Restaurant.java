package oodp_project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.ArrayList;

public class Restaurant {
	
	static Scanner sc = new Scanner(System.in);
	
	static final int noTable = 10;

	private int foodID,staffID;
	private int capacity = 2;
	private String foodName, foodType, desc,staffName,jobTitle;
	private double price;
	private Table [] table;
	private char gender;
	
	ArrayList<Food> foodArray = new ArrayList<Food>();
	ArrayList<Staff> staffArray = new ArrayList<Staff>();
	
	Food sortFood = new Food();
	
	public void displayMenu() {
		System.out.println("--------------- Navigate around Restaurant eNova ---------------");
		System.out.println("1.Display Menu");
		System.out.println("2.Modify Menu item");
		System.out.println("3.Modify Set item");
		System.out.println("4.Create Order");
		System.out.println("5.View Order");
		System.out.println("6.Edit Order");
		System.out.println("7.Create Reservation");
		System.out.println("8.View Reservation Booking");
		System.out.println("9.Remove Reservation");
		System.out.println("10.Check Table Availablilty");
		System.out.println("11.Print Receipt");
		System.out.println("12.Print Sales Revenue");
		System.out.println("13.Quit");
		System.out.println("----------------------------------------------------------------");
		System.out.print("Please enter your choice: ");
	}

	public ArrayList<Food> createFoodMenu() throws FileNotFoundException {

		String currentLine = null;
		
		BufferedReader br = new BufferedReader(new FileReader("food.txt"));
		try {
			while ((currentLine = br.readLine()) != null) {
				String[] s = currentLine.split(",");
				foodID = Integer.parseInt(s[0]);
				foodName = s[1];
				foodType = s[2];
				price = Double.parseDouble(s[3]);
				desc = s[4];
				Food food = new Food(foodID, foodName, foodType, price, desc);
				foodArray.add(food);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		sortFood.sortFoodArray(foodArray);
		
		return foodArray;
	}
	public Table [] initTable(int noTable){
		table = new Table[noTable];
		for(int i=0;i<table.length;i++){
			ArrayList<Reservation> resArray = new ArrayList<Reservation>();
			ArrayList<Order> orderArray = new ArrayList<Order>();
			table[i] = new Table(i+1,capacity,false,false,null,resArray,orderArray);
			if(i % 2 == 1){
				capacity +=2;
			}
		}
		return table;
	}
	public void showAvailTable(Table [] table)
	{
		int available = 0;
		int reserved = 0;
		int occupied = 0;
		
		updateTableStatus(table);
		
		for (int i = 0; i <noTable;i++)
		{
			if(table[i].isReserved() == true)
			{
				reserved++;
			}
			else if(table[i].isOccupied() == true)
			{
				occupied++;
			}
			else if (table[i].isOccupied() == false && table[i].isReserved()==false){
				available++;
			}
		}
		System.out.println("");
		System.out.println("No of Available Table = "+ available);
		System.out.println("No of Reserved Table = "+ reserved);
		System.out.println("No of Occuiped Table = "+ occupied +"\n");
		
		for(int i = 0; i <noTable;i++)
		{
			if(table[i].isReserved() == false && table[i].isOccupied() == false)
			{
				System.out.println("Table "+ table[i].getTableNo() + "(Capacity: " + table[i].getCapacity() + ")" + " is available");
			}
			else if(table[i].isOccupied() == true){
				System.out.println("Table " + table[i].getTableNo() + "(Capacity: " + table[i].getCapacity() + ")" + " is occuipied");
			}
			else{
				System.out.println("Table " + table[i].getTableNo() + "(Capacity: " + table[i].getCapacity() + ")" + " is reserved");
			}
		}	
		System.out.println("----------------------------------------------------------------");
	}
	public void updateTableStatus(Table [] table){
		long timeDiff;
		Date date = new Date();
		
		Table tempTable[] = table.clone();
		ArrayList<Reservation> tempRes = new ArrayList<Reservation>();
		
		for(Table t:table){
			for(Reservation r: t.getResArray()){
				tempRes.add(r);
			}
		}
		
		//Calendar object to track current date time
		Calendar cal = new GregorianCalendar();
		
		cal.setTime(date);
		
		for(Table t:tempTable){
			for(Reservation r:tempRes){
				timeDiff = cal.getTimeInMillis() - r.getDate().getTime();
				//System.out.println("Performing a check. Timediff = " + timeDiff);
				if(timeDiff >= 60000){
					t.setReserved(false);
					t.setOccupied(false);
					t.getResArray().remove(r);
					//System.out.println("Removed.");
				}
			}
		}
	}
	
	public ArrayList<Staff> getStaffInfo() throws FileNotFoundException {
		String currentLine = null;
		
		BufferedReader br = new BufferedReader(new FileReader("staff.txt"));
		try {
			while ((currentLine = br.readLine()) != null) {
				String[] s = currentLine.split(",");
				staffID = Integer.parseInt(s[0]);
				staffName = s[1];
				gender = s[2].charAt(0);
				jobTitle = s[3];
				Staff staff = new Staff(staffID, staffName, gender, jobTitle);
				staffArray.add(staff);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return staffArray;
	}
	
	public void getSalesReport()
	{
		double[]Revenue;
		double TotalRevenue;
		SalesReport sr= new SalesReport();
		ArrayList<Order> orderArr = new ArrayList<Order>();
		ArrayList<Food> foodArr = new ArrayList<Food>();
		int choice;
		String year,month;
		Calendar now = Calendar.getInstance();
		int curyear = now.get(Calendar.YEAR);
		String yearInString = String.valueOf(curyear);
		DecimalFormat df = new DecimalFormat("#.00");
		
		String format = "|%1$-50s|%2$-10s|\n";
		
		System.out.println("Print Sales report by:");
		System.out.println("1) Year");
		System.out.println("2) Month");
		choice = sc.nextInt();
		
		if(choice==1)
		{
			Map<String, Integer> myMap = new HashMap<String, Integer>();
			System.out.print("Enter Year (yyyy):");
			year=sc.next();
			try {
				orderArr=sr.GetOrders(year,1);
			} catch (FileNotFoundException e) {			
				e.printStackTrace();
			}
			for(Order o:orderArr)
			{
				String[] seperated = o.getDate().split("\\/");
				
				if(seperated[0].equals(year))
				{
					foodArr=o.getFoodArray();
					for(Food f:foodArr)
					{
						if(myMap.containsKey(f.getFoodName()))
						{
							Integer value = myMap.get(f.getFoodName());
					        if (value == null)
					        {
					             value = 0;
					        }
					        value++;
					        myMap.put(f.getFoodName(), value);
						}
						else
						{
							myMap.put(f.getFoodName(), 1);
						}
					}	
				}
			}
			try{
			int max = Collections.max(myMap.values());
			Integer intValue=max;
	        Object strKey = null;
			for(Map.Entry entry: myMap.entrySet()){
	            if(intValue.equals(entry.getValue())){
	                strKey = entry.getKey();
	                break; 
	            }
	        }
			System.out.println("----------------------------------------------------------------");
			System.out.format(format,"Food Item","Quantity");
			System.out.println("----------------------------------------------------------------");
			for(Map.Entry entry:myMap.entrySet()){
				System.out.format(format,entry.getKey() ,entry.getValue());
			}
			System.out.print("The Best Selling Item is : " + strKey.toString() + "\n");
			Revenue=sr.getRevenue();
			TotalRevenue=0;
			for(int rev=0;rev<(int)Revenue.length;rev++)
			{
				TotalRevenue+=Revenue[rev];
			}
			System.out.println("The Total Revenue for the Period is :" + "$" + df.format(TotalRevenue) + "\n");
		}
		catch (NoSuchElementException e){
			System.out.println("Does not have sales report for this Year.");
		}
	
		}
		else if(choice==2)
		{
			Map<String, Integer> myMap = new HashMap<String, Integer>();
			System.out.print("Enter Month (1-12):");
			month=sc.next();
			try {
				orderArr=sr.GetOrders(month,0);
			} catch (FileNotFoundException e) {			
				e.printStackTrace();
			}
			for(Order o:orderArr)
			{
				String[] seperated = o.getDate().split("\\/");
				if(seperated[1].equals(month) && seperated[0].equals(yearInString))
				{
					foodArr=o.getFoodArray();
					for(Food f:foodArr)
					{
						if(myMap.containsKey(f.getFoodName()))
						{
							Integer value = myMap.get(f.getFoodName());
					        if (value == null)
					        {
					             value = 0;
					        }
					        value++;
					        myMap.put(f.getFoodName(), value);
						}
						else
						{
							myMap.put(f.getFoodName(), 1);
						}
					}

				}
			}
			try{
				int max = Collections.max(myMap.values());
				Integer intValue=max;
			
				Object strKey = null;
				for(Map.Entry entry: myMap.entrySet()){
					if(intValue.equals(entry.getValue())){
						strKey = entry.getKey();
						break; 
					}
				}
			
			System.out.println("----------------------------------------------------------------");
			System.out.format(format,"Food Item","Quantity");
			System.out.println("----------------------------------------------------------------");
			for(Map.Entry entry:myMap.entrySet()){
				
				//System.out.println(entry.toString());
				System.out.format(format,entry.getKey() ,entry.getValue());
				//System.out.println(entry.getKey() + entry.getValue());
			}
			//System.out.print(myMap.toString() + "\n");
			System.out.print("The Best Selling Item is : " + strKey.toString() + "\n");
			Revenue=sr.getRevenue();
			TotalRevenue=0;
			
			for(int rev=0;rev<Revenue.length;rev++)
			{
				TotalRevenue+=Revenue[rev];
			}
			System.out.println("The Total Revenue for the Period is :" + "$" + df.format(TotalRevenue) + "\n");
			}
			catch (NoSuchElementException e){
				System.out.println("Does not have sales report for this month.");
			}
		}
		else
		{
			System.out.print("Invalid Choice!");	
		}
	}
	
}
