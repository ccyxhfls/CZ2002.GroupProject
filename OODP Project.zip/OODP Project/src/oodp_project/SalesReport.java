package oodp_project;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class SalesReport {

	private double[]TotalRevenue=new double[100];
	String dateCmp;
	int oNumCmp;
	Date date;
	private int orderNo;
	private double price;
	int foodID,foodTypeChoice;
	String foodName,foodType,desc;
	private ArrayList<Food> foodArr = new ArrayList<Food>();
	private ArrayList<Order> orderArr = new ArrayList<Order>();
	SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
	
	public ArrayList<Order> GetOrders(String dtcheck,int type) throws FileNotFoundException {

		String currentLine = null;
		int i=0, revsum=0;
		Calendar now = Calendar.getInstance();
		int curyear = now.get(Calendar.YEAR);
		String yearInString = String.valueOf(curyear);
		
		BufferedReader br = new BufferedReader(new FileReader("Order.txt"));
		try {
			while ((currentLine = br.readLine()) != null) {
				String[] s = currentLine.split(":");
				String check ="!";
				if(check.equals(s[0]))
				{
					
					String[] seperated = s[1].split("\\/");
					if(type==1 && dtcheck.equals(seperated[0]))
					{
						TotalRevenue[revsum] = Double.parseDouble(s[2]);
						revsum++;
					}
					if(type==0 && dtcheck.equals(seperated[1]) && yearInString.equals(seperated[0]))
					{
						TotalRevenue[revsum] = Double.parseDouble(s[2]);
						revsum++;
					}		
				}
				else
				{
					try {
						 
						date=(Date)formatter.parse(s[0]);
						
					} catch (ParseException e) {
						System.out.println("\n An error with the formatting occured.");
						//e.printStackTrace();
					}				

					orderNo=Integer.parseInt(s[1]);				
					foodID = Integer.parseInt(s[2]);
					foodName = s[3];
					foodType = s[4];
					price= Double.parseDouble(s[5]);
					desc = s[6];
					
					if(i==0)
					{
						oNumCmp=Integer.parseInt(s[1]);
						i++;
					}
					if(oNumCmp==Integer.parseInt(s[1])&& i != 1)
					{
						Food food = new Food(foodID, foodName, foodType, price, desc);
						foodArr.add(food);
						continue;			
						/*Order order=new Order(orderNo, foodArr, s[0]);
						orderArr.add(order);
						oNumCmp=Integer.parseInt(s[1]);*/				
						
					}
					else
					{
						Food food = new Food(foodID, foodName, foodType, price, desc);
						foodArr = new ArrayList<Food>();
						foodArr.add(food);
						i++;
						Order order = new Order(orderNo, foodArr, s[0]);
						orderArr.add(order);
						oNumCmp=Integer.parseInt(s[1]);						
						
					}				
				}		
			}		
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return orderArr;
	}
	public double[] getRevenue()
	{
		return TotalRevenue;
		
	}
	

	
	
}
