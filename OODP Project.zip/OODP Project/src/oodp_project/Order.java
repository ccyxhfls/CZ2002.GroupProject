package oodp_project;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


/**
 * This is the Order class. This object will be created whenever a customer makes an order.
 * An order contains its Order Number, Price, Staff , an Array of Food and an Array of set menu. 
 * Food or Set array can be empty if no items were ordered.
 * 
 * @author erwinn
 * @version 1.0
 * @since 2014-11-01
 *
 */

public class Order {
	/**
	 * This Order's Order Number.
	 * Order Number is uniquely set by the system with the following Algorithm:
	 * (current date time * a Random number)
	 */
	private int orderNo;
	
	/**
	 * This order's Price. Total price is computed based on the food / set price which is in this order.
	 */
	private double price;
	
	/**
	 * The staff who took this Order. 
	 */
	private Staff staff;
	
	/**
	 * This Order's order of food items.
	 */
	private ArrayList<Food> foodArray = new ArrayList<Food>();
	
	/**
	 * This Order's order of set items.
	 */
	private ArrayList<Set> setArray = new ArrayList<Set>();
	
	/**
	 * this Order's date
	 */
	private String date;
	
	/**
	 * Default Constructor
	 */

	public Order()
	{
		
	}

	public Order(int orderNo,  ArrayList<Food> foodArray, double price) 
	{
		this.orderNo = orderNo;
		this.foodArray = foodArray;
		this.price = price;

	}
	public Order(int orderNo,  ArrayList<Food> foodArray, String date) 
	{
		this.orderNo = orderNo;
		this.foodArray = foodArray;
		this.date = date;

	}
	
	/**
	 * Creates a new Order Object with its Order Number, Food items, set items, total price and staff who took the order.
	 * 
	 * @param orderNo is this Order's uniquely defined orderNumber.
	 * @param foodArray is the array of food item/s ordered by customer.
	 * @param setArray is the array of set item/s ordered by customer.
	 * @param price is the total price computed based on foodPrice and setPrice.
	 * @param staff is the staff who took this order.
	 */

	public Order(int orderNo,  ArrayList<Food> foodArray, ArrayList<Set> setArray, double price, Staff staff) 
	{
		this.orderNo = orderNo;
		this.foodArray = foodArray;
		this.setArray = setArray;
		this.price = price;
		this.staff = staff;
	}

	/**
	 * Gets this Order's promotional set ordered by customer.
	 * Each order may contain many set items.
	 * @return an arrayList of set items.
	 */
	public ArrayList<Set> getSetArray() {
		return setArray;
	}

	/**
	 * Change or sets this Order's set items.
	 * Each set is derived from Set class.
	 * @param setArray set this Order's setAray to setArray.
	 */
	public void setSetArray(ArrayList<Set> setArray) {
		this.setArray = setArray;
	}

	/**
	 * Gets this Order's Order Number
	 * @return this Order's OrderNo
	 */
	public int getOrderNo() 
	{
		return orderNo;
	}
	
	/**
	 * Changes or Set this Order's Order Number
	 * Order number is uniquely assigned by the system with the following Algorithm
	 * (Curent date time * a large random Number)
	 * 
	 * @param orderNo sets this Order's order number with orderNo
	 */
	public void setOrderNo(int orderNo)
	{
		this.orderNo = orderNo;
	}
	
	/**
	 * Gets the price of this Order.
	 * @return the price of this Order in double.
	 */
	public double getPrice() {
		return price;
	}
	
	/**
	 * Change or Sets the Order's Price.
	 * The price is the value of all the food item price and set price.
	 * @param price
	 */
	public void setPrice(double price)
	{
		this.price = price;
	}

	/**
	 * Get this order list of Food items stored in an Array List.
	 * @return this Order's array of Food Item.
	 */
	public ArrayList<Food> getFoodArray() {
		return foodArray;
	}

	/**
	 * Changes or set this orders food array.
	 * @param foodArray Sets this order's FoodArray with foodArray.
	 */
	public void setFoodArray(ArrayList<Food> foodArray) {
		this.foodArray = foodArray;
	}
	
	/**
	 * Get the staff who took this Order.
	 * @return a staff object who took this order.
	 */
	public Staff getStaff(){
		return staff;
	}
	
	/**
	 * Changes or set the staff who took this Order.
	 * @param staff sets the Staff object in this order with staff.
	 */
	public void setStaff(Staff staff){
		this.staff = staff;
	}
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	/**
	 * Prints the order.
	 */
	public void printMenu()
	{
		this.price = 0;
		int i = 0;
		
		Map<String, Integer> myMap = new HashMap<String, Integer>();
		Map<Integer, Integer> setMap = new HashMap<Integer, Integer>();
		
		for(Food f:foodArray){
				if(myMap.containsKey(f.getFoodName()))
				{
					Integer value = myMap.get(f.getFoodName());
			        if (value == null)
			        {
			             value = 0;
			        }
			        value++;
			        myMap.put(f.getFoodName(), value);
				}
				else
				{
					myMap.put(f.getFoodName(), 1);
				}
		}
		for(Set s:setArray){
			if(setMap.containsKey(s.getSetNo())){
				Integer value = setMap.get(s.getSetNo());
		        if (value == null)
		        {
		             value = 0;
		        }
		        value++;
		        setMap.put(s.getSetNo(), value);
			}
			else
			{
				setMap.put(s.getSetNo(), 1);
			}
		}
		String format = "|%1$-15s|%2$-50s|%3$-10s|%4$-10s|\n";
		System.out.println("Order date/time: " + this.date);
		System.out.println("---------------------------------------------------------------------------------");
		System.out.format(format,"Food/Set ID","Food Name","Quantity","Price");
		System.out.println("---------------------------------------------------------------------------------");
		
		ArrayList<String> printed = new ArrayList<String>();
		ArrayList<Integer> intPrinted = new ArrayList<Integer>();
		
		for(Food f:foodArray){
				
			if(printed.contains(f.getFoodName()))
			{
				this.price += f.getPrice();
				continue;
			}
			printed.add(f.getFoodName());
			System.out.format(format,f.getFoodID(),f.getFoodName(),myMap.get(f.getFoodName()),"$" + String.format("%.2f",myMap.get(f.getFoodName())*f.getPrice()));
			this.price += f.getPrice();
		}
		
		for(Set s:setArray){
			if(intPrinted.contains(s.getSetNo())){
				this.price += s.getPrice();
				continue;
			}
			intPrinted.add(s.getSetNo());
			for(Food f:s.getFood()){
				
				if (i > 0){
					System.out.format(format, "" , f.getFoodName() , "","");
				}
				else{
					System.out.format(format, "Set No " + s.getSetNo(), f.getFoodName() ,setMap.get(s.getSetNo()),"$" + String.format("%.2f", setMap.get(s.getSetNo())*s.getPrice()));
				}
				i++;
			}
			this.price += s.getPrice();
		}
		System.out.println("Total Price: $" + String.format("%.2f",this.price));
		System.out.println("---------------------------------------------------------------------------------");
		
		/*String format = "|%1$-15s|%2$-50s|%3$-10s|\n";
		System.out.println("---------------------------------------------------------------------------------");
		System.out.format(format,"Food/Set ID","Food Name","Price");
		System.out.println("---------------------------------------------------------------------------------");
		for(Food f: foodArray){
			System.out.format(format,f.getFoodID(),f.getFoodName(),"$" + String.format("%.2f",f.getPrice()));
			this.price += f.getPrice();
		}
		for(Set s:setArray){
			System.out.println(s.toString());
			this.price += s.getPrice();
		}
		System.out.println("Total Price: $" + String.format("%.2f",this.price));
		System.out.println("---------------------------------------------------------------------------------");*/
		
	
	}
}

