package oodp_project;
import java.util.ArrayList;


/**
 * This is the Food Class where each type of food in the restaurant can 
 * be identified.
 * One food Object may contain a:	Identification number,
 * 									Name,
 * 									Type,
 * 									Price.
 * 									Description.
 * @author erwinn
 * @version 1.0
 * @since 2014-11-01
 */

public class Food implements Comparable<Object>
	{
		/**
		 * This food's Identification Number.
		 */
		private int foodID;
		
		/**
		 * This food's Name.
		 */
		private String foodName;
		
		/**
		 * This food's Type.
		 * Varies from	: Hors d'Oeuvre
		 * 				: Salads
		 * 				: Main Course
		 * 				: Drinks
		 * 				: Dessert
		 */
		private String foodType;
		
		/**
		 * This food's price.
		 * Price valids in the form of Double.
		 */
		private double price;
		
		/**
		 * This food's Description. 
		 */
		private String desc;
		

		/**
		 * Default Constructor
		 */
		public Food()
		{}
		
		/**
		 * Creates a new Food Object with the given parameters:	foodID
		 * 													  :	foodName
		 * 													  : foodType
		 * 													  : price
		 * 													  : desc
		 * 								
		 * @param foodID is this food's Identification Number.
		 * @param foodName is this food's name.
		 * @param foodType is this food's type.
		 * @param price is this food's price.
		 * @param desc is the description of the food.
		 */
		public Food(int foodID, String foodName, String foodType, double price, String desc)
		{
			this.foodID = foodID;
			this.foodName = foodName;
			this.foodType = foodType;
			this.price = price;
			this.desc = desc;
		}
		
		/**
		 * Gets the Identification number of this food.
		 * @return the identification of this food.
		 */
		public int getFoodID() 
		{
			return foodID;
		}
		
		/**
		 * Changes or sets this food's Identification number.
		 * Food Identification number is uniquely and internally assigned.
		 * @param foodID 	Sets this foodID to foodID.
		 */
		public void setFoodID(int foodID) 
		{
			this.foodID = foodID;
		}
		
		
		/**
		 * Gets this food's Name.
		 * @return this food's name
		 */
		public String getFoodName() 
		{
			return foodName;
		}
		
		/**
		 * Change or Sets this food's name.
		 * @param foodName Sets this food Name to foodName
		 */
		public void setFoodName(String foodName) 
		{
			this.foodName = foodName;
		}
	
		/**
		 * Get's this Food Type.
		 * Food Type can only be: foodID
		 * 		     			: foodName
		 * 		  				: foodType
		 * 						: price
		 * 						: desc
		 * @return this food type
		 */
		public String getFoodType() 
		{
			return foodType;
		}
	
		/**
		 * Change or sets this food Type.
		 * Food Type can only be: foodID
		 * 		     			 : foodName
		 * 		  				 : foodType
		 * 						 : price
		 * 						 : desc
		 * @param foodType Sets this foodType to one of the above.
		 */
		public void setFoodType(String foodType) 
		{
			this.foodType = foodType;
		}
	
		/**
		 * Gets the price of this food.
		 * @return this food's price.
		 */
		public double getPrice() 
		{
			return price;
		}
	
		/**
		 * Changes or sets this food price.
		 * @param price sets this food price to price.
		 */
		public void setPrice(double price) 
		{
			this.price = price;
		}
	
		/**
		 * Gets the description of this food.
		 * @return the description of this food.
		 */
		public String getDesc() 
		{
			return desc;
		}
	
		/**
		 * Change or sets this food description.
		 * @param desc Sets this food description to desc.
		 */
		public void setDesc(String desc) 
		{
			this.desc = desc;
		}
		
		/**
		 * Prints this food parameters.
		 * Format of presentation is initialized. 
		 */
		public String toString()
		{
			String format = "|%1$-5s|%2$-50s|%3$-15s|%4$-7s|%5$-70s|";
			String output = "";
			output += String.format(format, this.foodID,this.foodName,this.foodType,"$" + String.format("%.2f",this.price),this.desc);
			return output;
		}
		
		/**
		 * Implementation of comparable class
		 */
		public int compareTo(Object o)
		{
			Food aFood = (Food) o;
			if (foodID < aFood.getFoodID())
				return -1;
			else if (foodID > aFood.getFoodID())
				return 1;
			else {
			return 0;
			}
		}
		
		/**
		 * Sorts food in foodArray according to foodID
		 * @param foodArray takes in foodArray in order to sort its content based on foodID.
		 */
		public void sortFoodArray(ArrayList<Food> foodArray)
		{
			for (int index = 1; index < foodArray.size(); index++)
			{
				Comparable key = foodArray.get(index);
				int position = index;
				// Shift larger values to the right
				while (position > 0 && key.compareTo(foodArray.get(position-1)) < 0)
				{
					foodArray.set(position, foodArray.get(position-1));
					position--;
				}
				foodArray.set(position, (Food)key);
			}
		}
	}

