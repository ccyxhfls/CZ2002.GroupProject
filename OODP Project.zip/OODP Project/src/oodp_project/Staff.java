package oodp_project;

public class Staff {
	
	private int staffID;
	private String staffName;
	private char gender;
	private String jobTitle;
	
	public Staff(){
		
	}
	
	public Staff(int staffID, String staffName, char gender, String jobTitle) {
		this.staffID = staffID;
		this.staffName = staffName;
		this.gender = gender;
		this.jobTitle = jobTitle;
	}

	public int getStaffID() {
		return staffID;
	}

	public void setStaffID(int staffID) {
		this.staffID = staffID;
	}

	public String getStaffName() {
		return staffName;
	}

	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}

	public char getGender() {
		return gender;
	}

	public void setGender(char gender) {
		this.gender = gender;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
	
	public String toString(){
		String format = "|%1$-10s|%2$-20s|%3$-5s|%4$-10s|\n";
		String output = "";
		output = String.format(format, this.staffID,this.staffName,this.gender,this.jobTitle);
		return output;
		/*return ("******************************" + 
		"\nID: " + this.staffID + 
		"\nStaff Name:" + this.staffName +
		"\nGender:" + this.gender +
		"\nJob Title:" + this.jobTitle +
		"\n******************************");*/
	}
}
