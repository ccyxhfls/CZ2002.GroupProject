package oodp_project;
import java.util.ArrayList;


/**
 * This is a Table class. A table can contain the following particulars: tableNo ( the table number of this table)
 * 																	   : capacity (number of people that can fit into this table)
 * 																	   : reserved (a boolean value to check if this table is reserved)
 * 																	   : occupied (a boolean value to check if this table is occupied)
 * 																	   : cust (a customer object who is occupying or reserved the table)
 * 																	   : Reservation type Arraylist 
 * 																	   : Order Type Arraylist
 * @author erwinn
 * @version 1.0
 * @since 2014-11-01
 */
public class Table 
	{
		/**
		 * this table's table number.
		 */
		private int tableNo;
		
		/**
		 * the capacity of this table.
		 */
		private int capacity;
		
		/**
		 * the reservation status of this table.
		 */
		private boolean reserved;
		
		/**
		 * the occupancy of this table.
		 */
		private boolean occupied;
		
		/**
		 * the custommer object who has reserved or is occupying this table
		 */
		private Customer cust;
		
		/**
		 * a Reservation type Arraylist about this table
		 */
		private ArrayList<Reservation> resArray = new ArrayList<Reservation>();
		
		/**
		 * an Order type Arraylist about this table
		 */
		private ArrayList<Order> orderArray = new ArrayList<Order>();
	
		
		/**
		 * Default constructor
		 */
		public Table()
		{}
	
		/**
		 * Creates a new Table with tableNo, capacity,reserved,occupied,Customer cust, ArrayList <Resevation>, ArrayList<Order>
		 * 
		 * @param tableNo is the table number of this table.
		 * @param capacity is the seating capacity of this table.
		 * @param reserved is the reservation status of this table.
		 * @param occupied is the occupancy of this table.
		 * @param cust is the customer object who has reserved or occupied this table.
		 * @param resArray is the Reservation details of this table.
		 * @param orderArray is the Orders made on this table.
		 */
		public Table(int tableNo, int capacity, boolean reserved,boolean occupied,Customer cust,ArrayList<Reservation> resArray, ArrayList<Order> orderArray)
		{
			this.tableNo = tableNo;
			this.capacity = capacity;
			this.reserved = reserved;
			this.occupied = occupied;
			this.cust = cust;
			this.resArray = resArray;
			this.orderArray = orderArray;
		}
	
		/**
		 * Gets the table number of this table.
		 * @return the table number of this table.
		 */
		public int getTableNo() 
		{
			return tableNo;
		}
	
		/**
		 * Gets the customer object who reserved or occupied this table
		 * @return a customer object who reserved or occupied this table.
		 */
		public Customer getCust() 
		{
			return cust;
		}
	
		/**
		 * Change or set customer to occupy or this table
		 * @param cust sets the customer of this table to cust.
		 */
		public void setCust(Customer cust) 
		{
			this.cust = cust;
		}
	
		/**
		 * Change or set this table number.
		 * @param tableNo sets this table number with tableNo.
		 */
		public void setTableNo(int tableNo) 
		{
			this.tableNo = tableNo;
		}
	
		/**
		 * Checks the reservation status of this table.
		 * @return a boolean value of the reservation status.
		 */
		public boolean isReserved() 
		{
			return reserved;
		}
	
		/**
		 * Change the reservation status of this table.
		 * @param reserved sets the reservation status of this table with reserved.
		 */
		public void setReserved(boolean reserved) 
		{
			this.reserved = reserved;
		}
		
		/**
		 * Checks the occupancy of this table.
		 * @return a boolean value of the occupancy of this table. 
		 */
		public boolean isOccupied()
		{
			return occupied;
		}
		
		/**
		 * Change or sets the occupancy of this table.
		 * @param occupied sets the occupancy of this table with a boolean value occupied.
		 */
		public void setOccupied(boolean occupied) 
		{
			this.occupied = occupied;
		}
	
		/**
		 * Gets the seating capacity of this table.
		 * @return a int value of seating capacity of this table.
		 */
		public int getCapacity(){
			return capacity;
		}
	
		/**
		 * Change or sets the seating capacity of this table.
		 * @param capacity sets the seating capacity of this table with a valid int value capacity.
		 */
		public void setCapacity(int capacity)
		{
			this.capacity = capacity;
		}
		
		/**
		 * Get the list of reservation associated to this table.
		 * @return a list of reservation made on this table.
		 */
		public ArrayList<Reservation> getResArray()
		{
			return resArray;
		}
		
		/**
		 * Change or set reservations made on this table.
		 * @param resArray Sets the reservation details of this table with resArray.
		 */
		public void setResArray(ArrayList<Reservation> resArray)
		{
			this.resArray = resArray;
		}
		
		/**
		 * Get the orders done on from this table.
		 * @return a list of orders that this table has made.
		 */
	    public ArrayList<Order> getOrderArray() 
	    {
			return orderArray;
		}
	
	    /**
	     * Change or set the orders made on this table.
	     * @param orderArray set the orders with orderArray
	     */
		public void setOrderArray(ArrayList<Order> orderArray) 
		{
			this.orderArray = orderArray;
		}
		
		/**
		 * Overrides toString() in Object Class.
		 * Prints this table's Table number.
		 */
		public String toString(){
			return "Table No:" + this.tableNo;
		}
	}

