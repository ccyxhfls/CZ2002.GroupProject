package oodp_project;

/**
 * This is the receipt Class. Receipt is generated when a customer leaves and make a payment in the restaurant.
 * 
 * @author erwinn
 * @version 1.0
 * @since 2014-11-01
 */

public class Receipt 
	{
		/**
		 * this Receipt's receipt Number
		 */
		private int receiptNo;
		
		/**
		 * the table that is settling the bill printed on this receipt.
		 */
		private Table table;
		
		/**
		 * this receipts total price.
		 */
		private double totalPrice;
		
		/**
		 * Default Constructor
		 */
		public Receipt()
		{}
		
		/**
		 * Creates a new Receipt with its Receipt Number, total Price and the table number.
		 * @param receiptNo is the receipt number of this receipt.
		 * @param totalPrice is the total price inclusive of gst and service charge on this receipt.
		 * @param table is the table that is settling the bill for this receipt.
		 */
		public Receipt(int receiptNo,int totalPrice,Table table) 
		{
			this.receiptNo = receiptNo;
			this.totalPrice = totalPrice;
			this.table = table;
		}
	
		/**
		 * Gets the Table object for this receipt.
		 * Table class javadoc can be refered.
		 * @return a table object of this receipt.
		 */
		public Table getTable() 
		{
			return table;
		}
	
		/**
		 * Change or set a table on this receipt.
		 * @param table sets the Table object in this receipt with table.
		 */
		public void setTable(Table table) 
		{
			this.table = table;
		}
	
		/**
		 * Gets the receipt number of this receipt. 
		 * @return a integer value of this receipt number.
		 */
		public int getReceiptNo()
		{
			return receiptNo;
		}
	
		/**
		 * Change or sets this receipt number.
		 * @param receiptNo sets this receipt number with receiptNo.
		 */
		public void setReceiptNo(int receiptNo) 
		{
			this.receiptNo = receiptNo;
		}
	
		/**
		 * gets the total Price on this receipt.
		 * @return the the total price in double.
		 */
		public double getTotalPrice()
		{
			return totalPrice;
		}
	
		/**
		 * Change or sets the total price of this receipt.
		 * @param totalPrice2 sets the total price on this receipt with totalPrice.
		 */
		public void setTotalPrice(double totalPrice2) 
		{
			this.totalPrice = totalPrice2;
		}
	}
