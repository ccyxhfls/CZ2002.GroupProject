package oodp_project;

/**
 * This is a Set class where promotional sets for the restaurant are created.
 * Each set contains a uniquely assigned set Number,
 * a Food Type array where there are 3 food Items of type Hors d'Oeuvre/Salads , Main Course , Drinks/Dessert.
 * and price of the set.
 * 
 * @author erwinn
 * @version 1.0
 * @since 2014-11-01
 *
 */

public class Set 
	{
		/**
		 * This Set's Set number
		 * The set number is uniquely assiged so that there are no same set with different food item.
		 */
		private int setNo;
		
		/**
		 * Food items in this set.
		 * this set can only contain 3 food itemsof type Hors d'Oeuvre/Salads , Main Course , Drinks/Dessert.
		 */
		private Food [] food;
		
		/**
		 * This set's price.
		 * The price of this set is set at 10% off the total price of food item in this set.
		 */
		private double price;
		
		/**
		 * Default Constructor
		 */
		public Set()
		{}
		
		/**
		 * Creates a new set with the its setNo, 3 different type of food in a Food Type array, and price of the set.
		 * @param setNo is a uniquely assigned number to this set.
		 * @param food is an array of 3 Food items.
		 * @param price is the 90% if the total price of the food in the food array.
		 */
		public Set(int setNo,Food [] food, double price)
		{
			this.setNo = setNo;
			this.food = food;
			this.price = price;
		}
		
		/**
		 * Get this set's Set Number
		 * @return this set's set number
		 */
		public int getSetNo() 
		{
			return setNo;
		}
		
		
		/**
		 * Change or set this set's Set Number
		 * @param setNo sets this Set's set number to setNo
		 */
		public void setSetNo(int setNo)
		{
			this.setNo = setNo;
		}
		
		/**
		 * Gets the price of this set.
		 * @return the price of this set in double.
		 */
		public double getPrice()
		{
			return price;
		}
		
		/**
		 * Change or set the price of this set.
		 * @param price sets the price of this set with price.
		 */
		public void setPrice(double price)
		{
			this.price = price;
		}
		
		/**
		 * Gets a Food type Array of this set.
		 * This Array contains 3 food type objects.
		 * @return this set's Food items.
		 */
		public Food[] getFood() 
		{
			return food;
		}
		
		/**
		 * Changes or set this set's Food Item. 
		 * @param food sets this set's Food item with food.
		 */
		public void setFood(Food[] food)
		{
			this.food = food;
		}
		
		/**
		 * Overrides toString() in Object Class.
		 * Prints out the content of this set.
		 */
		public String toString()
		{
			String output = "";
			String format = "|%1$-15s|%2$-50s|%3$-10s|\n";
			int i =0;
			
			for(Food f:food)
				{
					
				if (i > 0)
					{
						output += String.format(format, "" , f.getFoodName() , "");
					}
				else
					{
						output = String.format(format, "Set No " + this.setNo, f.getFoodName() ,"$"+String.format("%.2f",this.price));
					}
				i++;
			}
			return output;
		}
	}
	
