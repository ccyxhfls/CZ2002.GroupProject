package oodp_project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;
import java.util.InputMismatchException;

public class FoodMgr {
	
	static Scanner sc = new Scanner(System.in);
	
	int foodID,foodTypeChoice,setID,foodNo;
	double price,setPrice;
	String foodName,foodType,desc,end;
	boolean startEdit;
	
	public void insertFood(ArrayList<Food> foodArray){
		Food newFood = new Food();
		boolean sameID = true;
		boolean again = true;
		while (sameID == true){
			System.out.println("Enter Food ID: ");
			try{
				foodID = sc.nextInt();
			}
			catch(InputMismatchException e){
				System.out.println("Invalid Input");
				sc.next();
				continue;
			}
			for(Food f:foodArray){
				if(foodID == f.getFoodID()){
					sameID = true;
					System.out.println("*Duplicated Food ID.Please enter a new Food ID.*");
					break;
				}
				sameID = false;
			}
		}
	
    	System.out.println("Enter Food Name: ");
    	sc.nextLine();//flush
    	foodName = sc.nextLine();
    	System.out.println("Enter Food Type: ");
    	//foodType = sc.nextLine();
    	displayFoodType();
    	foodTypeChoice = sc.nextInt();
    	switch (foodTypeChoice){
    		case 1:
    			newFood.setFoodType("Hors d'Oeuvre");
    			break;
    		case 2:
    			newFood.setFoodType("Salads");
    			break;
    		case 3:
    			newFood.setFoodType("Main Course");
    			break;
    		case 4:
    			newFood.setFoodType("Drinks");
    			break;
    		case 5:
    			newFood.setFoodType("Dessert");
    			break;
    	}
    	while(again){
	    	System.out.println("Enter Price: ");
	    	try{
		    	price = sc.nextDouble();
		    	again = false;
	    	}
	    	catch (InputMismatchException e){
	    		System.out.println("Invalid input.");
	    		sc.next();
	    	}
    	}
    	sc.nextLine();//flush
    	System.out.println("Enter Description: ");
    	desc = sc.nextLine();
    	
  
    	newFood.setFoodID(foodID);
    	newFood.setFoodName(foodName);
    	newFood.setPrice(price);
    	newFood.setDesc(desc);
    	
    	foodArray.add(newFood);
	}
	public void deleteFood(ArrayList<Food> foodArray){
		boolean again = true;
		while(again){
			System.out.println("Enter ID to be deleted: ");
			try{
				foodID = sc.nextInt();
			}
			catch (InputMismatchException e){
				System.out.println("Invalid input");
				sc.next();
				continue;
			}
				
			int i = 0;
			for(Food f: foodArray){
				if(f.getFoodID() == foodID){
					break;
				}
				i++;
			}
			try{
				foodArray.remove(i);
				again = false;
			}
			catch(IndexOutOfBoundsException e){
				System.out.println("Invalid Food ID");
			}
		}
	}
	public void editFood(ArrayList<Food> foodArray){
		boolean again = true;
		while(again){
			System.out.println("Enter ID to be edited:");
			try{
				foodID = sc.nextInt();
			}
			catch (InputMismatchException e){
				System.out.println("Invalid input");
				sc.next();
				continue;
			}
		
			int i = 0;
			for(Food f:foodArray){
				if(f.getFoodID() == foodID){
					System.out.println("Food ID: " + foodArray.get(i).getFoodID());
					System.out.println("Current Food Name: " + foodArray.get(i).getFoodName());
					System.out.println("Enter new Food Name: ");
					sc.nextLine();//flush
					foodName = sc.nextLine();
					System.out.println("Current Food Type: " + foodArray.get(i).getFoodType());
					System.out.println("Enter new Food Type: ");
					displayFoodType();
			    	foodTypeChoice = sc.nextInt();
			    	switch (foodTypeChoice){
			    		case 1:
			    			foodArray.get(i).setFoodType("Hors d'Oeuvre");
			    			break;
			    		case 2:
			    			foodArray.get(i).setFoodType("Salads");
			    			break;
			    		case 3:
			    			foodArray.get(i).setFoodType("Main Course");
			    			break;
			    		case 4:
			    			foodArray.get(i).setFoodType("Drinks");
			    			break;
			    		case 5:
			    			foodArray.get(i).setFoodType("Dessert");
			    			break;
			    	}
					//foodType = sc.nextLine();
					System.out.println("Current Price: " + foodArray.get(i).getPrice());
					while(again){
						System.out.println("Enter new Price: ");
						try{
							price = sc.nextDouble();
							again = false;
						}
						catch (InputMismatchException e){
							System.out.println("Invalid input");
							sc.next();
						}
					}
					sc.nextLine();//flush
					System.out.println("Current Description: " + foodArray.get(i).getDesc());
					System.out.println("Enter new Description: ");
					desc = sc.nextLine();
					break;
				}
				i++;
			}
			try{
				foodArray.get(i).setFoodName(foodName);
				foodArray.get(i).setPrice(price);
				foodArray.get(i).setDesc(desc);
				again = false;
			}
			catch (IndexOutOfBoundsException e){
				System.out.println("Invalid Food ID");
			}
		}
	}
	public void update(ArrayList<Food> foodArray) throws IOException{
		String content;
		
		BufferedWriter bw = new BufferedWriter(new FileWriter("food.txt"));
		
		for (Food f:foodArray){
			content = f.getFoodID() + "," + f.getFoodName() + "," + f.getFoodType() + "," + f.getPrice() + "," + f.getDesc();
			bw.write(content);
			bw.newLine();
			bw.flush();
		}
		bw.close();
	}
	public void displayFoodCat(){
		System.out.println("1) Hors d'Oeuvre");
		System.out.println("2) Salads");
		System.out.println("3) Main Course");
		System.out.println("4) Drinks");
		System.out.println("5) Dessert");
		System.out.println("6) Show All");
		System.out.println("7) View Sets");
		System.out.println("----------------------------------------------------------------");
		System.out.println("Please Select Category:");
	}
	public void displayFoodType(){
		System.out.println("1) Hors d'Oeuvre");
		System.out.println("2) Salads");
		System.out.println("3) Main Course");
		System.out.println("4) Drinks");
		System.out.println("5) Dessert");
		System.out.println("----------------------------------------------------------------");
		System.out.println("Please Select Food Type:");
	}
	public ArrayList<Set> InsertSetItem(ArrayList<Food> foodArray,ArrayList<Set> setArray){
		Set set = new Set();
		ArrayList<Food> appsArray = new ArrayList<Food>();
		ArrayList<Food> mainArray = new ArrayList<Food>();
		ArrayList<Food> desArray = new ArrayList<Food>();
		
		int setID = 0;
		int i=0;
		double setPrice = 0;
		boolean again = true;
		
		//Each set only contains 3 food item
		Food [] foodSet = new Food[3];
		for(Food f:foodArray){
			if(f.getFoodType().equals("Hors d'Oeuvre") || f.getFoodType().equals("Salads"))
				appsArray.add(f);
			else if(f.getFoodType().equals("Main Course"))
				mainArray.add(f);
			else if(f.getFoodType().equals("Drinks") || f.getFoodType().equals("Dessert"))
				desArray.add(f);
		}
		
		while(i < 3){
			Food food = new Food();
			if(i == 0){
				food = addSetItem(appsArray);
			}
			else if(i == 1)
			{
				food = addSetItem(mainArray);
			}
			else{
				food = addSetItem(desArray);
			}
			foodSet[i] = food;
			i++;
		}
		
		setID = setArray.size() + 1;
		for(Food f:foodSet){
			setPrice += f.getPrice();
		}
		set.setSetNo(setID);
		set.setPrice(setPrice*0.9);
		set.setFood(foodSet);
		
		//Add set to array list
		setArray.add(set);
		return setArray;
	}
	public void viewSet(ArrayList<Set> setArray){
		int i =0;
		if(setArray.isEmpty()){
			System.out.println("No Promotion Set Available");
		}
		for(Set s :setArray){
			System.out.println("----------------------------------------------------------------");
			System.out.println(s.toString());
			System.out.println("----------------------------------------------------------------");
			i++;
		}
	}
	public void deleteSet(ArrayList<Set> setArray){
		boolean again = true;
		if(setArray.isEmpty()){
			System.out.println("No Promotion Set Available.");
		}
		else
			while(again){
				System.out.println("Enter Set ID to be deleted: ");
				setID = sc.nextInt();
				int i = 0;
				for(Set s:setArray){
					if(s.getSetNo() == setID){
						break;
					}
					i++;
				}
				try{
					setArray.remove(i);
					again = false;
				}
				catch(IndexOutOfBoundsException e){
					System.out.println("Invalid Set ID");
				}
			}
	}
	public void editSet(ArrayList<Food> foodArray, ArrayList<Set> setArray){
		startEdit = true;
		
		ArrayList<Integer> tempArray = new ArrayList<Integer>();
		ArrayList<Food> appsArray = new ArrayList<Food>();
		ArrayList<Food> mainArray = new ArrayList<Food>();
		ArrayList<Food> desArray = new ArrayList<Food>();
		
		for(Set s:setArray){
			tempArray.add(s.getSetNo());
			System.out.println(s.toString());
		}
		
		while (true){
			System.out.println("Enter Set ID to edit: ");
			try{
				setID = sc.nextInt();
			}
			catch (InputMismatchException e){
				System.out.println("Invalid Input");
				sc.next();
				continue;
			}
			if(tempArray.contains(setID) == false){
				System.out.println("Invalid Set ID");
				continue;
			}
			else{
				break;
			}
		}
		
		for(Food f:foodArray){
			if(f.getFoodType().equals("Hors d'Oeuvre") || f.getFoodType().equals("Salads"))
				appsArray.add(f);
			else if(f.getFoodType().equals("Main Course"))
				mainArray.add(f);
			else if(f.getFoodType().equals("Drinks") || f.getFoodType().equals("Dessert"))
				desArray.add(f);
		}
		
		int i = 1;
		
		for(Set s:setArray){
			if(s.getSetNo() == setID){
				for(Food f:s.getFood()){
					System.out.println("Food Item " + i + ": " + f.getFoodName());
					i++;
				}
				while (startEdit)
				{
					System.out.println("Enter Food Item No.to be edited: ");
					foodNo = sc.nextInt();
					
					if(foodNo == 1){
						editSetItem(s.getFood(),appsArray);
					}
					else if (foodNo == 2){
						editSetItem(s.getFood(),mainArray);
					}
					else if (foodNo == 3){
						editSetItem(s.getFood(),desArray);
					}
					for(Food f: s.getFood()){
						setPrice +=f.getPrice();
					}
					s.setPrice(setPrice*0.9);
					s.setFood(s.getFood());
					
					System.out.println("Want to Edit more item ?<Y/N>");
					end = sc.next().toUpperCase();
					
					if(end.equals("Y")){
						continue;
					}
					else{
						startEdit = false;
					}
					
				}
			}
		}
	}
	public Food addSetItem(ArrayList<Food> foodArray){
		Food food = new Food();
		food.sortFoodArray(foodArray);
		
		//temp arraylist to store food ID for checking purpose
		ArrayList<Integer> tempArray = new ArrayList<Integer>();
		
		boolean again = true;
	
		for(Food f:foodArray){
			tempArray.add(f.getFoodID());
			System.out.println(f.toString());
		}
			while (again){
				System.out.println("Enter Food ID of Food to be added:");
				try{
					foodID = sc.nextInt();
				}
				catch (InputMismatchException e){
					System.out.println("Invalid Input");
					sc.next();
					continue;
				}
				
				if(tempArray.contains(foodID) == false){
					System.out.println("Food ID does not exist");
					continue;
				}
				else{
					break;
				}
			}
			for(Food f:foodArray){
				if(foodID == f.getFoodID()){
					food.setFoodID(f.getFoodID());
					food.setFoodName(f.getFoodName());
					if(f.getFoodName().length() == 0){
						System.out.println("Invalid Food ID");
						
					}
					food.setFoodType(f.getFoodType());
					food.setPrice(f.getPrice());
					food.setDesc(f.getDesc());
					break;
				}
			}
			return food;
	}
	public void editSetItem (Food [] food,ArrayList<Food> foodArray){
		ArrayList<Integer> tempArray = new ArrayList<Integer>();
		
		for(Food f:foodArray){
			tempArray.add(f.getFoodID());
			System.out.println(f.toString());
		}
		while (true){
			System.out.println("Enter new Food ID: ");
			foodID = sc.nextInt();
			if(tempArray.contains(foodID) == false){
				System.out.println("Invalid Food ID");
				continue;
			}
			else{
				break;
			}
		}
		for(Food f:foodArray){
			if(foodID == f.getFoodID()){
				food[foodNo-1].setFoodName(f.getFoodName());
				food[foodNo-1].setFoodType(f.getFoodType());
				food[foodNo-1].setPrice(f.getPrice());
				food[foodNo-1].setFoodID(f.getFoodID());
				food[foodNo-1].setDesc(f.getDesc());
			}
		}
	}
}
