package oodp_project;

import java.io.IOException;
import java.text.ParseException;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.ArrayList;

public class RestaurantUI {
	
	static Scanner sc = new Scanner(System.in);
	
	static final int noTable = 10;

	public static void main(String[] args) throws IOException, ParseException {
		
		int choiceMenu = 0,choiceFood,foodCategory,choiceSet,editOrder = 0;
		
		ArrayList<Food> foodArray = new ArrayList<Food>();
		ArrayList<Set> setArray = new ArrayList<Set>();
		
		//Creation of objects
		Restaurant rest = new Restaurant();
		Table [] table = new Table[noTable];
		
		//control class
		FoodMgr fm = new FoodMgr();
		ReserveMgr rm = new ReserveMgr();
		OrderMgr om = new OrderMgr();
		ReceiptMgr rem = new ReceiptMgr();
		
		//Initialisation when app starts
		table = rest.initTable(noTable);
		foodArray = rest.createFoodMenu();
		
		String format = "|%1$-5s|%2$-50s|%3$-15s|%4$-7s|%5$-70s|";
		
		do
        {   
			rest.displayMenu();
			choiceMenu = sc.nextInt();

            switch(choiceMenu)
            {
                case 1: fm.displayFoodCat();
                		foodCategory = sc.nextInt();
                		sc.nextLine();
                		switch(foodCategory)
                		{
                		case 1:System.out.println("-----------------------------------------------Hors d'Oeuvre------------------------------------------------------------");
            			System.out.format(format, "ID","Food Name","Food Type","Price","Description");
            			System.out.println("\n------------------------------------------------------------------------------------------------------------------------");	
                			for(Food f:foodArray)
                		{
                			
                			if(f.getFoodType().equals("Hors d'Oeuvre"))
                    		System.out.println(f.toString());
                    	}
                			break;
                		case 2:
                			System.out.println("-------------------------------------------------Salads--------------------------------------------------------------");
                			System.out.format(format, "ID","Food Name","Food Type","Price","Description");
                			System.out.println("\n---------------------------------------------------------------------------------------------------------------------");
                			for(Food f:foodArray)
                		{
                			if(f.getFoodType().equals("Salads"))
                    		System.out.println(f.toString());
                    	}
                			break;
                		case 3:System.out.println("-----------------------------------------------Main Course--------------------------------------------------------------");
            				   System.out.format(format, "ID","Food Name","Food Type","Price","Description");
            			       System.out.println("\n------------------------------------------------------------------------------------------------------------------------");	
                			for(Food f:foodArray)
		                		{
              
		                			if(f.getFoodType().equals("Main Course"))
		                    		System.out.println(f.toString());
		                    	}
		                			break;
		                			
                		case 4:System.out.println("-------------------------------------------------Drinks--------------------------------------------------------------");
            				   System.out.format(format, "ID","Food Name","Food Type","Price","Description");
            			       System.out.println("\n---------------------------------------------------------------------------------------------------------------------");	
                			for(Food f:foodArray)
                		{
                			if(f.getFoodType().equals("Drinks"))
                    		System.out.println(f.toString());
                    	}
                			break;
                			
                		case 5:
            			System.out.println("-------------------------------------------------Dessert-------------------------------------------------------------");
            			System.out.format(format, "ID","Food Name","Food Type","Price","Description");
            			System.out.println("\n-------------------------------------------------------------------------------------------------------------------");
                		for (Food f:foodArray)
                		{
                			if(f.getFoodType().equals("Dessert"))
                    		System.out.println(f.toString());
                    	}
                			break;
                		case 6:
                			System.out.println("------------------------------------------------Food Item------------------------------------------------------------");
                			System.out.format(format, "ID","Food Name","Food Type","Price","Description");
                			System.out.println("\n-------------------------------------------------------------------------------------------------------------------");
                			for(Food f:foodArray)
	                		{
	                    		System.out.println(f.toString());
	                    	}
                			break;
                		case 7:
                			fm.viewSet(setArray);
                		}
                		break;
                case 2:
                	System.out.println("1.Insert Food Item");
                	System.out.println("2.Edit Food Item");
                	System.out.println("3.Delete Food Item");
                	System.out.println("================================");
                	System.out.println("Please Enter your choice");
                	choiceFood = sc.nextInt();
                	switch(choiceFood)
                	{
                		case 1:
                			fm.insertFood(foodArray);
                			fm.update(foodArray);
                			break;
                		case 2:
                			fm.editFood(foodArray);
                			fm.update(foodArray);
                			break;
                		case 3:
                			fm.deleteFood(foodArray);
                			fm.update(foodArray);
                			break;
                		default:System.out.println("Invalid input");
                			break;
                	}
                		break;
                case 3: 
                	System.out.println("1.Insert Set Item");
                	System.out.println("2.Edit Set Item");
                	System.out.println("3.Delete Set Item");
                	System.out.println("================================");
                	System.out.println("Please Enter your choice");
                	choiceSet = sc.nextInt();
                	switch(choiceSet)
                	{
                		case 1:
                			fm.InsertSetItem(foodArray,setArray);
                			break;
                		case 2:
                			fm.editSet(foodArray, setArray);
                			break;
                		case 3:
                			fm.deleteSet(setArray);
                			break;
                	}
        				break;
                case 4:	om.createOrder(foodArray,setArray,table);
                		break;
                case 5: om.showOrders(table);
                		break;
                case 6:	System.out.println("1.Add Orders");
    					System.out.println("2.Delete Items");
    					System.out.println("3.Delete Order");
    					System.out.println("================================");
    					System.out.println("Please Enter your choice");
    				
    					editOrder = sc.nextInt();
    				
    					switch(editOrder)
    					{
    						case 1:
    							om.addOrders(table,foodArray,setArray);
    							break;
    						case 2:
    							om.removeItem(table);
    							break;
    						case 3:
    							om.removeOrder(table);
    							break;
    						default:System.out.println("Invalid input");
    							break;
    					}
                		break;
                case 7:	
                		 rm.createReservation(table);
                		break;       
                case 8:	
                		rm.showReservation(table);
            			break; 
                case 9:	
                		rm.removeReservation(table);
            			break; 
                case 10:	
                		rest.showAvailTable(table);
            			break; 
                case 11: 
                		rem.printReceipt(table);
            			break; 
                case 12:rest.getSalesReport(); 	
            			break; 
                case 13: System.out.println("Thank you for using the System :D");
                		 fm.update(foodArray);
                		 System.exit(0);
            			break; 
            	default: System.out.println("Invalid Input");
            			
            }//end switch
        }while((choiceMenu >= 1) && (choiceMenu < 13));
		

	}

}
