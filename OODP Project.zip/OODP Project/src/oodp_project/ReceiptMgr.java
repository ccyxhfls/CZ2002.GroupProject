package oodp_project;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;

public class ReceiptMgr {
	
	static Scanner sc = new Scanner(System.in);
	
	Receipt rpt = new Receipt();
	
	public void printReceipt(Table [] table) throws IOException{
	
		int tableNo = 0,orderNo = 0,i = 0,orderChoice = 0,numOrder = 1;
		
		double discount = 0.1;
		double gst = 0.07;
		double svcCharge = 0.1;
		double totalPrice = 0;
		
		boolean flag = true;
		
		Date date = new Date();
		
		//Calendar object to track current date time
		Calendar cal = new GregorianCalendar();
		
		//Set Calendar object to current date time
		cal.setTime(date);
		
		ArrayList<Order> tempOrder = new ArrayList<Order>();
		ArrayList<Food> foodArray = new ArrayList<Food>();
		
		while (flag){
			System.out.println("Enter Table No");
			try{
				tableNo = sc.nextInt();
				flag = false;
			}
			catch (InputMismatchException e){
				System.out.println("Invalid input");
				sc.next();
				continue;
			}
			catch (IndexOutOfBoundsException e){
				System.out.println("Invalid input");
				sc.next();
				continue;
			}
		}
		
		for(Table t:table){
			if(tableNo == t.getTableNo()){
				t.setOccupied(false);
				t.setReserved(false);
			for(Order ord: t.getOrderArray()){
				tempOrder.add(ord);
			}
	
			for(Order o: tempOrder){
				for(Order or:tempOrder){
					System.out.println(numOrder + ". " + or.getOrderNo());
					numOrder++;
				}
				while(orderChoice < 1 || orderChoice > t.getOrderArray().size() ){
					System.out.println("Please select order to print:");
					try{
						orderChoice = sc.nextInt();
						orderNo = t.getOrderArray().get(orderChoice-1).getOrderNo();
					}
					catch(ArrayIndexOutOfBoundsException e){
						System.out.println("Invalid input");
						sc.next();
						continue;
					}
					catch(InputMismatchException e){
						System.out.println("Invalid input");
						sc.next();
						continue;
					}
					catch(IndexOutOfBoundsException e){
						System.out.println("Invalid input");
						sc.next();
						continue;
					}
					//orderNo = sc.nextInt();
				}
				
				if(orderNo == o.getOrderNo()){
					System.out.println("------------------------------------ Receipt ----------------------------------------");
					System.out.println(o.getDate());
					System.out.println("Served by: " + o.getStaff().getStaffName());
					System.out.println(t.toString() + "\t\t\t\t\t\t" + o.getOrderNo());
					System.out.println("-------------------------------------------------------------------------------------");
					
					Map<String, Integer> myMap = new HashMap<String, Integer>();
					Map<Integer, Integer> setMap = new HashMap<Integer, Integer>();
					
					for(Food f:o.getFoodArray()){
							if(myMap.containsKey(f.getFoodName()))
							{
								Integer value = myMap.get(f.getFoodName());
						        if (value == null)
						        {
						             value = 0;
						        }
						        value++;
						        myMap.put(f.getFoodName(), value);
							}
							else
							{
								myMap.put(f.getFoodName(), 1);
							}
					}
					for(Set s:o.getSetArray()){
						if(setMap.containsKey(s.getSetNo())){
							Integer value = setMap.get(s.getSetNo());
					        if (value == null)
					        {
					             value = 0;
					        }
					        value++;
					        setMap.put(s.getSetNo(), value);
						}
						else
						{
							setMap.put(s.getSetNo(), 1);
						}
					}
					String format = "%1$-15s %2$-50s %3$-10s %4$-10s \n";
					
					ArrayList<String> printed = new ArrayList<String>();
					ArrayList<Integer> intPrinted = new ArrayList<Integer>();
					
					for(Food f:o.getFoodArray()){
						foodArray.add(f);
						if(printed.contains(f.getFoodName()))
						{
							continue;
						}
						printed.add(f.getFoodName());
						System.out.format(format,f.getFoodID(),f.getFoodName(),myMap.get(f.getFoodName()),"$" + String.format("%.2f",myMap.get(f.getFoodName())*f.getPrice()));
					}
					
					for(Set s:o.getSetArray()){
						if(intPrinted.contains(s.getSetNo())){
							continue;
						}
						intPrinted.add(s.getSetNo());
						for(Food f:s.getFood()){
							foodArray.add(f);
							if (i > 0){
								System.out.format(format, "" , f.getFoodName() , "","");
							}
							else{
								System.out.format(format, "Set No " + s.getSetNo(), f.getFoodName() ,setMap.get(s.getSetNo()),"$" + String.format("%.2f", setMap.get(s.getSetNo())*s.getPrice()));
							}
							i++;
						}
					}
					if(t.getCust().getMembership() == true){
						totalPrice = o.getPrice() + o.getPrice()*gst + o.getPrice()*svcCharge + o.getPrice()*discount;
						
						System.out.println("------------------------------------------------------------------------------------");
						System.out.println("\t\t\t\t\t\t\tSub-total: $" + String.format("%.2f",o.getPrice()));
						System.out.println("\t\t\t\t\t\t\tDiscount: " + discount);
						System.out.println("\t\t\t\t\t\t\tGST: " + gst);
						System.out.println("\t\t\t\t\t\t\tService Charge:" + svcCharge);
						System.out.println("------------------------------------------------------------------------------------");
						System.out.println("\t\t\t\t\t\t\t\t\tTotal Price: $" + String.format("%.2f",totalPrice));
						System.out.println("------------------------------------------------------------------------------------");
						System.out.println("                         Thank you for your patronage!                              ");
						System.out.println("------------------------------------------------------------------------------------");
					}
					else{
						totalPrice = o.getPrice() + o.getPrice()*gst + o.getPrice()*svcCharge;
						
						System.out.println("------------------------------------------------------------------------------------");
						System.out.println("\t\t\t\t\t\t\tSub-total: $" + String.format("%.2f",o.getPrice()));
						System.out.println("\t\t\t\t\t\t\tGST: " + gst);
						System.out.println("\t\t\t\t\t\t\tServiceCharge:" + svcCharge);
						System.out.println("------------------------------------------------------------------------------------");
						System.out.println("\t\t\t\t\t\t\tTotal Price: $" + String.format("%.2f",totalPrice));
						System.out.println("------------------------------------------------------------------------------------");
						System.out.println("                         Thank you for your patronage!                              ");
						System.out.println("------------------------------------------------------------------------------------");
					}
				}
				rpt.setTotalPrice(totalPrice);
				WritetoSales(o.getOrderNo(),foodArray,totalPrice);
				t.getOrderArray().remove(o);
				orderNo++;
				
			}
			}
		}
	}
	public void WritetoSales(int OrderNo,ArrayList<Food> foodArray,double price) throws IOException{
		String content;
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date = new Date();
		DecimalFormat df = new DecimalFormat("#.00");
		BufferedWriter bw = new BufferedWriter(new FileWriter("order.txt",true));
		
		for (Food f:foodArray){
			
			content =   dateFormat.format(date) + ":" + OrderNo + ":" + f.getFoodID() + ":" + f.getFoodName() + ":" + f.getFoodType() + ":" + f.getPrice() + ":" + f.getDesc();		
			bw.newLine();
			bw.write(content);
			bw.newLine();
			bw.flush();

		}
		content="!:" + dateFormat.format(date) + ":"+ df.format(price);
	
		bw.write(content);
		//bw.newLine();
		bw.flush();
		bw.close();
	}

}
