package oodp_project;

/**
 * This is a Customer Class where each customer can be uniquely identified by their
 * 		Customer ID. Each customer has a Name and if he/she holds a membership for the restaurant.
 * 
 * @author  erwinn
 * @version 1.0
 * @since 2014-11-01
 */

public class Customer 
	{
	
		/**
		 * The custumer ID of this Customer
		 */
		private int custID;
		
		/**
		 * The first and Last name of this customer
		 */
		private String custName;
		
		/**
		 * If this customer holds a Membership to the restaurant
		 */
		private boolean membership;

		/**
		 * Default Constructor
		 */
		public Customer()
		{}
		
		
		/**
		 * Creates a new Customer object with the given ID, Name and Membership status
		 * @param custID is this Customer's Identification Number
		 * @param custName is this Customer's Name. Can be with or without Last Name
		 * @param membership shows if this Customer Holds a membership
		 */
		public Customer(int custID, String custName, boolean membership)
		{
			this.custID = custID;
			this.custName = custName;
			this.membership = membership;
		}
		
		
		/**
		 * Gets the Customer ID of this Customer.
		 * @return this Customer's ID.
		 */
		public int getCustID() 
		{
			return custID;
		}
	
		
		/**
		 * Change or Sets this Customer ID to custID 
		 * Value of ID is (current date time * a Random number)
		 * @param custID 	Sets this 
		 * 					customer ID to custID 
		 * 
		 */
		public void setCustID(int custID) 
		{
			this.custID = custID;
		}
		
	
		/**
		 * Gets this Customer's Name.
		 * The name can may contain first name, last name or just this customer's first name.
		 * @return this Customer's Name.
		 */
		public String getCustName() 
		{
			return custName;
		}
		
		
		/**
		 * Change or sets this Customer's name.
		 * Name of the customer may contain first name, last name or just this customer's first name.
		 * 
		 * @param custName	Sets this customer name from nothing to custName
		 */
		public void setCustName(String custName) 
		{
			this.custName = custName;
		}
	
		
		/**
		 * Gets a boolean value of this Customer's Membership. 
		 * this Customer can only have or dont have a membership.
		 * @return a membership status.
		 */
		public boolean getMembership()
		{
			return membership;
		}
		
	
		/**
		 * Change or Sets the membership status of this customer
		 * Membership state can only be true or false
		 * @param membership Sets this customer's membership status to True or False.
		 */
		public void setMembership(boolean membership)
		{
			this.membership = membership;
		}
	

	}
